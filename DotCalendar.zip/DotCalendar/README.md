# Dot Calendar · ドット暦

A minimal dot calendar: flat dots on a dark ground, one orange dot for today. The Japanese side carries a Samurai Champloo spirit through type and small accents: ink-brush kanji months (十月) with a vermilion brush swipe, a red hanko seal, hip-hop marker lettering for English titles, an optional sunflower for today, and the year as a vinyl record.

## Features

- **Japanese or English** for the app and both widgets (one shared setting). Tap 日 / EN on either widget or at the top of the app.
- **Japanese calendar**: 令和 era years in kanji numerals, kanji months and traditional names (神無月), 日月火水木金土 weekdays, all public holidays with English names.
- **Week widget** (4×1) and **month widget** (4×4), both resizable.
- **Widget backgrounds**: Clear (default), Solid, Glass, Blur, with a strength slider for Glass and Blur. Android widgets can't blur the wallpaper behind them, so Blur is drawn as frosted glass.
- **Widget text color**: automatic, or any color.
- **Settings**: dark or paper theme, dots or squares, dates on the dots, sunflower for today, and colors for passed days, today, Sundays/holidays and upcoming days, with a live widget preview.

## Building with GitHub (phone only)

The build script in `.github/workflows/` unzips `DotCalendar.zip` and builds the APK. To update: upload a new `DotCalendar.zip` (same name), wait for the green check under Actions, then download `app-release.apk` from Releases.

The app is signed with a permanent key (`app/dotcalendar.keystore`), so once this version is installed, later versions install over it. If the very first version is still installed, uninstall it once first.

## Changing things in code

- Look and drawing: `app/src/main/java/dev/dotcalendar/render/Renderer.java` (shared by app and widgets)
- Default colors and swatches: `Settings.kt`
- Text in both languages: `Tx.kt`
- Holidays: `JapaneseHolidays.kt` (current law; accurate from 2022 onward)

## Fonts

Yuji Boku (SIL Open Font License) and Permanent Marker (Apache 2.0), subset to the characters the app uses; other text uses the phone's own font. Licenses are in `licenses/`.
