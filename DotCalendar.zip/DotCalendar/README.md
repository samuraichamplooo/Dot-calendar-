# Dot Calendar · ドット暦

A minimal dot calendar with Japanese dates, Japanese and US holidays, a week widget and a month widget, and six swappable themes.

## Themes

| Theme | Look |
| --- | --- |
| 浪人 RONIN | Grey grainy poster paper, flat ukiyo-e colours (vermilion, indigo, bone), brush kanji, marker lettering, a white cloud, a 🌻 for today, the year as a vinyl record |
| 墨 SUMI | Black ink on grainy paper under a soft spotlight, ink-blot dots, a brush ensō for today, the year painted as an ensō |
| 気 KI | Deep blue with manga speed lines, hot orange and yellow, a flame (or burst) for today, the year as a power-gauge ring |
| 霊 SPIRIT | 90s cel-anime night sky in violet, sparkle glints, pink and cyan, a glowing ball of light for today, the year as a filling moon |
| 鋼 STEEL | Near-black iron with grit and a teal haze, bone and blood red, a sword slash (or splash) for today, the year as a riveted iron dial |
| 電脳 CYBER | Dark HUD glass with scanlines and a fine grid, cyan, magenta and amber, a lock-on reticle for today, the year as a HUD ring |

The app, the week widget and the month widget can each use a different theme.

## Features

- **Japanese or English** for the app and both widgets. Tap 日 / EN on either widget or at the top of the app.
- **Japanese calendar**: 令和 era years in kanji numerals, kanji months and traditional names (神無月), 日月火水木金土 weekdays.
- **Holidays**: Japanese public holidays and US holidays (federal holidays plus Valentine's, Easter, Mother's and Father's Day, Halloween, Christmas Eve, New Year's Eve), each named in both languages. Choose Japan, US or Both.
- **Widget backgrounds**: Clear, Theme (the theme's own backdrop), Glass, Blur. Android widgets can't blur the wallpaper behind them, so Blur is drawn as frosted glass.
- **Readability**: larger, heavier labels, a soft shadow on text over the wallpaper, and a **Bold text** option.
- **Settings**: theme, per-widget theme, theme icon for today, dates on the dots, dots or squares, custom dot colours (Auto follows the theme), widget text colour, live widget preview.

## Building with GitHub (phone only)

The build script in `.github/workflows/` unzips `DotCalendar.zip` and builds the APK. To update: upload a new `DotCalendar.zip` (same name), wait for the green check under Actions, then download `app-release.apk` from the newest release.

The app is signed with a permanent key (`app/dotcalendar.keystore`), so new versions install over the old one.

## Changing things in code

- Theme colours: `render/ThemeSpecs.java`
- Drawing (shared by app and widgets): `render/Renderer.java`
- Theme fonts: `ThemeFonts` in `RenderBridge.kt`
- Text in both languages: `Tx.kt`
- Holidays: `JapaneseHolidays.kt` (current law; accurate from 2022 onward) and `Holidays.kt` (US)

## Fonts

Yuji Boku, Yuji Syuku, Caveat Brush, Dela Gothic One, Bangers, RocknRoll One, Righteous, Zen Antique, Pirata One, DotGothic16, Orbitron (SIL Open Font License) and Permanent Marker (Apache 2.0), subset to the characters the app uses. Licenses are in `licenses/`.
