# Dot Calendar

A month-of-dots calendar with Japanese dates (令和 era years, kanji weekdays, traditional month names, public holidays), plus two home-screen widgets.

## Dots

| Dot | Meaning |
| --- | --- |
| Green, filled | Days that have passed |
| Orange, filled | Today |
| Red ring | Upcoming Sundays and Japanese public holidays |
| Gray ring | Other upcoming days |

## Widgets

- **Week** (4×1): this week, Sunday to Saturday, with 日月火水木金土 labels. Make it taller and it adds today's date and era year.
- **Month** (4×4): the whole month with day numbers, month name (e.g. 10月 神無月) and era year.

Both resize, follow light/dark mode, open the app when tapped, and turn over automatically after midnight.

## Install on your phone

1. Install [Android Studio](https://developer.android.com/studio) (free).
2. Unzip this folder, then in Android Studio choose **File → Open** and pick the `DotCalendar` folder. Let it finish syncing (first time takes a few minutes; it downloads what it needs).
3. On your phone: **Settings → About phone**, tap **Build number** 7 times to unlock Developer options, then turn on **USB debugging** in Developer options.
4. Plug the phone in, pick it in the device menu at the top of Android Studio, and press the green **Run ▶** button.
5. Long-press your home screen → **Widgets** → **Dot Calendar** to add the week or month widget.

To get an APK file instead: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.

## Changing things

- **Colors:** `app/src/main/res/values/colors.xml` (widgets) and `DotColors` in `DotState.kt` (app).
- **What each dot means:** `DotState.of()` in `DotState.kt`.
- **Holidays:** `JapaneseHolidays.kt`. Follows current law, so it's accurate from 2022 onward.
