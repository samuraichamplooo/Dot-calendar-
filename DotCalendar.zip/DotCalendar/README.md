# Dot Calendar · ドット暦

A minimal dot calendar with Japanese dates, Japanese and US holidays, week, month and year widgets, and eight swappable themes.

## Themes

| Theme | Look |
| --- | --- |
| 浪人 RONIN | Grey grainy poster paper, flat ukiyo-e colours (vermilion, indigo, bone), brush kanji, marker lettering, a white cloud, a 🌻 for today, the year as a vinyl record |
| 墨 SUMI | Black ink on grainy paper under a soft spotlight, ink-blot dots, a brush ensō for today, the year painted as an ensō |
| 侍 SAMURAI | Black urushi lacquer with faint crimson-laced armour plates and gold dust, gold-leaf dots, a katana under every title, a helmet (or crossed katanas) for today, the year as a sword guard |
| 気 KI | Deep blue with manga speed lines, hot orange and yellow, an energy wave (or burst) for today, the year as a power-gauge ring |
| 霊 SPIRIT | 90s cel-anime night sky in deep teal and blue, sparkle glints, a glowing ball of light for today (ice, jade, sapphire, amethyst, gold, sakura or crimson; bright or subtle glow), the year as a filling moon |
| 鋼 STEEL | Near-black iron with grit and a teal haze, bone and blood red, a sword slash (or splash) for today, the year as a riveted iron dial |
| 電脳 CYBER | Dark HUD glass with scanlines and a fine grid, teal and lime green, a lock-on reticle for today, the year as a HUD ring |
| 宇宙 COSMO | Retro space jazz: charcoal night with stars, a faint ringed planet and flat 70s colour bars, mustard dots, orange and teal, a rocket 🚀 for today, the year as an orbit |

The app and each widget (week, month, year) can use a different theme.

## Features

- **Settings** are a short menu (Theme, Widgets, Weekdays, Dots, Language & dates, Calendar extras) under a live widget preview, and read in Japanese and English at the same time.

- **Japanese or English** for the app and all widgets. Tap 日 / EN on either widget or at the top of the app. The widget button can be hidden for a cleaner look.
- **Japanese date style**: 10.14 with 令和八年 (standard), 令和8年10月14日, or just 10月14日.
- **Year widget**: every day of the year as a dot, one row per month, with how far through the year you are.
- **My dates**: add birthdays, trips or exams on the main screen. They get a coloured ring on the calendar, and the widgets count down to the next one (期末試験まであと12日 / Finals · in 12 days). Birthdays can repeat every year.
- **Phone calendar**: optional small mark under days that have events in the phone's calendars. Only dates are read, never event details. Needs calendar permission.
- **六曜 and 二十四節気**: optional, shown under today's date (大安 · 寒露). 六曜 uses Android's built-in lunar calendar and can, rarely, differ by a day from printed Japanese calendars.
- **Japanese calendar**: 令和 era years in kanji numerals, kanji months and traditional names (神無月), 日月火水木金土 weekdays.
- **Holidays**: Japanese public holidays and US holidays (federal holidays plus Valentine's, Easter, Mother's and Father's Day, Halloween, Christmas Eve, New Year's Eve), each named in both languages. Choose Japan, US or Both.
- **Widget look** (top of Settings, right under the preview): background, text colour, **text size** (Small, Medium, Large), and a **week-only** layout for the week widget (just the weekday row and dots, no date on the left).
- **Weekdays**: label size (Extra small to Large), font (Standard, Theme, Manga, Racing) and colours for today, Sundays & holidays, Saturdays and the other days. These stay the same when you change theme.
- **Pulsing today** (optional): a soft glow round today on the widgets slowly brightens and fades. Widgets can't animate on their own, so a small ViewFlipper (`res/layout/pulse_glow.xml`) cross-fades the glow frame in and out on the home screen.
- **Turning sunflower** (optional, Ronin theme): today's sunflower slowly turns on the widgets, about once every 20 seconds. Twenty small frames go into a ViewFlipper (`res/layout/spin_flipper.xml`); each one fades out over the next.
- **Text shadow**: Normal, Soft or Off. Coloured weekday labels only ever get a thin dark shadow, never a light halo.
- **Wallpaper: Dark / Light / Auto** (Widgets → Background): Light turns the widget text, weekdays and dots dark for white or pale wallpapers and makes Glass and Blur pale. Auto asks Android how bright the wallpaper is (Android 8.1+), picks light or dark to match, and always adds extra contrast. It looks again every 30 minutes and whenever the app opens. Wallpapers Android can't read (some live wallpapers) are treated as dark.
- **Extra contrast**: a soft shade behind each dot and weekday, a thin outline round the dots and a stronger text shadow, so the widget stands out on busy photos. Very dark text colours are brightened a little while it's on. Always on in Auto.
- **Widget backgrounds**: Transparent, Blur, Glass, Solid (the theme's own backdrop), each shown as a picture tile. Android widgets can't blur the wallpaper behind them, so Blur is drawn as frosted glass.
- **Readability**: larger, heavier labels, a soft shadow on text over the wallpaper, and a **Bold text** option.
- **Settings**: theme, per-widget theme, theme icon for today, dates on the dots, dots or squares, custom dot colours (Auto follows the theme), widget text colour, live widget preview.

## Building with GitHub (phone only)

The build script in `.github/workflows/` unzips `DotCalendar.zip` and builds the APK. To update: upload a new `DotCalendar.zip` (same name), wait for the green check under Actions, then download `app-release.apk` from the newest release.

The app is signed with a permanent key (`app/dotcalendar.keystore`), so new versions install over the old one.

## Changing things in code

- Theme colours: `render/ThemeSpecs.java`
- Drawing (shared by app and widgets): `render/Renderer.java`
- Theme fonts: `ThemeFonts` in `RenderBridge.kt`
- Widget text sizes: `WidgetTextSize` in `Settings.kt`
- Text in both languages: `Tx.kt`
- Holidays: `JapaneseHolidays.kt` (current law; accurate from 2022 onward) and `Holidays.kt` (US)
- 六曜 and 二十四節気: `Koyomi.kt`
- My dates: `MyDates.kt`; phone calendar: `PhoneCalendar.kt`

## Fonts

Yuji Boku, Yuji Syuku, Shippori Mincho B1, Cinzel, Mochiy Pop One, Shrikhand, Potta One, Murecho, Racing Sans One, Caveat Brush, Dela Gothic One, Bangers, RocknRoll One, Righteous, Zen Antique, Pirata One, DotGothic16, Orbitron (SIL Open Font License) and Permanent Marker (Apache 2.0), subset to the characters the app uses. Licenses are in `licenses/`.
