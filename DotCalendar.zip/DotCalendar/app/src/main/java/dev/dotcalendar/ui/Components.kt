package dev.dotcalendar.ui

import android.graphics.RectF
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.dotcalendar.Defaults
import dev.dotcalendar.Fonts
import dev.dotcalendar.Lang
import dev.dotcalendar.render.Day
import dev.dotcalendar.render.Renderer

/** A Compose canvas that hands the shared renderer a native canvas measured in dp. */
@Composable
fun RenderCanvas(modifier: Modifier, draw: (android.graphics.Canvas, Float, Float) -> Unit) {
    Canvas(modifier) {
        val k = density
        drawIntoCanvas { c ->
            val nc = c.nativeCanvas
            val save = nc.save()
            nc.scale(k, k)
            draw(nc, size.width / k, size.height / k)
            nc.restoreToCount(save)
        }
    }
}

/** Vermilion hanko seal. */
@Composable
fun SealMark(size: Dp, glyph: String = "暦") {
    val context = LocalContext.current
    val brush = remember { Fonts.brush(context) }
    RenderCanvas(Modifier.size(size)) { c, w, h -> Renderer.drawSeal(c, RectF(0f, 0f, w, h), glyph, brush) }
}

/** A title with a vermilion ink-brush swipe under it. */
@Composable
fun BrushTitle(text: String, fontSize: TextUnit, modifier: Modifier = Modifier) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    Box(modifier) {
        RenderCanvas(Modifier.matchParentSize()) { c, w, h ->
            Renderer.drawBrushStroke(c, 0f, h * 0.84f, w + 6f, (h * 0.11f).coerceIn(3f, 6f), Renderer.withAlpha(Renderer.SEAL, 0.9f), 7L)
        }
        Text(
            text,
            fontFamily = titleFont(tx.ja),
            fontSize = fontSize,
            color = pal.text,
            modifier = Modifier.padding(end = 6.dp),
        )
    }
}

/** One day drawn exactly as on the calendar. */
@Composable
fun DaySample(state: Int, number: Int, size: Dp) {
    val style = LocalAppStyle.current
    RenderCanvas(Modifier.size(size)) { c, w, h ->
        Renderer.drawDay(c, w / 2f, h / 2f, w, Day(number, state), style, false)
    }
}

/** Flat rounded card. */
@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPalette.current
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(pal.panel)
            .padding(16.dp),
        content = content,
    )
}

/** Heading in the current language, with the other language small beside it. */
@Composable
fun SectionTitle(ja: String, en: String) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (tx.ja) {
            Text(ja, fontFamily = BrushFont, fontSize = 18.sp, color = pal.text)
            Spacer(Modifier.width(8.dp))
            Text(en.uppercase(), fontFamily = UiFont, fontSize = 10.sp, color = pal.sub, letterSpacing = 1.5.sp)
        } else {
            Text(en.uppercase(), fontFamily = UiFont, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = pal.text, letterSpacing = 1.5.sp)
            Spacer(Modifier.width(8.dp))
            Text(ja, fontFamily = BrushFont, fontSize = 13.sp, color = pal.sub)
        }
    }
    Spacer(Modifier.height(12.dp))
}

@Composable
fun Label(ja: String, en: String) {
    val tx = LocalTx.current
    Text(
        if (tx.ja) ja else en,
        fontFamily = UiFont,
        fontSize = 12.sp,
        color = LocalPalette.current.sub,
        modifier = Modifier.padding(top = 4.dp, bottom = 6.dp),
    )
}

/** Flat rounded button. Selected ones fill with the accent colour, like the lit keys in your launcher. */
@Composable
fun FlatButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    fontFamily: FontFamily = UiFont,
    fontSize: TextUnit = 14.sp,
) {
    val pal = LocalPalette.current
    val accent = LocalSettings.current.today
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .heightIn(min = 44.dp)
            .clip(shape)
            .background(if (selected) Color(accent) else pal.button)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            fontFamily = fontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = fontSize,
            color = if (selected) Color(Renderer.contrastOn(accent)) else pal.text,
            maxLines = 1,
        )
    }
}

@Composable
fun FlatIconButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    val pal = LocalPalette.current
    Box(
        Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(pal.panel)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = pal.text)
    }
}

/** A row (or grid) of buttons where exactly one is selected. */
@Composable
fun SegmentGrid(options: List<String>, selected: Int, columns: Int = options.size, onSelect: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.chunked(columns).forEachIndexed { r, row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEachIndexed { c, label ->
                    val index = r * columns + c
                    FlatButton(label, { onSelect(index) }, Modifier.weight(1f), selected = index == selected)
                }
                repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPalette.current
    val accent = Color(LocalSettings.current.today)
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontFamily = UiFont, fontSize = 14.sp, color = pal.text, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = accent,
                checkedBorderColor = accent,
                uncheckedThumbColor = pal.sub,
                uncheckedTrackColor = pal.button,
                uncheckedBorderColor = pal.button,
            ),
        )
    }
}

/** 日 / EN switch. Tap to flip. */
@Composable
fun LangSwitch(lang: Lang, onToggle: () -> Unit) {
    val style = LocalAppStyle.current
    val label = if (lang == Lang.JA) "言語: 日本語。タップで英語に切り替え" else "Language: English. Tap for Japanese"
    RenderCanvas(
        Modifier
            .size(68.dp, 32.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onToggle)
            .semantics { contentDescription = label },
    ) { c, w, h ->
        Renderer.drawLangChip(c, RectF(1f, 1f, w - 1f, h - 1f), lang == Lang.JA, style, false)
    }
}

/** Swatches plus hue / saturation / brightness sliders. */
@Composable
fun ColorPicker(color: Int, onPick: (Int) -> Unit) {
    val pal = LocalPalette.current
    val tx = LocalTx.current
    Column {
        Defaults.SWATCHES.chunked(5).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                row.forEach { swatch ->
                    val selected = swatch == color
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .border(if (selected) 2.dp else 0.dp, if (selected) pal.text else Color.Transparent, CircleShape)
                            .padding(if (selected) 5.dp else 3.dp)
                            .clip(CircleShape)
                            .background(Color(swatch))
                            .clickable { onPick(swatch) },
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        val hsv = FloatArray(3).also { android.graphics.Color.colorToHSV(color, it) }
        Box(
            Modifier
                .padding(start = 92.dp, top = 4.dp)
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red),
                    ),
                ),
        )
        HsvSlider(tx.t("色相", "Hue"), hsv[0], 0f..360f, Color(color)) {
            onPick(android.graphics.Color.HSVToColor(floatArrayOf(it, hsv[1], hsv[2])))
        }
        HsvSlider(tx.t("彩度", "Saturation"), hsv[1], 0f..1f, Color(color)) {
            onPick(android.graphics.Color.HSVToColor(floatArrayOf(hsv[0], it, hsv[2])))
        }
        HsvSlider(tx.t("明るさ", "Brightness"), hsv[2], 0f..1f, Color(color)) {
            onPick(android.graphics.Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], it)))
        }
    }
}

@Composable
private fun HsvSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, track: Color, onChange: (Float) -> Unit) {
    val pal = LocalPalette.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontFamily = UiFont, fontSize = 12.sp, color = pal.sub, modifier = Modifier.width(92.dp))
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = track,
                activeTrackColor = track,
                inactiveTrackColor = pal.button,
            ),
        )
    }
}

/** A tappable colour setting that expands into a picker, optionally with an Auto choice. */
@Composable
fun ColorRow(
    label: String,
    color: Int,
    expanded: Boolean,
    onToggle: () -> Unit,
    onPick: (Int) -> Unit,
    sampleState: Int? = null,
    isAuto: Boolean = false,
    onAuto: (() -> Unit)? = null,
) {
    val pal = LocalPalette.current
    val tx = LocalTx.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onToggle)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (sampleState != null) {
            DaySample(sampleState, 13, 34.dp)
        } else {
            Box(
                Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(Color(color)),
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(label, fontFamily = UiFont, fontSize = 14.sp, color = pal.text, modifier = Modifier.weight(1f))
        Text(
            if (isAuto) tx.t("自動", "Auto") else String.format("#%06X", color and 0xFFFFFF),
            fontFamily = UiFont,
            fontSize = 12.sp,
            color = pal.sub,
        )
        Spacer(Modifier.width(8.dp))
        Text(if (expanded) "▲" else "▼", fontSize = 11.sp, color = pal.sub)
    }
    AnimatedVisibility(visible = expanded) {
        Column(Modifier.padding(top = 8.dp, bottom = 6.dp)) {
            if (onAuto != null) {
                FlatButton(tx.t("自動（テーマに合わせる）", "Auto (match theme)"), onAuto, Modifier.fillMaxWidth(), selected = isAuto)
                Spacer(Modifier.height(12.dp))
            }
            ColorPicker(color, onPick)
        }
    }
}
