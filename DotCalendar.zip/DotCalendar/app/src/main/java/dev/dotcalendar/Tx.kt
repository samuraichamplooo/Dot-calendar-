package dev.dotcalendar

import java.time.LocalDate
import java.time.YearMonth

/** All user-facing text, in Japanese or English. */
class Tx(val lang: Lang, val dateStyle: JaDateStyle = JaDateStyle.STANDARD) {
    /** Japanese era years with ordinary numbers (令和8年) instead of kanji numerals (令和八年). */
    val shortJa: Boolean get() = dateStyle != JaDateStyle.STANDARD
    val ja: Boolean get() = lang == Lang.JA

    fun t(ja: String, en: String): String = if (this.ja) ja else en

    val weekdays: List<String>
        get() = if (ja) JapaneseCalendar.WEEKDAYS_JA else listOf("SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT")

    /** Weekday heads: kanji for Japanese, three letters for English (shortened to two when tight). */
    val weekdayInitials: List<String>
        get() = if (ja) JapaneseCalendar.WEEKDAYS_JA else listOf("SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT")

    /** 令和八年 (or 令和8年 in short form) / REIWA 8 · 2026 */
    fun eraLine(date: LocalDate): String =
        if (ja) eraJa(date) else "${JapaneseCalendar.eraYearRomaji(date)} · ${date.year}"

    private fun eraJa(date: LocalDate): String =
        if (shortJa) JapaneseCalendar.eraYear(date) else JapaneseCalendar.eraYearKanji(date)

    /** 10月14日 / OCT 14 */
    fun monthDay(date: LocalDate): String =
        if (ja) "${date.monthValue}月${date.dayOfMonth}日" else "${EN_MONTHS[date.monthValue - 1].take(3).uppercase()} ${date.dayOfMonth}"

    /** Countdown to one of the user's dates: 期末試験まであと12日 / Finals · in 12 days */
    fun countdown(name: String, days: Long): String =
        if (ja) {
            when (days) {
                0L -> "今日は$name"
                1L -> "明日は$name"
                else -> "${name}まであと${days}日"
            }
        } else {
            when (days) {
                0L -> "$name · today"
                1L -> "$name · tomorrow"
                else -> "$name · in $days days"
            }
        }

    /** Short "in N days" for lists: あと12日 / in 12 days */
    fun daysAway(days: Long): String =
        if (ja) {
            when (days) {
                0L -> "今日"
                1L -> "明日"
                else -> "あと${days}日"
            }
        } else {
            when (days) {
                0L -> "Today"
                1L -> "Tomorrow"
                else -> "in $days days"
            }
        }

    /** 令和8年10月14日 / REIWA 8 · OCT 14 */
    fun eraDate(date: LocalDate): String =
        if (ja) "${JapaneseCalendar.eraYear(date)}${date.monthValue}月${date.dayOfMonth}日"
        else "${JapaneseCalendar.eraYearRomaji(date)} · ${EN_MONTHS[date.monthValue - 1].take(3).uppercase()} ${date.dayOfMonth}"

    /** 十月 / OCTOBER */
    fun monthTitle(month: Int): String =
        if (ja) JapaneseCalendar.kanjiMonth(month) else EN_MONTHS[month - 1].uppercase()

    /** 神無月 / KANNAZUKI */
    fun monthSubtitle(month: Int): String =
        if (ja) JapaneseCalendar.traditionalMonth(month) else JapaneseCalendar.traditionalRomaji(month).uppercase()

    /** 令和8年 / REIWA 8 */
    fun eraYear(date: LocalDate): String =
        if (ja) JapaneseCalendar.eraYear(date) else JapaneseCalendar.eraYearRomaji(date)

    /** 令和8年 2026 / 2026 REIWA 8 */
    fun lcdYear(date: LocalDate): String =
        if (ja) "${JapaneseCalendar.eraYear(date)} ${date.year}" else "${date.year} ${JapaneseCalendar.eraYearRomaji(date)}"

    /** 令和8年10月13日（火） / TUE 13 OCT 2026 */
    fun fullDate(date: LocalDate): String =
        if (ja) "${JapaneseCalendar.eraYear(date)}${date.monthValue}月${date.dayOfMonth}日（${JapaneseCalendar.weekdayKanji(date)}）"
        else "${weekdays[date.dayOfWeek.value % 7]} ${date.dayOfMonth} ${EN_MONTHS[date.monthValue - 1].take(3).uppercase()} ${date.year}"

    /** 10月12日（月） / MON 12 OCT */
    fun shortDate(date: LocalDate): String =
        if (ja) "${date.monthValue}月${date.dayOfMonth}日（${JapaneseCalendar.weekdayKanji(date)}）"
        else "${weekdays[date.dayOfWeek.value % 7]} ${date.dayOfMonth} ${EN_MONTHS[date.monthValue - 1].take(3).uppercase()}"

    /** 火曜日 / TUESDAY */
    fun dayName(date: LocalDate): String =
        if (ja) "${JapaneseCalendar.weekdayKanji(date)}曜日" else EN_DAYS[date.dayOfWeek.value % 7].uppercase()

    /** Month line under the title, e.g. 神無月 · 令和八年 / KANNAZUKI · 2026 */
    fun monthLine(month: YearMonth): String =
        if (ja) "${JapaneseCalendar.traditionalMonth(month.monthValue)} · ${eraJa(month.atEndOfMonth())}"
        else "${JapaneseCalendar.traditionalRomaji(month.monthValue).uppercase()} · ${month.year}"

    /** Short weekday: 火 / TUE */
    fun weekdayShort(date: LocalDate): String =
        if (ja) JapaneseCalendar.weekdayKanji(date) else weekdays[date.dayOfWeek.value % 7]

    fun holiday(japaneseName: String): String = if (ja) japaneseName else HOLIDAYS_EN[japaneseName] ?: japaneseName

    companion object {
        private val EN_MONTHS = listOf(
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December",
        )
        private val EN_DAYS = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")

        val HOLIDAYS_EN = mapOf(
            "元日" to "New Year's Day",
            "成人の日" to "Coming of Age Day",
            "建国記念の日" to "National Foundation Day",
            "天皇誕生日" to "Emperor's Birthday",
            "春分の日" to "Vernal Equinox Day",
            "昭和の日" to "Showa Day",
            "憲法記念日" to "Constitution Day",
            "みどりの日" to "Greenery Day",
            "こどもの日" to "Children's Day",
            "海の日" to "Marine Day",
            "山の日" to "Mountain Day",
            "敬老の日" to "Respect for the Aged Day",
            "秋分の日" to "Autumnal Equinox Day",
            "スポーツの日" to "Sports Day",
            "文化の日" to "Culture Day",
            "勤労感謝の日" to "Labor Thanksgiving Day",
            "振替休日" to "Substitute Holiday",
            "国民の休日" to "Citizens' Holiday",
        )
    }
}
