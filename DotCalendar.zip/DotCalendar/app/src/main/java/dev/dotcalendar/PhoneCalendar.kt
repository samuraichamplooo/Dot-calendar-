package dev.dotcalendar

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset

/** Reads which days have events in the phone's calendars (Google Calendar and others). */
object PhoneCalendar {

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    /** Days between [from] and [to] (inclusive) that have at least one event in a visible calendar. */
    fun eventDays(context: Context, from: LocalDate, to: LocalDate): Set<LocalDate> {
        if (!hasPermission(context)) return emptySet()
        val zone = ZoneId.systemDefault()
        val begin = from.atStartOfDay(zone).toInstant().toEpochMilli()
        val end = to.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(builder, begin)
        ContentUris.appendId(builder, end)
        val projection = arrayOf(
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.ALL_DAY,
        )
        val out = HashSet<LocalDate>()
        try {
            context.contentResolver.query(
                builder.build(),
                projection,
                "${CalendarContract.Instances.VISIBLE} = 1",
                null,
                null,
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val b = cursor.getLong(0)
                    val e = cursor.getLong(1)
                    val allDay = cursor.getInt(2) == 1
                    // All-day events are stored at UTC midnight; timed ones in local time.
                    val z: ZoneId = if (allDay) ZoneOffset.UTC else zone
                    var d = Instant.ofEpochMilli(b).atZone(z).toLocalDate()
                    val last = Instant.ofEpochMilli(maxOf(b, e - 1)).atZone(z).toLocalDate()
                    var guard = 0
                    while (!d.isAfter(last) && guard < 400) {
                        if (!d.isBefore(from) && !d.isAfter(to)) out.add(d)
                        d = d.plusDays(1)
                        guard++
                    }
                }
            }
        } catch (e: Exception) {
            // No calendar provider, or permission revoked mid-read: just show no marks.
        }
        return out
    }
}
