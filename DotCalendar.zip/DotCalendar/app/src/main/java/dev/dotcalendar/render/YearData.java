package dev.dotcalendar.render;

/** The whole year as twelve rows of days, already in the chosen language. */
public final class YearData {
    public String title = "";        // 2026年 / 2026
    public String subtitle = "";     // 令和八年 / REIWA 8
    public String progress = "";     // 287 / 365 · 79%
    public String[] monthLabels = new String[12];
    public Day[][] months = new Day[12][];
    public boolean japanese = true;
}
