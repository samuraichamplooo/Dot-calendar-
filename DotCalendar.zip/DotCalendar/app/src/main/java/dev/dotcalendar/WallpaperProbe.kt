package dev.dotcalendar

import android.app.WallpaperColors
import android.app.WallpaperManager
import android.content.Context
import android.os.Build
import android.os.SystemClock

/**
 * Asks Android whether the home-screen wallpaper is light or dark, for the Auto wallpaper setting.
 *
 * Android 12+ says outright whether the wallpaper suits dark text. Android 8.1–11 only gives the
 * wallpaper's main colours, so their brightness is judged here. Some live wallpapers report no
 * colours at all; then [light] is null and the widgets treat the wallpaper as dark (light text),
 * still with the extra contrast that Auto adds. No permission is needed for any of this.
 */
object WallpaperProbe {
    /** true = light wallpaper, false = dark, null = Android can't tell. */
    @Volatile
    var light: Boolean? = null
        private set

    @Volatile
    private var checkedAt = 0L

    /** Looks again, at most every few seconds (it's a quick call, but widgets redraw in bursts). */
    fun refresh(context: Context) {
        val now = SystemClock.elapsedRealtime()
        if (checkedAt != 0L && now - checkedAt < 5_000L) return
        checkedAt = now
        light = read(context)
    }

    private fun read(context: Context): Boolean? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O_MR1) return null
        return try {
            val colors = WallpaperManager.getInstance(context).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
                ?: return null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (colors.colorHints and WallpaperColors.HINT_SUPPORTS_DARK_TEXT) != 0
            } else {
                brightness(colors) > 0.62f
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Rough brightness from the wallpaper's main colours, the first one weighted most. */
    private fun brightness(colors: WallpaperColors): Float {
        val list = listOfNotNull(colors.primaryColor, colors.secondaryColor, colors.tertiaryColor)
        val weights = listOf(0.6f, 0.25f, 0.15f)
        var sum = 0f
        var total = 0f
        list.forEachIndexed { i, c ->
            val lum = 0.299f * c.red() + 0.587f * c.green() + 0.114f * c.blue()
            sum += lum * weights[i]
            total += weights[i]
        }
        return if (total > 0f) sum / total else 0f
    }
}
