package dev.dotcalendar

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import kotlin.math.floor

/**
 * Japanese public holidays (国民の祝日), computed from the rules in the Holidays Act,
 * including substitute holidays (振替休日) and sandwiched days (国民の休日).
 *
 * Follows the current law, so dates are accurate from 2022 onward. Years with one-off
 * changes (2019 enthronement, 2020–21 Olympics) and pre-2020 holiday names may differ.
 */
object JapaneseHolidays {

    private val cache = HashMap<Int, Map<LocalDate, String>>()

    @Synchronized
    fun forYear(year: Int): Map<LocalDate, String> = cache.getOrPut(year) { compute(year) }

    fun nameOf(date: LocalDate): String? = forYear(date.year)[date]

    fun isHoliday(date: LocalDate): Boolean = nameOf(date) != null

    private fun compute(y: Int): Map<LocalDate, String> {
        val base = sortedMapOf<LocalDate, String>()
        fun add(month: Int, day: Int, name: String) { base[LocalDate.of(y, month, day)] = name }
        fun monday(month: Int, nth: Int): LocalDate =
            LocalDate.of(y, month, 1).with(TemporalAdjusters.dayOfWeekInMonth(nth, DayOfWeek.MONDAY))

        add(1, 1, "元日")
        base[monday(1, 2)] = "成人の日"
        add(2, 11, "建国記念の日")
        if (y >= 2020) add(2, 23, "天皇誕生日")
        add(3, vernalEquinoxDay(y), "春分の日")
        add(4, 29, "昭和の日")
        add(5, 3, "憲法記念日")
        add(5, 4, "みどりの日")
        add(5, 5, "こどもの日")
        base[monday(7, 3)] = "海の日"
        add(8, 11, "山の日")
        base[monday(9, 3)] = "敬老の日"
        add(9, autumnalEquinoxDay(y), "秋分の日")
        base[monday(10, 2)] = "スポーツの日"
        add(11, 3, "文化の日")
        add(11, 23, "勤労感謝の日")

        val result = base.toSortedMap()

        // 国民の休日: an ordinary day sandwiched between two holidays.
        var d = LocalDate.of(y, 1, 2)
        while (d.year == y && d.monthValue < 12) {
            if (d !in base && d.dayOfWeek != DayOfWeek.SUNDAY &&
                d.minusDays(1) in base && d.plusDays(1) in base
            ) {
                result[d] = "国民の休日"
            }
            d = d.plusDays(1)
        }

        // 振替休日: a holiday on Sunday moves to the next day that isn't already a holiday.
        for (holiday in base.keys) {
            if (holiday.dayOfWeek == DayOfWeek.SUNDAY) {
                var next = holiday.plusDays(1)
                while (next in result) next = next.plusDays(1)
                result[next] = "振替休日"
            }
        }
        return result
    }

    // Standard approximation, valid 1980–2099.
    private fun vernalEquinoxDay(y: Int): Int =
        floor(20.8431 + 0.242194 * (y - 1980) - floor((y - 1980) / 4.0)).toInt()

    private fun autumnalEquinoxDay(y: Int): Int =
        floor(23.2488 + 0.242194 * (y - 1980) - floor((y - 1980) / 4.0)).toInt()
}
