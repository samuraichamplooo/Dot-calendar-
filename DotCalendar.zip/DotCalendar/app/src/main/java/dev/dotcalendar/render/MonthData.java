package dev.dotcalendar.render;

/** Text and day cells for a month, already in the chosen language. */
public final class MonthData {
    public String title = "";        // 十月 / OCTOBER
    public String subtitle = "";     // 神無月 / KANNAZUKI
    public String era = "";          // 令和8年 / REIWA 8 · 2026
    public String count = "";        // 13 / 31  (days passed this month)
    public String seal = "暦";
    public String[] weekdays = new String[7];
    public Day[][] weeks = new Day[0][];   // rows of 7, null for blank cells
    public int todayColumn = -1;           // weekday column of today, or -1
    public boolean japanese = true;
}
