package dev.dotcalendar.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import dev.dotcalendar.JapaneseCalendar
import dev.dotcalendar.JapaneseHolidays
import dev.dotcalendar.MainActivity
import dev.dotcalendar.R
import java.time.DayOfWeek
import java.time.LocalDate

/** Small widget: the current week, Sunday to Saturday. */
class WeekWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent { WeekContent() }
    }
}

@Composable
private fun WeekContent() {
    currentState(REFRESH_KEY) // re-render on refresh
    val today = LocalDate.now()
    val week = JapaneseCalendar.weekOf(today)

    val size = LocalSize.current
    val hPad = 12.dp
    val vPad = 8.dp
    val showTitle = size.height >= 100.dp
    val titleH = if (showTitle) 22.dp else 0.dp
    val labelH = 16.dp
    val cellW = (size.width - hPad * 2) / 7
    val dot = minOf(cellW * 0.82f, size.height - vPad * 2 - titleH - labelH - 4.dp)
        .coerceAtLeast(8.dp)

    Column(
        GlanceModifier
            .fillMaxSize()
            .background(ImageProvider(R.drawable.widget_bg))
            .padding(horizontal = hPad, vertical = vPad)
            .clickable(actionStartActivity<MainActivity>()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (showTitle) {
            Row(GlanceModifier.fillMaxWidth().height(titleH), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    JapaneseCalendar.shortDate(today),
                    style = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Bold, color = textPrimary),
                )
                Spacer(GlanceModifier.defaultWeight())
                Text(
                    JapaneseCalendar.eraYear(today),
                    style = TextStyle(fontSize = 12.sp, color = textSecondary),
                )
            }
        }
        Row(GlanceModifier.fillMaxWidth().defaultWeight(), verticalAlignment = Alignment.CenterVertically) {
            week.forEach { date ->
                val red = date.dayOfWeek == DayOfWeek.SUNDAY || JapaneseHolidays.isHoliday(date)
                Column(
                    GlanceModifier.defaultWeight().fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        JapaneseCalendar.weekdayKanji(date),
                        style = TextStyle(
                            fontSize = 11.sp,
                            color = if (red) textRed else textSecondary,
                            textAlign = TextAlign.Center,
                            fontWeight = if (date == today) FontWeight.Bold else FontWeight.Normal,
                        ),
                    )
                    Spacer(GlanceModifier.height(4.dp))
                    WidgetDot(date, today, dot)
                }
            }
        }
    }
}
