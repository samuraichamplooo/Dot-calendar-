package dev.dotcalendar

import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.floor
import kotlin.math.sin

/**
 * Traditional Japanese calendar details.
 *
 * 六曜 (rokuyō) comes from the lunisolar date: (lunar month + lunar day) mod 6.
 * The lunar date uses Android's built-in Chinese-calendar (旧暦) arithmetic; on rare days near a
 * new moon it can differ by a day from printed Japanese calendars.
 *
 * 二十四節気 (sekki) are found from the sun's apparent ecliptic longitude: a new term starts
 * each time it crosses a multiple of 15°, judged at midnight Japan time.
 */
object Koyomi {
    private val ROKUYO_JA = listOf("大安", "赤口", "先勝", "友引", "先負", "仏滅")
    private val ROKUYO_EN = listOf("Taian", "Shakkō", "Senshō", "Tomobiki", "Senbu", "Butsumetsu")

    // Index = floor(solar longitude / 15°), starting at the spring equinox.
    private val SEKKI_JA = listOf(
        "春分", "清明", "穀雨", "立夏", "小満", "芒種", "夏至", "小暑", "大暑", "立秋", "処暑", "白露",
        "秋分", "寒露", "霜降", "立冬", "小雪", "大雪", "冬至", "小寒", "大寒", "立春", "雨水", "啓蟄",
    )
    private val SEKKI_EN = listOf(
        "Spring Equinox", "Clear and Bright", "Grain Rain", "Start of Summer", "Grain Buds", "Grain in Ear",
        "Summer Solstice", "Minor Heat", "Major Heat", "Start of Autumn", "End of Heat", "White Dew",
        "Autumn Equinox", "Cold Dew", "Frost's Descent", "Start of Winter", "Minor Snow", "Major Snow",
        "Winter Solstice", "Minor Cold", "Major Cold", "Start of Spring", "Rain Water", "Awakening of Insects",
    )

    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")
    private val rokuyoCache = HashMap<LocalDate, Int>()

    /** 0..5 (大安, 赤口, 先勝, 友引, 先負, 仏滅), or -1 if it can't be worked out on this phone. */
    @Synchronized
    fun rokuyoIndex(date: LocalDate): Int = rokuyoCache.getOrPut(date) {
        try {
            val cal = android.icu.util.ChineseCalendar()
            cal.timeZone = android.icu.util.TimeZone.getTimeZone("Asia/Tokyo")
            cal.timeInMillis = date.atTime(12, 0).atZone(JST).toInstant().toEpochMilli()
            val month = cal.get(android.icu.util.Calendar.MONTH) + 1
            val day = cal.get(android.icu.util.Calendar.DAY_OF_MONTH)
            (month + day) % 6
        } catch (e: Exception) {
            -1
        }
    }

    fun rokuyo(date: LocalDate, ja: Boolean): String? {
        val i = rokuyoIndex(date)
        if (i < 0) return null
        return if (ja) ROKUYO_JA[i] else ROKUYO_EN[i]
    }

    /** The solar term period [date] falls in (0 = 春分 … 23 = 啓蟄). */
    fun sekkiIndex(date: LocalDate): Int = (floor(longitudeAt(date.plusDays(1)) / 15.0).toInt()) % 24

    /** True on the day a new solar term begins. */
    fun isSekkiDay(date: LocalDate): Boolean =
        floor(longitudeAt(date) / 15.0).toInt() != floor(longitudeAt(date.plusDays(1)) / 15.0).toInt()

    fun sekki(date: LocalDate, ja: Boolean): String {
        val i = sekkiIndex(date)
        return if (ja) SEKKI_JA[i] else SEKKI_EN[i]
    }

    /** Sun's apparent longitude in degrees at midnight (Japan time) starting [date]. */
    private fun longitudeAt(date: LocalDate): Double {
        val ms = date.atStartOfDay(JST).toInstant().toEpochMilli()
        val jd = ms / 86_400_000.0 + 2_440_587.5
        val t = (jd - 2_451_545.0) / 36_525.0
        val l0 = 280.46646 + 36_000.76983 * t + 0.0003032 * t * t
        val m = Math.toRadians(357.52911 + 35_999.05029 * t - 0.0001537 * t * t)
        val c = (1.914602 - 0.004817 * t - 0.000014 * t * t) * sin(m) +
            (0.019993 - 0.000101 * t) * sin(2 * m) + 0.000289 * sin(3 * m)
        val omega = Math.toRadians(125.04 - 1934.136 * t)
        val lambda = l0 + c - 0.00569 - 0.00478 * sin(omega)
        return ((lambda % 360.0) + 360.0) % 360.0
    }
}
