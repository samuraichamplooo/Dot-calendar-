package dev.dotcalendar

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import dev.dotcalendar.render.Day
import dev.dotcalendar.render.MonthData
import dev.dotcalendar.render.Renderer
import dev.dotcalendar.render.Style
import dev.dotcalendar.render.WeekData
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Bundled fonts, loaded once. */
object Fonts {
    @Volatile private var brush: Typeface? = null
    @Volatile private var marker: Typeface? = null

    /** Japanese ink brush. */
    fun brush(context: Context): Typeface =
        brush ?: load(context, R.font.yuji_boku, Typeface.SERIF).also { brush = it }

    /** Hip-hop marker for English titles. */
    fun marker(context: Context): Typeface =
        marker ?: load(context, R.font.permanent_marker, Typeface.DEFAULT_BOLD).also { marker = it }

    /** The phone's clean sans, medium weight, for numbers and English labels. */
    val sans: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    private fun load(context: Context, id: Int, fallback: Typeface): Typeface =
        try {
            ResourcesCompat.getFont(context.applicationContext, id) ?: fallback
        } catch (e: Exception) {
            fallback
        }
}

/** Turns settings and dates into what the renderer draws. */
object RenderBridge {

    private const val PAPER_FUTURE = 0xFFCFC8BA.toInt()

    /** True when the surface behind the dots is light. */
    fun isLight(s: AppSettings, widget: Boolean): Boolean =
        s.body == Body.PAPER && (!widget || s.widgetBg != WidgetBg.CLEAR)

    fun autoPassed(s: AppSettings, widget: Boolean): Int =
        if (isLight(s, widget)) Renderer.INK else Renderer.OFF_WHITE

    fun autoFuture(s: AppSettings, widget: Boolean): Int =
        if (isLight(s, widget)) PAPER_FUTURE else Renderer.DIM

    fun autoWidgetText(s: AppSettings): Int =
        if (isLight(s, widget = true)) Renderer.INK_TEXT else Renderer.PAPER_TEXT

    fun widgetTextColor(s: AppSettings): Int = s.widgetText ?: autoWidgetText(s)

    fun appTextColor(s: AppSettings): Int =
        if (s.body == Body.PAPER) Renderer.INK_TEXT else Renderer.PAPER_TEXT

    fun style(context: Context, s: AppSettings, widget: Boolean): Style = Style().apply {
        passed = s.passed ?: autoPassed(s, widget)
        today = s.today
        holiday = s.holiday
        future = s.future ?: autoFuture(s, widget)
        squares = s.shape == DotShape.SQUARE
        numbers = s.numbers
        sunflower = s.sunflower
        paper = s.body == Body.PAPER
        background = when (s.widgetBg) {
            WidgetBg.SOLID -> Renderer.BG_SOLID
            WidgetBg.GLASS -> Renderer.BG_GLASS
            WidgetBg.BLUR -> Renderer.BG_BLUR
            WidgetBg.CLEAR -> Renderer.BG_CLEAR
        }
        opacity = s.widgetOpacity
        text = if (widget) widgetTextColor(s) else appTextColor(s)
        brush = Fonts.brush(context)
        sans = Fonts.sans
        marker = Fonts.marker(context)
    }

    fun dayState(date: LocalDate, today: LocalDate): Int = when {
        date == today -> Renderer.TODAY
        date < today -> Renderer.PASSED
        date.dayOfWeek == DayOfWeek.SUNDAY || JapaneseHolidays.isHoliday(date) -> Renderer.HOLIDAY
        else -> Renderer.FUTURE
    }

    fun month(month: YearMonth, today: LocalDate, lang: Lang): MonthData {
        val tx = Tx(lang)
        val data = MonthData()
        data.japanese = tx.ja
        data.title = tx.monthTitle(month.monthValue)
        data.subtitle = tx.monthSubtitle(month.monthValue)
        data.era = tx.eraLine(month.atEndOfMonth())
        val length = month.lengthOfMonth()
        val passed = when {
            YearMonth.from(today) == month -> today.dayOfMonth
            month.isBefore(YearMonth.from(today)) -> length
            else -> 0
        }
        data.count = "$passed / $length"
        data.weekdays = tx.weekdayInitials.toTypedArray()
        val grid = JapaneseCalendar.monthWeeks(month)
        data.weeks = Array(grid.size) { r ->
            val row = arrayOfNulls<Day>(7)
            for (c in 0 until 7) {
                val d = grid[r][c]
                if (d != null) row[c] = Day(d.dayOfMonth, dayState(d, today))
            }
            row
        }
        data.todayColumn = if (YearMonth.from(today) == month) today.dayOfWeek.value % 7 else -1
        return data
    }

    fun week(today: LocalDate, lang: Lang): WeekData {
        val tx = Tx(lang)
        val data = WeekData()
        data.japanese = tx.ja
        data.bigDate = "${today.monthValue}.${today.dayOfMonth}"
        data.dayName = tx.dayName(today)
        data.extra = JapaneseHolidays.nameOf(today)?.let { tx.holiday(it) } ?: tx.eraLine(today)
        data.weekdays = tx.weekdayInitials.toTypedArray()
        JapaneseCalendar.weekOf(today).forEachIndexed { i, d ->
            data.days[i] = Day(d.dayOfMonth, dayState(d, today))
            data.redLabels[i] = d.dayOfWeek == DayOfWeek.SUNDAY || JapaneseHolidays.isHoliday(d)
            if (d == today) data.todayIndex = i
        }
        return data
    }

    fun monthWidgetBitmap(context: Context, s: AppSettings, today: LocalDate, wDp: Float, hDp: Float): Bitmap {
        val style = style(context, s, widget = true)
        val data = month(YearMonth.from(today), today, s.lang)
        return bitmap(context, wDp, hDp) { Renderer.drawMonthWidget(it, wDp, hDp, style, data) }
    }

    fun weekWidgetBitmap(context: Context, s: AppSettings, today: LocalDate, wDp: Float, hDp: Float): Bitmap {
        val style = style(context, s, widget = true)
        val data = week(today, s.lang)
        return bitmap(context, wDp, hDp) { Renderer.drawWeekWidget(it, wDp, hDp, style, data) }
    }

    /** A bitmap sized for the screen, capped so a big widget stays within Android's widget memory limit. */
    private fun bitmap(context: Context, wDp: Float, hDp: Float, draw: (Canvas) -> Unit): Bitmap {
        val metrics = context.resources.displayMetrics
        var k = metrics.density
        // Android limits widget bitmaps to about 1.5 screens of memory; stay well under it.
        val maxPixels = min(1_400_000f, metrics.widthPixels * metrics.heightPixels * 0.3f)
        val area = wDp * hDp * k * k
        if (area > maxPixels) k *= sqrt(maxPixels / area)
        val bmp = Bitmap.createBitmap(
            max(1, (wDp * k).roundToInt()),
            max(1, (hDp * k).roundToInt()),
            Bitmap.Config.ARGB_8888,
        )
        val canvas = Canvas(bmp)
        canvas.scale(k, k)
        draw(canvas)
        return bmp
    }
}
