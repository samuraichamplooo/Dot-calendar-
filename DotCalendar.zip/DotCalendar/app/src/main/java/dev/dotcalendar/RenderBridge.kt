package dev.dotcalendar

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import dev.dotcalendar.render.Day
import dev.dotcalendar.render.MonthData
import dev.dotcalendar.render.Renderer
import dev.dotcalendar.render.Style
import dev.dotcalendar.render.ThemeSpecs
import dev.dotcalendar.render.WeekData
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Which surface a style is for: the app itself or one of the widgets. */
enum class Surface { APP, WEEK, MONTH }

/** Font resources for each theme: Japanese display font and English display font. */
object ThemeFonts {
    fun jaRes(t: AppTheme): Int = when (t) {
        AppTheme.RONIN -> R.font.yuji_boku
        AppTheme.SUMI -> R.font.yuji_syuku
        AppTheme.KI -> R.font.dela_gothic_one
        AppTheme.REI -> R.font.rocknroll_one
        AppTheme.HAGANE -> R.font.zen_antique
        AppTheme.DENNOU -> R.font.dotgothic16
    }

    fun enRes(t: AppTheme): Int = when (t) {
        AppTheme.RONIN -> R.font.permanent_marker
        AppTheme.SUMI -> R.font.caveat_brush
        AppTheme.KI -> R.font.bangers
        AppTheme.REI -> R.font.righteous
        AppTheme.HAGANE -> R.font.pirata_one
        AppTheme.DENNOU -> R.font.orbitron_bold
    }
}

/** Bundled fonts, loaded once each. */
object Fonts {
    private val cache = HashMap<Int, Typeface>()

    @Synchronized
    private fun get(context: Context, id: Int, fallback: Typeface): Typeface =
        cache.getOrPut(id) {
            try {
                ResourcesCompat.getFont(context.applicationContext, id) ?: fallback
            } catch (e: Exception) {
                fallback
            }
        }

    fun titleJa(context: Context, t: AppTheme): Typeface = get(context, ThemeFonts.jaRes(t), Typeface.SERIF)
    fun titleEn(context: Context, t: AppTheme): Typeface = get(context, ThemeFonts.enRes(t), Typeface.DEFAULT_BOLD)

    /** The phone's clean sans for small text and numbers. */
    val label: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    val labelBold: Typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
}

/** Turns settings and dates into what the renderer draws. */
object RenderBridge {

    fun themeFor(s: AppSettings, surface: Surface): AppTheme = when (surface) {
        Surface.APP -> s.theme
        Surface.WEEK -> s.weekTheme ?: s.theme
        Surface.MONTH -> s.monthTheme ?: s.theme
    }

    fun isLightTheme(t: AppTheme): Boolean {
        val st = Style()
        ThemeSpecs.apply(st, t.id, false)
        return Renderer.luminance(st.surface) > 0.45f
    }

    /** Colours and options for a surface, without fonts. */
    fun colors(s: AppSettings, surface: Surface): Style {
        val widget = surface != Surface.APP
        val t = themeFor(s, surface)
        val st = Style()
        ThemeSpecs.apply(st, t.id, widget && s.widgetBg != WidgetBg.SOLID)
        s.passed?.let { st.passed = it }
        s.today?.let { st.today = it }
        s.holiday?.let { st.holiday = it }
        s.future?.let { st.future = it }
        st.squares = s.shape == DotShape.SQUARE
        st.numbers = s.numbers
        st.todayIcon = s.todayIcon
        st.todayAlt = when (t) {
            AppTheme.KI -> s.kiFlame
            AppTheme.HAGANE -> s.steelSlash
            else -> false
        }
        st.bold = s.boldText
        st.background = when (s.widgetBg) {
            WidgetBg.SOLID -> Renderer.BG_SOLID
            WidgetBg.GLASS -> Renderer.BG_GLASS
            WidgetBg.BLUR -> Renderer.BG_BLUR
            WidgetBg.CLEAR -> Renderer.BG_CLEAR
        }
        st.opacity = s.widgetOpacity
        if (widget) {
            s.widgetText?.let {
                st.text = it
                st.sub = Renderer.withAlpha(it, 0.82f)
            }
        }
        return st
    }

    fun style(context: Context, s: AppSettings, surface: Surface): Style {
        val st = colors(s, surface)
        val t = themeFor(s, surface)
        st.titleJa = Fonts.titleJa(context, t)
        st.titleEn = Fonts.titleEn(context, t)
        st.label = Fonts.label
        st.labelBold = Fonts.labelBold
        return st
    }

    /** The widget text colour the theme picks on its own (shown as "Auto" in Settings). */
    fun autoWidgetText(s: AppSettings): Int = colors(s.copy(widgetText = null), Surface.MONTH).text

    fun widgetTextColor(s: AppSettings): Int = s.widgetText ?: autoWidgetText(s)

    fun dayState(date: LocalDate, today: LocalDate, region: HolidayRegion): Int = when {
        date == today -> Renderer.TODAY
        date < today -> Renderer.PASSED
        date.dayOfWeek == DayOfWeek.SUNDAY || Holidays.isHoliday(date, region) -> Renderer.HOLIDAY
        else -> Renderer.FUTURE
    }

    fun month(month: YearMonth, today: LocalDate, lang: Lang, region: HolidayRegion): MonthData {
        val tx = Tx(lang)
        val data = MonthData()
        data.japanese = tx.ja
        data.title = tx.monthTitle(month.monthValue)
        data.subtitle = tx.monthSubtitle(month.monthValue)
        data.era = tx.eraLine(month.atEndOfMonth())
        val length = month.lengthOfMonth()
        val passed = when {
            YearMonth.from(today) == month -> today.dayOfMonth
            month.isBefore(YearMonth.from(today)) -> length
            else -> 0
        }
        data.count = "$passed / $length"
        data.weekdays = tx.weekdayInitials.toTypedArray()
        val grid = JapaneseCalendar.monthWeeks(month)
        data.weeks = Array(grid.size) { r ->
            val row = arrayOfNulls<Day>(7)
            for (c in 0 until 7) {
                val d = grid[r][c]
                if (d != null) row[c] = Day(d.dayOfMonth, dayState(d, today, region))
            }
            row
        }
        data.todayColumn = if (YearMonth.from(today) == month) today.dayOfWeek.value % 7 else -1
        return data
    }

    fun week(today: LocalDate, lang: Lang, region: HolidayRegion): WeekData {
        val tx = Tx(lang)
        val data = WeekData()
        data.japanese = tx.ja
        data.bigDate = "${today.monthValue}.${today.dayOfMonth}"
        data.dayName = tx.dayName(today)
        data.extra = Holidays.on(today, region).firstOrNull()?.let { if (tx.ja) it.nameJa else it.nameEn } ?: tx.eraLine(today)
        data.weekdays = tx.weekdayInitials.toTypedArray()
        JapaneseCalendar.weekOf(today).forEachIndexed { i, d ->
            data.days[i] = Day(d.dayOfMonth, dayState(d, today, region))
            data.redLabels[i] = d.dayOfWeek == DayOfWeek.SUNDAY || Holidays.isHoliday(d, region)
            if (d == today) data.todayIndex = i
        }
        return data
    }

    fun monthWidgetBitmap(context: Context, s: AppSettings, today: LocalDate, wDp: Float, hDp: Float): Bitmap {
        val style = style(context, s, Surface.MONTH)
        val data = month(YearMonth.from(today), today, s.lang, s.holidays)
        return bitmap(context, wDp, hDp) { Renderer.drawMonthWidget(it, wDp, hDp, style, data) }
    }

    fun weekWidgetBitmap(context: Context, s: AppSettings, today: LocalDate, wDp: Float, hDp: Float): Bitmap {
        val style = style(context, s, Surface.WEEK)
        val data = week(today, s.lang, s.holidays)
        return bitmap(context, wDp, hDp) { Renderer.drawWeekWidget(it, wDp, hDp, style, data) }
    }

    /** A bitmap sized for the screen, capped so a big widget stays within Android's widget memory limit. */
    private fun bitmap(context: Context, wDp: Float, hDp: Float, draw: (Canvas) -> Unit): Bitmap {
        val metrics = context.resources.displayMetrics
        var k = metrics.density
        // Android limits widget bitmaps to about 1.5 screens of memory; stay well under it.
        val maxPixels = min(1_400_000f, metrics.widthPixels * metrics.heightPixels * 0.3f)
        val area = wDp * hDp * k * k
        if (area > maxPixels) k *= sqrt(maxPixels / area)
        val bmp = Bitmap.createBitmap(
            max(1, (wDp * k).roundToInt()),
            max(1, (hDp * k).roundToInt()),
            Bitmap.Config.ARGB_8888,
        )
        val canvas = Canvas(bmp)
        canvas.scale(k, k)
        draw(canvas)
        return bmp
    }
}
