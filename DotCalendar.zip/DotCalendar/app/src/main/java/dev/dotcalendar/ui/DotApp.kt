package dev.dotcalendar.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import dev.dotcalendar.AppSettings
import dev.dotcalendar.Body
import dev.dotcalendar.RenderBridge
import dev.dotcalendar.Tx

private enum class Screen { MAIN, SETTINGS }

@Composable
fun DotApp(s: AppSettings, onChange: (AppSettings) -> Unit) {
    val context = LocalContext.current
    val pal = if (s.body == Body.PAPER) PaperPalette else DarkPalette
    val tx = remember(s.lang) { Tx(s.lang) }
    val appStyle = remember(s) { RenderBridge.style(context, s, widget = false) }
    var screen by rememberSaveable { mutableStateOf(Screen.MAIN) }
    BackHandler(enabled = screen == Screen.SETTINGS) { screen = Screen.MAIN }

    MaterialTheme(colorScheme = if (pal.paper) lightColorScheme() else darkColorScheme()) {
        CompositionLocalProvider(
            LocalPalette provides pal,
            LocalTx provides tx,
            LocalSettings provides s,
            LocalAppStyle provides appStyle,
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(pal.bg),
            ) {
                when (screen) {
                    Screen.MAIN -> MainScreen(s, onChange) { screen = Screen.SETTINGS }
                    Screen.SETTINGS -> SettingsScreen(s, onChange) { screen = Screen.MAIN }
                }
            }
        }
    }
}
