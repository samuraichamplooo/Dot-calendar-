package dev.dotcalendar.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import dev.dotcalendar.AppSettings
import dev.dotcalendar.RenderBridge
import dev.dotcalendar.Surface
import dev.dotcalendar.Tx

private enum class Screen { MAIN, SETTINGS }

@Composable
fun DotApp(s: AppSettings, onChange: (AppSettings) -> Unit) {
    val context = LocalContext.current
    val appStyle = remember(s) { RenderBridge.style(context, s, Surface.APP) }
    val pal = remember(appStyle) { paletteFor(appStyle) }
    val fonts = remember(s.theme) { fontsFor(s.theme) }
    val tx = remember(s.lang) { Tx(s.lang) }
    var screen by rememberSaveable { mutableStateOf(Screen.MAIN) }
    BackHandler(enabled = screen == Screen.SETTINGS) { screen = Screen.MAIN }

    MaterialTheme(colorScheme = if (pal.light) lightColorScheme() else darkColorScheme()) {
        CompositionLocalProvider(
            LocalPalette provides pal,
            LocalTx provides tx,
            LocalSettings provides s,
            LocalAppStyle provides appStyle,
            LocalFonts provides fonts,
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(pal.bg),
            ) {
                ThemeBackground(appStyle)
                when (screen) {
                    Screen.MAIN -> MainScreen(s, onChange) { screen = Screen.SETTINGS }
                    Screen.SETTINGS -> SettingsScreen(s, onChange) { screen = Screen.MAIN }
                }
            }
        }
    }
}
