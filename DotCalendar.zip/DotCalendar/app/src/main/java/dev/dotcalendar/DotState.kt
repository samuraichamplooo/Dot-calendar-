package dev.dotcalendar

import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.Color
import java.time.DayOfWeek
import java.time.LocalDate

/**
 * The four kinds of dot. Change the colors here (app) and in res/values/colors.xml (widgets).
 *
 *  PASSED  – green, filled   – days already gone
 *  TODAY   – orange, filled  – today
 *  HOLIDAY – red, ring       – upcoming Sundays and Japanese public holidays
 *  FUTURE  – gray, ring      – other upcoming days
 */
enum class DotState(@DrawableRes val widgetDrawable: Int) {
    PASSED(R.drawable.dot_passed),
    TODAY(R.drawable.dot_today),
    HOLIDAY(R.drawable.dot_holiday),
    FUTURE(R.drawable.dot_future);

    val filled: Boolean get() = this == PASSED || this == TODAY

    val color: Color
        get() = when (this) {
            PASSED -> DotColors.Green
            TODAY -> DotColors.Orange
            HOLIDAY -> DotColors.Red
            FUTURE -> DotColors.Gray
        }

    companion object {
        fun of(date: LocalDate, today: LocalDate): DotState = when {
            date == today -> TODAY
            date < today -> PASSED
            date.dayOfWeek == DayOfWeek.SUNDAY || JapaneseHolidays.isHoliday(date) -> HOLIDAY
            else -> FUTURE
        }
    }
}

object DotColors {
    val Green = Color(0xFF43A047)
    val Orange = Color(0xFFFB8C00)
    val Red = Color(0xFFE53935)
    val Gray = Color(0xFF9E9E9E)
}
