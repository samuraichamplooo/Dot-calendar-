package dev.dotcalendar

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

/** Which holidays the calendar marks. */
enum class HolidayRegion { JP, US, BOTH }

/** One holiday with names in both languages. */
data class Holiday(val date: LocalDate, val nameJa: String, val nameEn: String, val us: Boolean)

/**
 * US federal holidays plus widely kept days (Valentine's, Easter, Mother's and Father's Day,
 * Halloween, Christmas Eve, New Year's Eve). Shown on their calendar dates.
 */
object UsHolidays {
    private val cache = HashMap<Int, List<Holiday>>()

    @Synchronized
    fun forYear(y: Int): List<Holiday> = cache.getOrPut(y) { compute(y) }

    private fun compute(y: Int): List<Holiday> {
        fun nth(month: Int, dow: DayOfWeek, n: Int): LocalDate =
            LocalDate.of(y, month, 1).with(TemporalAdjusters.dayOfWeekInMonth(n, dow))
        fun last(month: Int, dow: DayOfWeek): LocalDate =
            LocalDate.of(y, month, 1).with(TemporalAdjusters.lastInMonth(dow))
        fun h(d: LocalDate, ja: String, en: String) = Holiday(d, ja, en, true)

        return listOf(
            h(LocalDate.of(y, 1, 1), "元日", "New Year's Day"),
            h(nth(1, DayOfWeek.MONDAY, 3), "キング牧師記念日", "Martin Luther King Jr. Day"),
            h(LocalDate.of(y, 2, 14), "バレンタインデー", "Valentine's Day"),
            h(nth(2, DayOfWeek.MONDAY, 3), "大統領の日", "Presidents' Day"),
            h(easter(y), "イースター", "Easter"),
            h(nth(5, DayOfWeek.SUNDAY, 2), "母の日", "Mother's Day"),
            h(last(5, DayOfWeek.MONDAY), "メモリアルデー", "Memorial Day"),
            h(nth(6, DayOfWeek.SUNDAY, 3), "父の日", "Father's Day"),
            h(LocalDate.of(y, 6, 19), "ジューンティーンス", "Juneteenth"),
            h(LocalDate.of(y, 7, 4), "独立記念日", "Independence Day"),
            h(nth(9, DayOfWeek.MONDAY, 1), "レイバー・デー", "Labor Day"),
            h(nth(10, DayOfWeek.MONDAY, 2), "コロンブス・デー／先住民の日", "Columbus / Indigenous Peoples' Day"),
            h(LocalDate.of(y, 10, 31), "ハロウィン", "Halloween"),
            h(LocalDate.of(y, 11, 11), "退役軍人の日", "Veterans Day"),
            h(nth(11, DayOfWeek.THURSDAY, 4), "感謝祭", "Thanksgiving"),
            h(LocalDate.of(y, 12, 24), "クリスマス・イブ", "Christmas Eve"),
            h(LocalDate.of(y, 12, 25), "クリスマス", "Christmas Day"),
            h(LocalDate.of(y, 12, 31), "大晦日", "New Year's Eve"),
        ).sortedBy { it.date }
    }

    /** Western Easter Sunday (anonymous Gregorian algorithm). */
    private fun easter(y: Int): LocalDate {
        val a = y % 19
        val b = y / 100
        val c = y % 100
        val d = b / 4
        val e = b % 4
        val f = (b + 8) / 25
        val g = (b - f + 1) / 3
        val h = (19 * a + b - d - g + 15) % 30
        val i = c / 4
        val k = c % 4
        val l = (32 + 2 * e + 2 * i - h - k) % 7
        val m = (a + 11 * h + 22 * l) / 451
        val month = (h + l - 7 * m + 114) / 31
        val day = ((h + l - 7 * m + 114) % 31) + 1
        return LocalDate.of(y, month, day)
    }
}

/** Japanese and US holidays together, filtered by the chosen region. */
object Holidays {

    private fun japanese(y: Int): List<Holiday> =
        JapaneseHolidays.forYear(y).map { (d, ja) -> Holiday(d, ja, Tx.HOLIDAYS_EN[ja] ?: ja, false) }

    fun forYear(y: Int, region: HolidayRegion): List<Holiday> = when (region) {
        HolidayRegion.JP -> japanese(y)
        HolidayRegion.US -> UsHolidays.forYear(y)
        HolidayRegion.BOTH -> (japanese(y) + UsHolidays.forYear(y)).sortedWith(compareBy({ it.date }, { it.us }))
    }

    fun forMonth(month: YearMonth, region: HolidayRegion): List<Holiday> =
        forYear(month.year, region).filter { YearMonth.from(it.date) == month }

    fun on(date: LocalDate, region: HolidayRegion): List<Holiday> =
        forYear(date.year, region).filter { it.date == date }

    fun isHoliday(date: LocalDate, region: HolidayRegion): Boolean = on(date, region).isNotEmpty()
}
