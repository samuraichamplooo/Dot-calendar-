package dev.dotcalendar

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dev.dotcalendar.render.ThemeSpecs
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class Lang { JA, EN }
enum class DotShape { DOT, SQUARE }
enum class WidgetBg { SOLID, GLASS, BLUR, CLEAR }

/** Shadow under widget text on the wallpaper: a normal drop shadow, a soft one, or none. Order matches Style.shadow. */
enum class TextShadow { NORMAL, SOFT, OFF }

/** What the widgets sit on: a dark wallpaper (light text), a light one (dark text), or work it out. */
enum class WallpaperTone { DARK, LIGHT, AUTO }

/** Text size on the widgets. Small stays readable; Large is for glancing from further away. */
enum class WidgetTextSize(val scale: Float) { SMALL(0.9f), MEDIUM(1f), LARGE(1.2f) }

/** Size of the weekday labels (日 月 火… / SUN MON…), on top of the widget text size. */
enum class WeekdaySize(val scale: Float) { XSMALL(0.7f), SMALL(0.85f), MEDIUM(1f), LARGE(1.2f) }

/** Font for the weekday labels: the clean system bold, the theme's font, manga, or racing. */
enum class WeekdayFont { STANDARD, THEME, MANGA, RACING }

/** Colour of the Spirit theme's glowing orb. ICE is the original. Order matches Renderer.ORBS. */
enum class SpiritOrb { ICE, JADE, SAPPHIRE, AMETHYST, GOLD, SAKURA, CRIMSON }

/** How dates are written in Japanese: 10.14, 令和8年10月14日, or 10月14日. */
enum class JaDateStyle { STANDARD, ERA, MONTH_DAY }

/** The eight looks, in the order shown in Settings. Ids match ThemeSpecs in the renderer. */
enum class AppTheme(val id: Int) {
    RONIN(ThemeSpecs.RONIN),
    SUMI(ThemeSpecs.SUMI),
    SAMURAI(ThemeSpecs.SAMURAI),
    KI(ThemeSpecs.KI),
    REI(ThemeSpecs.REI),
    HAGANE(ThemeSpecs.HAGANE),
    DENNOU(ThemeSpecs.DENNOU),
    COSMO(ThemeSpecs.COSMO),
}

/** Everything the user can change. Shared by the app and both widgets. */
data class AppSettings(
    val lang: Lang = Lang.JA,
    val theme: AppTheme = AppTheme.RONIN,
    /** Theme for the week widget, or null to follow the app theme. */
    val weekTheme: AppTheme? = null,
    /** Theme for the month widget, or null to follow the app theme. */
    val monthTheme: AppTheme? = null,
    /** Theme for the year widget, or null to follow the app theme. */
    val yearTheme: AppTheme? = null,
    /** Dot colour overrides; null means use the theme's colour. */
    val passed: Int? = null,
    val today: Int? = null,
    val holiday: Int? = null,
    val future: Int? = null,
    val shape: DotShape = DotShape.DOT,
    val numbers: Boolean = false,
    /** Theme icon for today: sunflower, burst, orb or splash. */
    val todayIcon: Boolean = true,
    /** Ki theme: energy wave (true) or comic burst (false) for today. */
    val kiWave: Boolean = true,
    /** Steel theme: sword slash (true) or ink splash (false) for today. */
    val steelSlash: Boolean = true,
    /** Samurai theme: helmet (true) or crossed katanas (false) for today. */
    val samuraiKabuto: Boolean = true,
    /** Spirit theme: colour of the glowing orb for today. */
    val spiritOrb: SpiritOrb = SpiritOrb.ICE,
    /** Spirit theme: a gentle glow around the orb instead of the bright one. */
    val orbSubtle: Boolean = false,
    /** Widgets: a soft glow round today that slowly brightens and fades. */
    val pulseToday: Boolean = false,
    /** Ronin theme widgets: today's sunflower slowly turns. */
    val spinSunflower: Boolean = false,
    /** Heavier, slightly larger text everywhere. */
    val boldText: Boolean = false,
    /** Which holidays to mark: Japanese, US, or both. */
    val holidays: HolidayRegion = HolidayRegion.BOTH,
    /** Show the 日 / EN button on widgets. */
    val showLangChip: Boolean = true,
    /** How dates are written in Japanese. */
    val jaDateStyle: JaDateStyle = JaDateStyle.STANDARD,
    /** The user's own dates (birthdays, trips, exams). */
    val myDates: List<MyDate> = emptyList(),
    /** Show a countdown to the next of the user's dates on the widgets and in the app. */
    val showCountdown: Boolean = true,
    /** Mark days that have events in the phone's calendar. */
    val phoneEvents: Boolean = false,
    /** Show today's 六曜 (大安, 仏滅…). */
    val showRokuyo: Boolean = false,
    /** Show the current 二十四節気 (寒露…). */
    val showSekki: Boolean = false,
    val widgetBg: WidgetBg = WidgetBg.CLEAR,
    val widgetOpacity: Float = 0.5f,
    /** Widget text colour, or null for automatic. */
    val widgetText: Int? = null,
    /** Text size on all widgets. */
    val widgetTextSize: WidgetTextSize = WidgetTextSize.MEDIUM,
    /** Week widget shows only the weekday row and dots, with no date block on the left. */
    val weekOnly: Boolean = false,
    /**
     * Wallpaper behind the widgets (Transparent, Glass and Blur): DARK keeps light text, LIGHT gives
     * dark text and deeper dots, AUTO picks from the wallpaper's brightness and adds extra contrast.
     */
    val wallpaper: WallpaperTone = WallpaperTone.DARK,
    /** Soft shade behind dots and weekdays, outlined dots and a strong text shadow (always on with AUTO). */
    val extraContrast: Boolean = false,
    /** Shadow under widget text on the wallpaper. */
    val textShadow: TextShadow = TextShadow.NORMAL,
    /** Weekday label size and font. */
    val weekdaySize: WeekdaySize = WeekdaySize.MEDIUM,
    val weekdayFont: WeekdayFont = WeekdayFont.STANDARD,
    /** Weekday label colours; null follows the theme. Kept when the theme changes. */
    val wdToday: Int? = null,
    val wdSunday: Int? = null,
    val wdSaturday: Int? = null,
    val wdOther: Int? = null,
) {
    fun withoutColorOverrides(): AppSettings =
        copy(passed = null, today = null, holiday = null, future = null, widgetText = null)
}

object Defaults {
    /** Colours offered in the pickers: theme colours plus a few neutrals. */
    val SWATCHES: List<Int> = listOf(
        // pure white and pure black first, then the neutrals between
        0xFFFFFFFF, 0xFFF2EBDC, 0xFFBCB6A9, 0xFF3A3F3C, 0xFF000000,
        0xFFF2B531, 0xFFFFB020, 0xFFFF8A1A, 0xFFFFD42A, 0xFFE6A69C,
        0xFFF0473A, 0xFFB0302A, 0xFFA3271F, 0xFFEC4F86, 0xFFFF4D97,
        0xFF5FA35A, 0xFF14E8D6, 0xFF74D6F4, 0xFF183166, 0xFF253151,
        0xFFE8E2FB, 0xFF3FD19A, 0xFF4A78FF, 0xFFA673FF, 0xFFDCF3FF,
    ).map { it.toInt() }
}

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "dot_settings_v3")

object SettingsRepo {
    private val LANG = stringPreferencesKey("lang")
    private val THEME = stringPreferencesKey("theme")
    private val WEEK_THEME = stringPreferencesKey("week_theme")
    private val MONTH_THEME = stringPreferencesKey("month_theme")
    private val YEAR_THEME = stringPreferencesKey("year_theme")
    private val PASSED = intPreferencesKey("dot_passed")
    private val TODAY = intPreferencesKey("dot_today")
    private val HOLIDAY = intPreferencesKey("dot_holiday")
    private val FUTURE = intPreferencesKey("dot_future")
    private val SHAPE = stringPreferencesKey("shape")
    private val NUMBERS = booleanPreferencesKey("numbers")
    private val TODAY_ICON = booleanPreferencesKey("today_icon")
    private val BOLD = booleanPreferencesKey("bold_text")
    private val KI_FLAME = booleanPreferencesKey("ki_flame")
    private val STEEL_SLASH = booleanPreferencesKey("steel_slash")
    private val SAMURAI_KABUTO = booleanPreferencesKey("samurai_kabuto")
    private val SPIRIT_ORB = stringPreferencesKey("spirit_orb")
    private val ORB_SUBTLE = booleanPreferencesKey("orb_subtle")
    private val PULSE_TODAY = booleanPreferencesKey("pulse_today")
    private val SPIN_SUNFLOWER = booleanPreferencesKey("spin_sunflower")
    private val TEXT_SHADOW = stringPreferencesKey("text_shadow")
    private val LIGHT_WALLPAPER = booleanPreferencesKey("light_wallpaper") // before v14: on/off only
    private val WALLPAPER_TONE = stringPreferencesKey("wallpaper_tone")
    private val EXTRA_CONTRAST = booleanPreferencesKey("extra_contrast")
    private val HOLIDAYS = stringPreferencesKey("holidays")
    private val LANG_CHIP = booleanPreferencesKey("show_lang_chip")
    private val JA_SHORT_DATE = booleanPreferencesKey("ja_short_date")
    private val JA_DATE_STYLE = stringPreferencesKey("ja_date_style")
    private val MY_DATES = stringPreferencesKey("my_dates")
    private val COUNTDOWN = booleanPreferencesKey("show_countdown")
    private val PHONE_EVENTS = booleanPreferencesKey("phone_events")
    private val ROKUYO = booleanPreferencesKey("show_rokuyo")
    private val SEKKI = booleanPreferencesKey("show_sekki")
    private val WIDGET_BG = stringPreferencesKey("widget_bg")
    private val WIDGET_OPACITY = floatPreferencesKey("widget_opacity")
    private val WIDGET_TEXT = intPreferencesKey("widget_text_v4")
    private val WIDGET_TEXT_SIZE = stringPreferencesKey("widget_text_size")
    private val WEEK_ONLY = booleanPreferencesKey("week_only")
    private val WEEKDAY_SIZE = stringPreferencesKey("weekday_size")
    private val WEEKDAY_FONT = stringPreferencesKey("weekday_font")
    private val WD_TODAY = intPreferencesKey("wd_today")
    private val WD_SUNDAY = intPreferencesKey("wd_sunday")
    private val WD_SATURDAY = intPreferencesKey("wd_saturday")
    private val WD_OTHER = intPreferencesKey("wd_other")

    fun flow(context: Context): Flow<AppSettings> =
        context.applicationContext.settingsStore.data.map { read(it) }

    suspend fun update(context: Context, change: (AppSettings) -> AppSettings) {
        context.applicationContext.settingsStore.edit { prefs -> write(prefs, change(read(prefs))) }
    }

    private fun read(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            lang = enumOr(p[LANG], d.lang),
            theme = enumOr(p[THEME], d.theme),
            weekTheme = enumOrNull<AppTheme>(p[WEEK_THEME]),
            monthTheme = enumOrNull<AppTheme>(p[MONTH_THEME]),
            yearTheme = enumOrNull<AppTheme>(p[YEAR_THEME]),
            passed = p[PASSED],
            today = p[TODAY],
            holiday = p[HOLIDAY],
            future = p[FUTURE],
            shape = enumOr(p[SHAPE], d.shape),
            numbers = p[NUMBERS] ?: d.numbers,
            todayIcon = p[TODAY_ICON] ?: d.todayIcon,
            boldText = p[BOLD] ?: d.boldText,
            kiWave = p[KI_FLAME] ?: d.kiWave,
            steelSlash = p[STEEL_SLASH] ?: d.steelSlash,
            samuraiKabuto = p[SAMURAI_KABUTO] ?: d.samuraiKabuto,
            spiritOrb = enumOr(p[SPIRIT_ORB], d.spiritOrb),
            orbSubtle = p[ORB_SUBTLE] ?: d.orbSubtle,
            pulseToday = p[PULSE_TODAY] ?: d.pulseToday,
            spinSunflower = p[SPIN_SUNFLOWER] ?: d.spinSunflower,
            textShadow = enumOr(p[TEXT_SHADOW], d.textShadow),
            wallpaper = enumOrNull<WallpaperTone>(p[WALLPAPER_TONE])
                ?: if (p[LIGHT_WALLPAPER] == true) WallpaperTone.LIGHT else d.wallpaper,
            extraContrast = p[EXTRA_CONTRAST] ?: d.extraContrast,
            holidays = enumOr(p[HOLIDAYS], d.holidays),
            showLangChip = p[LANG_CHIP] ?: d.showLangChip,
            // version 6 stored a yes/no "short date"; it becomes the era style
            jaDateStyle = enumOrNull<JaDateStyle>(p[JA_DATE_STYLE])
                ?: if (p[JA_SHORT_DATE] == true) JaDateStyle.ERA else d.jaDateStyle,
            myDates = MyDates.decode(p[MY_DATES]),
            showCountdown = p[COUNTDOWN] ?: d.showCountdown,
            phoneEvents = p[PHONE_EVENTS] ?: d.phoneEvents,
            showRokuyo = p[ROKUYO] ?: d.showRokuyo,
            showSekki = p[SEKKI] ?: d.showSekki,
            widgetBg = enumOr(p[WIDGET_BG], d.widgetBg),
            widgetOpacity = p[WIDGET_OPACITY] ?: d.widgetOpacity,
            widgetText = p[WIDGET_TEXT],
            widgetTextSize = enumOr(p[WIDGET_TEXT_SIZE], d.widgetTextSize),
            weekOnly = p[WEEK_ONLY] ?: d.weekOnly,
            weekdaySize = enumOr(p[WEEKDAY_SIZE], d.weekdaySize),
            weekdayFont = enumOr(p[WEEKDAY_FONT], d.weekdayFont),
            wdToday = p[WD_TODAY],
            wdSunday = p[WD_SUNDAY],
            wdSaturday = p[WD_SATURDAY],
            wdOther = p[WD_OTHER],
        )
    }

    private fun write(p: MutablePreferences, s: AppSettings) {
        p[LANG] = s.lang.name
        p[THEME] = s.theme.name
        putOrRemove(p, WEEK_THEME, s.weekTheme?.name)
        putOrRemove(p, MONTH_THEME, s.monthTheme?.name)
        putOrRemove(p, YEAR_THEME, s.yearTheme?.name)
        putOrRemove(p, PASSED, s.passed)
        putOrRemove(p, TODAY, s.today)
        putOrRemove(p, HOLIDAY, s.holiday)
        putOrRemove(p, FUTURE, s.future)
        p[SHAPE] = s.shape.name
        p[NUMBERS] = s.numbers
        p[TODAY_ICON] = s.todayIcon
        p[BOLD] = s.boldText
        p[KI_FLAME] = s.kiWave
        p[STEEL_SLASH] = s.steelSlash
        p[SAMURAI_KABUTO] = s.samuraiKabuto
        p[SPIRIT_ORB] = s.spiritOrb.name
        p[ORB_SUBTLE] = s.orbSubtle
        p[PULSE_TODAY] = s.pulseToday
        p[SPIN_SUNFLOWER] = s.spinSunflower
        p[TEXT_SHADOW] = s.textShadow.name
        p[WALLPAPER_TONE] = s.wallpaper.name
        p[EXTRA_CONTRAST] = s.extraContrast
        p.remove(LIGHT_WALLPAPER)
        p[HOLIDAYS] = s.holidays.name
        p[LANG_CHIP] = s.showLangChip
        p.remove(JA_SHORT_DATE)
        p[JA_DATE_STYLE] = s.jaDateStyle.name
        p[MY_DATES] = MyDates.encode(s.myDates)
        p[COUNTDOWN] = s.showCountdown
        p[PHONE_EVENTS] = s.phoneEvents
        p[ROKUYO] = s.showRokuyo
        p[SEKKI] = s.showSekki
        p[WIDGET_BG] = s.widgetBg.name
        p[WIDGET_OPACITY] = s.widgetOpacity
        putOrRemove(p, WIDGET_TEXT, s.widgetText)
        p[WIDGET_TEXT_SIZE] = s.widgetTextSize.name
        p[WEEK_ONLY] = s.weekOnly
        p[WEEKDAY_SIZE] = s.weekdaySize.name
        p[WEEKDAY_FONT] = s.weekdayFont.name
        putOrRemove(p, WD_TODAY, s.wdToday)
        putOrRemove(p, WD_SUNDAY, s.wdSunday)
        putOrRemove(p, WD_SATURDAY, s.wdSaturday)
        putOrRemove(p, WD_OTHER, s.wdOther)
    }

    private fun <T> putOrRemove(p: MutablePreferences, key: Preferences.Key<T>, value: T?) {
        if (value == null) {
            p.remove(key)
        } else {
            p[key] = value
        }
    }

    private inline fun <reified T : Enum<T>> enumOr(name: String?, fallback: T): T =
        enumValues<T>().firstOrNull { it.name == name } ?: fallback

    private inline fun <reified T : Enum<T>> enumOrNull(name: String?): T? =
        enumValues<T>().firstOrNull { it.name == name }
}
