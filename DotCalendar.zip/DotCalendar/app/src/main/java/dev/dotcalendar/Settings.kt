package dev.dotcalendar

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dev.dotcalendar.render.ThemeSpecs
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class Lang { JA, EN }
enum class DotShape { DOT, SQUARE }
enum class WidgetBg { SOLID, GLASS, BLUR, CLEAR }

/** The six looks, in the order shown in Settings. Ids match ThemeSpecs in the renderer. */
enum class AppTheme(val id: Int) {
    RONIN(ThemeSpecs.RONIN),
    SUMI(ThemeSpecs.SUMI),
    KI(ThemeSpecs.KI),
    REI(ThemeSpecs.REI),
    HAGANE(ThemeSpecs.HAGANE),
    DENNOU(ThemeSpecs.DENNOU),
}

/** Everything the user can change. Shared by the app and both widgets. */
data class AppSettings(
    val lang: Lang = Lang.JA,
    val theme: AppTheme = AppTheme.RONIN,
    /** Theme for the week widget, or null to follow the app theme. */
    val weekTheme: AppTheme? = null,
    /** Theme for the month widget, or null to follow the app theme. */
    val monthTheme: AppTheme? = null,
    /** Dot colour overrides; null means use the theme's colour. */
    val passed: Int? = null,
    val today: Int? = null,
    val holiday: Int? = null,
    val future: Int? = null,
    val shape: DotShape = DotShape.DOT,
    val numbers: Boolean = false,
    /** Theme icon for today: sunflower, burst, orb or splash. */
    val todayIcon: Boolean = true,
    /** Ki theme: flame (true) or comic burst (false) for today. */
    val kiFlame: Boolean = true,
    /** Steel theme: sword slash (true) or ink splash (false) for today. */
    val steelSlash: Boolean = true,
    /** Heavier, slightly larger text everywhere. */
    val boldText: Boolean = false,
    /** Which holidays to mark: Japanese, US, or both. */
    val holidays: HolidayRegion = HolidayRegion.BOTH,
    val widgetBg: WidgetBg = WidgetBg.CLEAR,
    val widgetOpacity: Float = 0.5f,
    /** Widget text colour, or null for automatic. */
    val widgetText: Int? = null,
) {
    fun withoutColorOverrides(): AppSettings =
        copy(passed = null, today = null, holiday = null, future = null, widgetText = null)
}

object Defaults {
    /** Colours offered in the pickers: theme colours plus a few neutrals. */
    val SWATCHES: List<Int> = listOf(
        0xFFF2EBDC, 0xFFF2B531, 0xFFB0302A, 0xFF253151, 0xFFE6A69C,
        0xFFFF8A1A, 0xFFFFD42A, 0xFFF0473A, 0xFF183166, 0xFF74D6F4,
        0xFFEC4F86, 0xFFE8E2FB, 0xFF5FA35A, 0xFFBCB6A9, 0xFF3A3F3C,
        0xFF111111, 0xFFA3271F, 0xFF14E8D6, 0xFFFF4D97, 0xFFFFB020,
    ).map { it.toInt() }
}

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "dot_settings_v3")

object SettingsRepo {
    private val LANG = stringPreferencesKey("lang")
    private val THEME = stringPreferencesKey("theme")
    private val WEEK_THEME = stringPreferencesKey("week_theme")
    private val MONTH_THEME = stringPreferencesKey("month_theme")
    private val PASSED = intPreferencesKey("dot_passed")
    private val TODAY = intPreferencesKey("dot_today")
    private val HOLIDAY = intPreferencesKey("dot_holiday")
    private val FUTURE = intPreferencesKey("dot_future")
    private val SHAPE = stringPreferencesKey("shape")
    private val NUMBERS = booleanPreferencesKey("numbers")
    private val TODAY_ICON = booleanPreferencesKey("today_icon")
    private val BOLD = booleanPreferencesKey("bold_text")
    private val KI_FLAME = booleanPreferencesKey("ki_flame")
    private val STEEL_SLASH = booleanPreferencesKey("steel_slash")
    private val HOLIDAYS = stringPreferencesKey("holidays")
    private val WIDGET_BG = stringPreferencesKey("widget_bg")
    private val WIDGET_OPACITY = floatPreferencesKey("widget_opacity")
    private val WIDGET_TEXT = intPreferencesKey("widget_text_v4")

    fun flow(context: Context): Flow<AppSettings> =
        context.applicationContext.settingsStore.data.map { read(it) }

    suspend fun update(context: Context, change: (AppSettings) -> AppSettings) {
        context.applicationContext.settingsStore.edit { prefs -> write(prefs, change(read(prefs))) }
    }

    private fun read(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            lang = enumOr(p[LANG], d.lang),
            theme = enumOr(p[THEME], d.theme),
            weekTheme = enumOrNull<AppTheme>(p[WEEK_THEME]),
            monthTheme = enumOrNull<AppTheme>(p[MONTH_THEME]),
            passed = p[PASSED],
            today = p[TODAY],
            holiday = p[HOLIDAY],
            future = p[FUTURE],
            shape = enumOr(p[SHAPE], d.shape),
            numbers = p[NUMBERS] ?: d.numbers,
            todayIcon = p[TODAY_ICON] ?: d.todayIcon,
            boldText = p[BOLD] ?: d.boldText,
            kiFlame = p[KI_FLAME] ?: d.kiFlame,
            steelSlash = p[STEEL_SLASH] ?: d.steelSlash,
            holidays = enumOr(p[HOLIDAYS], d.holidays),
            widgetBg = enumOr(p[WIDGET_BG], d.widgetBg),
            widgetOpacity = p[WIDGET_OPACITY] ?: d.widgetOpacity,
            widgetText = p[WIDGET_TEXT],
        )
    }

    private fun write(p: MutablePreferences, s: AppSettings) {
        p[LANG] = s.lang.name
        p[THEME] = s.theme.name
        putOrRemove(p, WEEK_THEME, s.weekTheme?.name)
        putOrRemove(p, MONTH_THEME, s.monthTheme?.name)
        putOrRemove(p, PASSED, s.passed)
        putOrRemove(p, TODAY, s.today)
        putOrRemove(p, HOLIDAY, s.holiday)
        putOrRemove(p, FUTURE, s.future)
        p[SHAPE] = s.shape.name
        p[NUMBERS] = s.numbers
        p[TODAY_ICON] = s.todayIcon
        p[BOLD] = s.boldText
        p[KI_FLAME] = s.kiFlame
        p[STEEL_SLASH] = s.steelSlash
        p[HOLIDAYS] = s.holidays.name
        p[WIDGET_BG] = s.widgetBg.name
        p[WIDGET_OPACITY] = s.widgetOpacity
        putOrRemove(p, WIDGET_TEXT, s.widgetText)
    }

    private fun <T> putOrRemove(p: MutablePreferences, key: Preferences.Key<T>, value: T?) {
        if (value == null) {
            p.remove(key)
        } else {
            p[key] = value
        }
    }

    private inline fun <reified T : Enum<T>> enumOr(name: String?, fallback: T): T =
        enumValues<T>().firstOrNull { it.name == name } ?: fallback

    private inline fun <reified T : Enum<T>> enumOrNull(name: String?): T? =
        enumValues<T>().firstOrNull { it.name == name }
}
