package dev.dotcalendar

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class Lang { JA, EN }
enum class DotShape { DOT, SQUARE }
enum class Body { DARK, PAPER }
enum class WidgetBg { SOLID, GLASS, BLUR, CLEAR }

/** Everything the user can change. Shared by the app and both widgets. */
data class AppSettings(
    val lang: Lang = Lang.JA,
    /** Passed-day colour, or null for automatic (off-white on dark, ink on paper). */
    val passed: Int? = null,
    val today: Int = Defaults.TODAY,
    val holiday: Int = Defaults.HOLIDAY,
    /** Upcoming-day colour, or null for automatic. */
    val future: Int? = null,
    val shape: DotShape = DotShape.DOT,
    val numbers: Boolean = false,
    val sunflower: Boolean = false,
    val body: Body = Body.DARK,
    val widgetBg: WidgetBg = WidgetBg.CLEAR,
    val widgetOpacity: Float = 0.5f,
    /** Widget text colour, or null for automatic. */
    val widgetText: Int? = null,
)

object Defaults {
    val TODAY = 0xFFFF6B1A.toInt()    // orange
    val HOLIDAY = 0xFFD23A2A.toInt()  // vermilion

    /** Colours offered in the pickers. */
    val SWATCHES: List<Int> = listOf(
        0xFFE6E2D8, 0xFFFF6B1A, 0xFFD23A2A, 0xFFF5A623, 0xFF5FA35A,
        0xFF2A9D8F, 0xFF6CB4E4, 0xFF3F5F94, 0xFFE8A0B4, 0xFF7B3F61,
        0xFFD4AF37, 0xFF9E9A90, 0xFF3A3935, 0xFF22211E, 0xFFFFFFFF,
    ).map { it.toInt() }
}

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "dot_settings_v3")

object SettingsRepo {
    private val LANG = stringPreferencesKey("lang")
    private val PASSED = intPreferencesKey("color_passed")
    private val TODAY = intPreferencesKey("color_today")
    private val HOLIDAY = intPreferencesKey("color_holiday")
    private val FUTURE = intPreferencesKey("color_future")
    private val SHAPE = stringPreferencesKey("shape")
    private val NUMBERS = booleanPreferencesKey("numbers")
    private val SUNFLOWER = booleanPreferencesKey("sunflower")
    private val BODY = stringPreferencesKey("body")
    private val WIDGET_BG = stringPreferencesKey("widget_bg")
    private val WIDGET_OPACITY = floatPreferencesKey("widget_opacity")
    private val WIDGET_TEXT = intPreferencesKey("widget_text")

    fun flow(context: Context): Flow<AppSettings> =
        context.applicationContext.settingsStore.data.map { read(it) }

    suspend fun update(context: Context, change: (AppSettings) -> AppSettings) {
        context.applicationContext.settingsStore.edit { prefs -> write(prefs, change(read(prefs))) }
    }

    private fun read(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            lang = enumOr(p[LANG], d.lang),
            passed = p[PASSED],
            today = p[TODAY] ?: d.today,
            holiday = p[HOLIDAY] ?: d.holiday,
            future = p[FUTURE],
            shape = enumOr(p[SHAPE], d.shape),
            numbers = p[NUMBERS] ?: d.numbers,
            sunflower = p[SUNFLOWER] ?: d.sunflower,
            body = enumOr(p[BODY], d.body),
            widgetBg = enumOr(p[WIDGET_BG], d.widgetBg),
            widgetOpacity = p[WIDGET_OPACITY] ?: d.widgetOpacity,
            widgetText = p[WIDGET_TEXT],
        )
    }

    private fun write(p: MutablePreferences, s: AppSettings) {
        p[LANG] = s.lang.name
        putOrRemove(p, PASSED, s.passed)
        p[TODAY] = s.today
        p[HOLIDAY] = s.holiday
        putOrRemove(p, FUTURE, s.future)
        p[SHAPE] = s.shape.name
        p[NUMBERS] = s.numbers
        p[SUNFLOWER] = s.sunflower
        p[BODY] = s.body.name
        p[WIDGET_BG] = s.widgetBg.name
        p[WIDGET_OPACITY] = s.widgetOpacity
        putOrRemove(p, WIDGET_TEXT, s.widgetText)
    }

    private fun putOrRemove(p: MutablePreferences, key: Preferences.Key<Int>, value: Int?) {
        if (value == null) {
            p.remove(key)
        } else {
            p[key] = value
        }
    }

    private inline fun <reified T : Enum<T>> enumOr(name: String?, fallback: T): T =
        enumValues<T>().firstOrNull { it.name == name } ?: fallback
}
