package dev.dotcalendar.render;

/**
 * The seven looks. Each is an original take on a mood rather than a copy of anything:
 *
 *  RONIN  浪人  grey grainy poster paper, flat ukiyo-e colours (vermilion, indigo, bone), brush kanji,
 *               marker lettering, a white cloud, a sunflower for today, a vinyl record for the year.
 *  SUMI   墨    black ink on grainy paper under a soft spotlight, ink-blot dots, a brush ensō for today,
 *               the year painted as an ensō.
 *  KI     気    deep blue with manga speed lines, hot orange and yellow, a flame or burst for today,
 *               a power-gauge ring for the year.
 *  SPIRIT 霊    90s cel-anime night sky in violet, sparkle glints, pink and cyan, a glowing ball of
 *               light for today, the moon filling up over the year.
 *  STEEL  鋼    near-black iron with grit and a dark teal haze, bone and blood red, a slash or splash
 *               for today, a riveted iron dial for the year.
 *  CYBER  電脳  dark HUD glass with scanlines and a fine grid, cyan, magenta and amber, a lock-on
 *               reticle for today, a HUD ring for the year.
 *  SAMURAI 侍   black urushi lacquer with faint laced armour plates and gold dust, gold-leaf dots,
 *               crimson lacing, a katana under titles, a helmet or crossed katanas for today, a sword
 *               guard (tsuba) for the year.
 *
 * Ids are internal and stable; the order shown in Settings comes from AppTheme in Kotlin.
 */
public final class ThemeSpecs {
    private ThemeSpecs() {}

    public static final int RONIN = 0, KI = 1, REI = 2, HAGANE = 3, SUMI = 4, DENNOU = 5, SAMURAI = 6;

    public static String nameJa(int t) {
        switch (t) {
            case KI: return "気";
            case REI: return "霊";
            case HAGANE: return "鋼";
            case SUMI: return "墨";
            case DENNOU: return "電脳";
            case SAMURAI: return "侍";
            default: return "浪人";
        }
    }

    public static String nameEn(int t) {
        switch (t) {
            case KI: return "KI";
            case REI: return "SPIRIT";
            case HAGANE: return "STEEL";
            case SUMI: return "SUMI";
            case DENNOU: return "CYBER";
            case SAMURAI: return "SAMURAI";
            default: return "RONIN";
        }
    }

    public static String seal(int t) {
        switch (t) {
            case KI: return "気";
            case REI: return "霊";
            case HAGANE: return "鋼";
            case SUMI: return "墨";
            case DENNOU: return "電";
            case SAMURAI: return "侍";
            default: return "暦";
        }
    }

    /**
     * Fills a style with the theme's colours.
     * @param onWallpaper true when the surface is the wallpaper itself or a see-through panel
     *                    (widget backgrounds Clear, Glass, Blur), so text needs to be light.
     */
    public static void apply(Style s, int t, boolean onWallpaper) {
        s.theme = t;
        switch (t) {
            case KI:
                s.surface = 0xFF183166;
                s.surface2 = 0xFF0C1A3C;
                s.text = 0xFFFFFFFF;
                s.sub = 0xFFD2DCF4;
                s.todayLabel = 0xFFFFD42A;
                s.accent = 0xFFFF8A1A;
                s.passed = 0xFFFF8A1A;
                s.today = 0xFFFFD42A;
                s.holiday = 0xFFFF5A4C;
                s.future = 0xFF36518C;
                if (onWallpaper) {
                    s.sub = 0xFFE6ECFA;
                    s.future = 0xFF425C96;
                }
                break;
            case REI:
                s.surface = 0xFF2E2870;
                s.surface2 = 0xFF15123A;
                s.text = 0xFFF7F5FF;
                s.sub = 0xFFCFC9F0;
                s.todayLabel = 0xFF8FE3FF;
                s.accent = 0xFFF2649A;
                s.passed = 0xFFE8E2FB;
                s.today = 0xFF8FE3FF;
                s.holiday = 0xFFF2649A;
                s.future = 0xFF4C4594;
                if (onWallpaper) {
                    s.sub = 0xFFE4E0F8;
                    s.future = 0xFF5A52A6;
                }
                break;
            case HAGANE:
                s.surface = 0xFF1C201E;
                s.surface2 = 0xFF0E100F;
                s.text = 0xFFEDE8DC;
                s.sub = 0xFFBDB7AB;
                s.todayLabel = 0xFFE5544B;
                s.accent = 0xFFB52520;
                s.passed = 0xFFC4BEB1;
                s.today = 0xFFB52520;
                s.holiday = 0xFFD1433B;
                s.future = 0xFF3A3F3C;
                if (onWallpaper) {
                    s.sub = 0xFFDDD8CC;
                    s.future = 0xFF484D4A;
                }
                break;
            case SUMI:
                s.surface = 0xFFE4E2DD;
                s.surface2 = 0xFFD3D1CB;
                s.text = 0xFF111111;
                s.sub = 0xFF2B2B2B;
                s.todayLabel = 0xFF111111;
                s.accent = 0xFF111111;
                s.passed = 0xFF151515;
                s.today = 0xFF111111;
                s.holiday = 0xFFA3271F;
                s.future = 0xFFB9B7B1;
                if (onWallpaper) {
                    s.text = 0xFFF4F2ED;
                    s.sub = 0xFFE2DFD8;
                    s.todayLabel = 0xFFFFFFFF;
                    s.accent = 0xFFF4F2ED;
                    s.passed = 0xFFF0EDE6;
                    s.today = 0xFFFFFFFF;
                    s.holiday = 0xFFE0544A;
                    s.future = 0xFF5C5B57;
                }
                break;
            case DENNOU:
                s.surface = 0xFF0B141A;
                s.surface2 = 0xFF04080B;
                s.text = 0xFFE2FFFB;
                s.sub = 0xFF9FE6DE;
                s.todayLabel = 0xFFFF4D97;
                s.accent = 0xFF14E8D6;
                s.passed = 0xFF14E8D6;
                s.today = 0xFFFF4D97;
                s.holiday = 0xFFFFB020;
                s.future = 0xFF1C4148;
                if (onWallpaper) {
                    s.sub = 0xFFC2F3EE;
                    s.future = 0xFF2A5860;
                }
                break;
            case SAMURAI:
                s.surface = 0xFF1F1815;
                s.surface2 = 0xFF0C0A09;
                s.text = 0xFFF1E7D3;
                s.sub = 0xFFD2BE98;
                s.todayLabel = 0xFFE6B54F;
                s.accent = 0xFFC62A2F;
                s.passed = 0xFFD9A646;
                s.today = 0xFFC62A2F;
                s.holiday = 0xFFDB473F;
                s.future = 0xFF3E332C;
                if (onWallpaper) {
                    s.sub = 0xFFE8DABB;
                    s.holiday = 0xFFF0584E;
                    s.future = 0xFF574940;
                }
                break;
            default: // RONIN
                s.surface = 0xFF93918C;
                s.surface2 = 0xFF85837E;
                s.text = 0xFF161513;
                s.sub = 0xFF262422;
                s.todayLabel = 0xFF1E2A4A;
                s.accent = 0xFFB0302A;
                s.passed = 0xFFF2EBDC;
                s.today = 0xFFF2B531;
                s.holiday = 0xFFA52A24;
                s.future = 0xFF73716C;
                if (onWallpaper) {
                    s.text = 0xFFF6F1E6;
                    s.sub = 0xFFE8E2D6;
                    s.todayLabel = 0xFFF6C24A;
                    s.holiday = 0xFFE0544A;
                    s.future = 0xFF5F5D59;
                }
                break;
        }
    }
}
