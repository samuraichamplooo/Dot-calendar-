package dev.dotcalendar.render;

/**
 * The eight looks. Each is an original take on a mood rather than a copy of anything:
 *
 *  RONIN  浪人  grey grainy poster paper, flat ukiyo-e colours (vermilion, indigo, bone), brush kanji,
 *               marker lettering, a white cloud, a sunflower for today, a vinyl record for the year.
 *  SUMI   墨    black ink on grainy paper under a soft spotlight, ink-blot dots, a brush ensō for today,
 *               the year painted as an ensō.
 *  KI     気    deep blue with manga speed lines, hot orange and yellow, an energy wave or burst for today,
 *               a power-gauge ring for the year.
 *  SPIRIT 霊    90s cel-anime night sky in deep teal and blue, sparkle glints, a glowing ball of
 *               light for today, the moon filling up over the year.
 *  STEEL  鋼    near-black iron with grit and a dark teal haze, bone and blood red, a slash or splash
 *               for today, a riveted iron dial for the year.
 *  CYBER  電脳  dark HUD glass with scanlines and a fine grid, teal and lime green, a lock-on
 *               reticle for today, a HUD ring for the year.
 *  SAMURAI 侍   black urushi lacquer with faint laced armour plates and gold dust, gold-leaf dots,
 *               crimson lacing, a katana under titles, a helmet or crossed katanas for today, a sword
 *               guard (tsuba) for the year.
 *  COSMO 宇宙   retro space jazz: charcoal night with stars, a faint ringed planet and flat 70s colour
 *               bars, mustard dots, orange and teal, a rocket for today, an orbit for the year.
 *
 * Ids are internal and stable; the order shown in Settings comes from AppTheme in Kotlin.
 */
public final class ThemeSpecs {
    private ThemeSpecs() {}

    public static final int RONIN = 0, KI = 1, REI = 2, HAGANE = 3, SUMI = 4, DENNOU = 5, SAMURAI = 6, COSMO = 7;

    public static String nameJa(int t) {
        switch (t) {
            case KI: return "気";
            case REI: return "霊";
            case HAGANE: return "鋼";
            case SUMI: return "墨";
            case DENNOU: return "電脳";
            case SAMURAI: return "侍";
            case COSMO: return "宇宙";
            default: return "浪人";
        }
    }

    public static String nameEn(int t) {
        switch (t) {
            case KI: return "KI";
            case REI: return "SPIRIT";
            case HAGANE: return "STEEL";
            case SUMI: return "SUMI";
            case DENNOU: return "CYBER";
            case SAMURAI: return "SAMURAI";
            case COSMO: return "COSMO";
            default: return "RONIN";
        }
    }

    public static String seal(int t) {
        switch (t) {
            case KI: return "気";
            case REI: return "霊";
            case HAGANE: return "鋼";
            case SUMI: return "墨";
            case DENNOU: return "電";
            case SAMURAI: return "侍";
            case COSMO: return "宙";
            default: return "暦";
        }
    }

    /**
     * Fills a style with the theme's colours.
     * @param onWallpaper true when the surface is the wallpaper itself or a see-through panel
     *                    (widget backgrounds Clear, Glass, Blur), so text needs to be light.
     */
    public static void apply(Style s, int t, boolean onWallpaper) {
        s.theme = t;
        switch (t) {
            case KI:
                s.surface = 0xFF183166;
                s.surface2 = 0xFF0C1A3C;
                s.text = 0xFFFFFFFF;
                s.sub = 0xFFD2DCF4;
                s.todayLabel = 0xFFFFD42A;
                s.accent = 0xFFFF8A1A;
                s.passed = 0xFFFF8A1A;
                s.today = 0xFFFFD42A;
                s.holiday = 0xFFFF5A4C;
                s.future = 0xFF36518C;
                if (onWallpaper) {
                    s.sub = 0xFFE6ECFA;
                    s.future = 0xFF425C96;
                }
                break;
            case REI:
                s.surface = 0xFF0F3A5A;
                s.surface2 = 0xFF081B33;
                s.text = 0xFFF2FBFF;
                s.sub = 0xFFC2DCEE;
                s.todayLabel = 0xFF6FF5DF;
                s.accent = 0xFF2ED6C4;
                s.passed = 0xFFDCF3FF;
                s.today = 0xFF8FE3FF;
                s.holiday = 0xFF5AB4FF;
                s.future = 0xFF2A5482;
                if (onWallpaper) {
                    s.sub = 0xFFDCEEFA;
                    s.future = 0xFF3A6496;
                }
                break;
            case HAGANE:
                s.surface = 0xFF1C201E;
                s.surface2 = 0xFF0E100F;
                s.text = 0xFFEDE8DC;
                s.sub = 0xFFBDB7AB;
                s.todayLabel = 0xFFE5544B;
                s.accent = 0xFFB52520;
                s.passed = 0xFFC4BEB1;
                s.today = 0xFFB52520;
                s.holiday = 0xFFD1433B;
                s.future = 0xFF3A3F3C;
                if (onWallpaper) {
                    s.sub = 0xFFDDD8CC;
                    s.future = 0xFF484D4A;
                }
                break;
            case SUMI:
                s.surface = 0xFFE4E2DD;
                s.surface2 = 0xFFD3D1CB;
                s.text = 0xFF111111;
                s.sub = 0xFF2B2B2B;
                s.todayLabel = 0xFF111111;
                s.accent = 0xFF111111;
                s.passed = 0xFF151515;
                s.today = 0xFF111111;
                s.holiday = 0xFFA3271F;
                s.future = 0xFFB9B7B1;
                if (onWallpaper) {
                    s.text = 0xFFF4F2ED;
                    s.sub = 0xFFE2DFD8;
                    s.todayLabel = 0xFFFFFFFF;
                    s.accent = 0xFFF4F2ED;
                    s.passed = 0xFFF0EDE6;
                    s.today = 0xFFFFFFFF;
                    s.holiday = 0xFFE0544A;
                    s.future = 0xFF5C5B57;
                }
                break;
            case DENNOU:
                s.surface = 0xFF0B141A;
                s.surface2 = 0xFF04080B;
                s.text = 0xFFE2FFFB;
                s.sub = 0xFF9FE6DE;
                s.todayLabel = 0xFFB4FF39;
                s.accent = 0xFF14E8D6;
                s.passed = 0xFF14E8D6;
                s.today = 0xFFB4FF39;
                s.holiday = 0xFF8CFFF0;
                s.future = 0xFF1C4148;
                if (onWallpaper) {
                    s.sub = 0xFFC2F3EE;
                    s.future = 0xFF2A5860;
                }
                break;
            case COSMO:
                s.surface = 0xFF1E2030;
                s.surface2 = 0xFF0F1019;
                s.text = 0xFFF5ECDA;
                s.sub = 0xFFC2C8DA;
                s.todayLabel = 0xFFFF8A3D;
                s.accent = 0xFF2FB0C2;
                s.passed = 0xFFF2B63C;
                s.today = 0xFFFF6A33;
                s.holiday = 0xFFEC4B3C;
                s.future = 0xFF363A50;
                if (onWallpaper) {
                    s.sub = 0xFFDFE3EE;
                    s.future = 0xFF494E68;
                }
                break;
            case SAMURAI:
                s.surface = 0xFF1F1815;
                s.surface2 = 0xFF0C0A09;
                s.text = 0xFFF1E7D3;
                s.sub = 0xFFD2BE98;
                s.todayLabel = 0xFFE6B54F;
                s.accent = 0xFFC62A2F;
                s.passed = 0xFFD9A646;
                s.today = 0xFFC62A2F;
                s.holiday = 0xFFDB473F;
                s.future = 0xFF3E332C;
                if (onWallpaper) {
                    s.sub = 0xFFE8DABB;
                    s.holiday = 0xFFF0584E;
                    s.future = 0xFF574940;
                }
                break;
            default: // RONIN
                s.surface = 0xFF93918C;
                s.surface2 = 0xFF85837E;
                s.text = 0xFF161513;
                s.sub = 0xFF262422;
                s.todayLabel = 0xFF1E2A4A;
                s.accent = 0xFFB0302A;
                s.passed = 0xFFF2EBDC;
                s.today = 0xFFF2B531;
                s.holiday = 0xFFA52A24;
                s.future = 0xFF73716C;
                if (onWallpaper) {
                    s.text = 0xFFF6F1E6;
                    s.sub = 0xFFE8E2D6;
                    s.todayLabel = 0xFFF6C24A;
                    s.holiday = 0xFFE0544A;
                    s.future = 0xFF5F5D59;
                }
                break;
        }
    }

    /**
     * For a widget on a light wallpaper (white, off-white, pastel), used with the Clear, Glass and
     * Blur backgrounds: near-black text, and every theme colour deepened until it reads on white.
     * Passed days become the theme's colour at full strength; upcoming days a pale tint of it.
     */
    public static void applyLightWallpaper(Style s) {
        s.lightWall = true;
        s.text = 0xFF151515;
        s.sub = 0xFF2A2A2A;
        s.todayLabel = deepen(s.todayLabel, 0.42f);
        s.accent = deepen(s.accent, 0.45f);
        s.holiday = deepen(s.holiday, 0.45f);
        s.today = deepen(s.today, 0.5f);
        s.passed = deepen(s.passed, 0.36f);
        s.future = Renderer.mix(s.passed, 0xFFFFFFFF, 0.72f);
    }

    /** The same hue, more saturated and darker, until its luminance is at most {@code maxLum}. */
    static int deepen(int color, float maxLum) {
        if (Renderer.luminance(color) <= maxLum) return color;
        float[] hsv = hsv(color);
        if (hsv[1] >= 0.12f) hsv[1] = Math.max(hsv[1], 0.55f);
        int out = color;
        for (int i = 0; i < 40; i++) {
            out = fromHsv(hsv, color >>> 24);
            if (Renderer.luminance(out) <= maxLum) break;
            hsv[2] = Math.max(0f, hsv[2] - 0.03f);
        }
        return out;
    }

    static float[] hsv(int c) {
        float r = ((c >> 16) & 0xFF) / 255f, g = ((c >> 8) & 0xFF) / 255f, b = (c & 0xFF) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        float h;
        if (d == 0f) h = 0f;
        else if (max == r) h = 60f * (((g - b) / d) % 6f);
        else if (max == g) h = 60f * ((b - r) / d + 2f);
        else h = 60f * ((r - g) / d + 4f);
        if (h < 0f) h += 360f;
        return new float[]{h, max == 0f ? 0f : d / max, max};
    }

    static int fromHsv(float[] hsv, int alpha) {
        float h = hsv[0], s = hsv[1], v = hsv[2];
        float c = v * s, x = c * (1f - Math.abs((h / 60f) % 2f - 1f)), m = v - c;
        float r, g, b;
        if (h < 60f) { r = c; g = x; b = 0f; }
        else if (h < 120f) { r = x; g = c; b = 0f; }
        else if (h < 180f) { r = 0f; g = c; b = x; }
        else if (h < 240f) { r = 0f; g = x; b = c; }
        else if (h < 300f) { r = x; g = 0f; b = c; }
        else { r = c; g = 0f; b = x; }
        return (alpha << 24) | (Math.round((r + m) * 255f) << 16) | (Math.round((g + m) * 255f) << 8) | Math.round((b + m) * 255f);
    }
}
