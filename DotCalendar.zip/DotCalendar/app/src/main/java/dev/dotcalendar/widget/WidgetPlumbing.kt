package dev.dotcalendar.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.AndroidRemoteViews
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.state.updateAppWidgetState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import dev.dotcalendar.Lang
import dev.dotcalendar.PulseFrame
import dev.dotcalendar.R
import dev.dotcalendar.SettingsRepo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

/** Written on every refresh so widgets re-render (e.g. after midnight). */
internal val REFRESH_KEY = longPreferencesKey("refreshed_at")

class WeekWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = WeekWidget()

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        super.onUpdate(context, manager, ids)
        DayChangeScheduler.scheduleNext(context)
    }
}

class YearWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = YearWidget()

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        super.onUpdate(context, manager, ids)
        DayChangeScheduler.scheduleNext(context)
    }
}

class MonthWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = MonthWidget()

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        super.onUpdate(context, manager, ids)
        DayChangeScheduler.scheduleNext(context)
    }
}

/**
 * The pulsing glow round today. Widgets can't run their own animations, but the home screen can:
 * a ViewFlipper (res/layout/pulse_glow.xml) cross-fades between an empty frame and the glow,
 * so the glow slowly brightens and fades for as long as the widget is on screen.
 */
@Composable
internal fun PulseGlow(context: Context, frame: PulseFrame) {
    val views = RemoteViews(context.packageName, R.layout.pulse_glow)
    views.setImageViewBitmap(R.id.pulse_bright, frame.bitmap)
    Box(
        modifier = GlanceModifier.fillMaxSize().padding(start = frame.x.dp, top = frame.y.dp),
        contentAlignment = Alignment.TopStart,
    ) {
        AndroidRemoteViews(views, GlanceModifier.width(frame.w.dp).height(frame.h.dp))
    }
}

/** Tapping the LCD on either widget flips the shared language between 日本語 and English. */
class ToggleLanguageAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        SettingsRepo.update(context) { it.copy(lang = if (it.lang == Lang.JA) Lang.EN else Lang.JA) }
        WidgetRefresher.refreshAll(context)
    }
}

object WidgetRefresher {
    /** Redraws every placed week, month and year widget. */
    suspend fun refreshAll(context: Context) {
        val manager = GlanceAppWidgetManager(context)
        val stamp = System.currentTimeMillis()
        for (widget in listOf(WeekWidget(), MonthWidget(), YearWidget())) {
            manager.getGlanceIds(widget.javaClass).forEach { id ->
                updateAppWidgetState(context, id) { prefs -> prefs[REFRESH_KEY] = stamp }
                widget.update(context, id)
            }
        }
    }
}

object DayChangeScheduler {
    private const val ACTION_DAY_CHANGED = "dev.dotcalendar.DAY_CHANGED"

    /**
     * Sets an alarm for just after the next midnight. It's a non-waking alarm, so it
     * doesn't drain battery: if the phone is asleep, the dots turn over when you wake it.
     */
    fun scheduleNext(context: Context) {
        val alarms = context.getSystemService(AlarmManager::class.java) ?: return
        val nextMidnight = LocalDate.now().plusDays(1)
            .atStartOfDay(ZoneId.systemDefault())
            .toInstant().toEpochMilli() + 5_000
        val intent = Intent(context, DayChangeReceiver::class.java).setAction(ACTION_DAY_CHANGED)
        val pending = PendingIntent.getBroadcast(
            context, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        alarms.setWindow(AlarmManager.RTC, nextMidnight, 60_000L, pending)
    }
}

/** Handles the midnight alarm, reboots, app updates, and clock / time-zone changes. */
class DayChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val result = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.Default).launch {
            try {
                WidgetRefresher.refreshAll(appContext)
            } finally {
                DayChangeScheduler.scheduleNext(appContext)
                result.finish()
            }
        }
    }
}
