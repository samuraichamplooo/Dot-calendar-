package dev.dotcalendar.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.unit.dp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.ContentScale
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import dev.dotcalendar.AppSettings
import dev.dotcalendar.MainActivity
import dev.dotcalendar.RenderBridge
import dev.dotcalendar.SettingsRepo
import dev.dotcalendar.Tx
import dev.dotcalendar.render.Renderer
import kotlinx.coroutines.flow.first
import java.time.LocalDate

/** Large widget: the whole month. Tap the LCD to switch language, anywhere else to open the app. */
class MonthWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val initial = SettingsRepo.flow(context).first()
        provideContent {
            val flow = remember { SettingsRepo.flow(context) }
            val settings by flow.collectAsState(initial = initial)
            currentState(REFRESH_KEY) // re-render when the day changes
            MonthContent(context, settings)
        }
    }
}

@Composable
private fun MonthContent(context: Context, s: AppSettings) {
    val size = LocalSize.current
    val w = if (size.width.value > 10f) size.width.value else 300f
    val h = if (size.height.value > 10f) size.height.value else 300f
    val bitmap = RenderBridge.monthWidgetBitmap(context, s, LocalDate.now(), w, h)
    val lcd = Renderer.monthLcdRect(w, h)

    Box(GlanceModifier.fillMaxSize().clickable(actionStartActivity<MainActivity>())) {
        Image(
            provider = ImageProvider(bitmap),
            contentDescription = Tx(s.lang).t("今月のカレンダー", "This month's calendar"),
            modifier = GlanceModifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds,
        )
        Box(
            modifier = GlanceModifier.fillMaxSize().padding(top = lcd[1].dp, end = (w - lcd[0] - lcd[2]).dp),
            contentAlignment = Alignment.TopEnd,
        ) {
            Box(
                modifier = GlanceModifier
                    .width(lcd[2].dp)
                    .height(lcd[3].dp)
                    .clickable(actionRunCallback<ToggleLanguageAction>()),
            ) {}
        }
    }
}
