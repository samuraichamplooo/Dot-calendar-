package dev.dotcalendar.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.action.actionStartActivity
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import dev.dotcalendar.JapaneseCalendar
import dev.dotcalendar.MainActivity
import dev.dotcalendar.R
import java.time.LocalDate
import java.time.YearMonth

/** Large widget: the whole current month. */
class MonthWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent { MonthContent() }
    }
}

@Composable
private fun MonthContent() {
    currentState(REFRESH_KEY) // re-render on refresh
    val today = LocalDate.now()
    val month = YearMonth.from(today)
    val weeks = JapaneseCalendar.monthWeeks(month)

    val size = LocalSize.current
    val pad = 12.dp
    val headerH = 28.dp
    val weekdayH = 18.dp
    val cellW = (size.width - pad * 2) / 7
    val cellH = (size.height - pad * 2 - headerH - weekdayH) / weeks.size
    val dot = (minOf(cellW, cellH) * 0.82f).coerceAtLeast(6.dp)

    Column(
        GlanceModifier
            .fillMaxSize()
            .background(ImageProvider(R.drawable.widget_bg))
            .padding(pad)
            .clickable(actionStartActivity<MainActivity>()),
    ) {
        Row(GlanceModifier.fillMaxWidth().height(headerH), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${month.monthValue}月",
                style = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold, color = textPrimary),
            )
            Text(
                "  ${JapaneseCalendar.traditionalMonth(month.monthValue)}",
                style = TextStyle(fontSize = 12.sp, color = textSecondary),
            )
            Spacer(GlanceModifier.defaultWeight())
            Text(
                JapaneseCalendar.eraYear(today),
                style = TextStyle(fontSize = 12.sp, color = textSecondary),
            )
        }

        Row(GlanceModifier.fillMaxWidth().height(weekdayH)) {
            JapaneseCalendar.WEEKDAYS.forEachIndexed { i, w ->
                Box(GlanceModifier.defaultWeight().fillMaxHeight(), contentAlignment = Alignment.Center) {
                    Text(
                        w,
                        style = TextStyle(
                            fontSize = 11.sp,
                            color = if (i == 0) textRed else textSecondary,
                            textAlign = TextAlign.Center,
                        ),
                    )
                }
            }
        }

        weeks.forEach { week ->
            Row(GlanceModifier.fillMaxWidth().height(cellH)) {
                week.forEach { date ->
                    Box(GlanceModifier.defaultWeight().fillMaxHeight(), contentAlignment = Alignment.Center) {
                        if (date != null) WidgetDot(date, today, dot)
                    }
                }
            }
        }
    }
}
