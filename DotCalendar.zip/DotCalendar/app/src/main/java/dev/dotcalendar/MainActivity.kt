package dev.dotcalendar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import dev.dotcalendar.widget.DayChangeScheduler
import dev.dotcalendar.widget.WidgetRefresher
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Keep widgets current whenever the app is opened.
        DayChangeScheduler.scheduleNext(this)
        lifecycleScope.launch { WidgetRefresher.refreshAll(applicationContext) }

        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    DotCalendarScreen()
                }
            }
        }
    }
}

@Composable
private fun DotCalendarScreen() {
    val today = remember { LocalDate.now() }
    var month by remember { mutableStateOf(YearMonth.from(today)) }

    Column(
        Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        TodayHeader(today)
        Spacer(Modifier.height(24.dp))

        MonthHeader(
            month = month,
            showTodayButton = month != YearMonth.from(today),
            onPrev = { month = month.minusMonths(1) },
            onNext = { month = month.plusMonths(1) },
            onToday = { month = YearMonth.from(today) },
        )
        Spacer(Modifier.height(8.dp))
        MonthGrid(month, today)

        Spacer(Modifier.height(20.dp))
        Legend()
        Spacer(Modifier.height(20.dp))
        HolidayList(month)

        Spacer(Modifier.height(24.dp))
        Text(
            "Add the widgets by long-pressing your home screen → Widgets → Dot Calendar.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun TodayHeader(today: LocalDate) {
    val holiday = JapaneseHolidays.nameOf(today)
    Text(
        JapaneseCalendar.fullDate(today),
        fontSize = 26.sp,
        fontWeight = FontWeight.Bold,
    )
    Text(
        "${today.year}  ·  ${JapaneseCalendar.traditionalMonth(today.monthValue)}" +
            (holiday?.let { "  ·  $it" } ?: ""),
        style = MaterialTheme.typography.bodyMedium,
        color = if (holiday != null) DotColors.Red else MaterialTheme.colorScheme.onSurfaceVariant,
    )

    // How much of the year has passed.
    val dayNumber = today.dayOfYear
    val daysInYear = today.lengthOfYear()
    Spacer(Modifier.height(12.dp))
    LinearProgressIndicator(
        progress = { dayNumber / daysInYear.toFloat() },
        modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
        color = DotColors.Green,
        trackColor = MaterialTheme.colorScheme.surfaceVariant,
    )
    Spacer(Modifier.height(4.dp))
    Text(
        "今年 ${dayNumber}日目 · 残り${daysInYear - dayNumber}日",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun MonthHeader(
    month: YearMonth,
    showTodayButton: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onToday: () -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onPrev) { Text("◀", fontSize = 18.sp) }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${month.monthValue}月", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(
                "${JapaneseCalendar.eraYear(month.atEndOfMonth())} · ${JapaneseCalendar.traditionalMonth(month.monthValue)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        TextButton(onClick = onNext) { Text("▶", fontSize = 18.sp) }
    }
    if (showTodayButton) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            TextButton(onClick = onToday) { Text("今日へ戻る · Back to today") }
        }
    }
}

@Composable
private fun MonthGrid(month: YearMonth, today: LocalDate) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val cell = maxWidth / 7
        val dot = cell * 0.78f
        Column {
            Row {
                JapaneseCalendar.WEEKDAYS.forEachIndexed { i, w ->
                    Text(
                        w,
                        modifier = Modifier.width(cell),
                        textAlign = TextAlign.Center,
                        fontSize = 13.sp,
                        color = if (i == 0) DotColors.Red else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            JapaneseCalendar.monthWeeks(month).forEach { week ->
                Row {
                    week.forEach { date ->
                        Box(Modifier.size(cell), contentAlignment = Alignment.Center) {
                            if (date != null) Dot(date, DotState.of(date, today), dot)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Dot(date: LocalDate, state: DotState, size: Dp) {
    val shape = CircleShape
    val modifier = if (state.filled) {
        Modifier.size(size).clip(shape).background(state.color)
    } else {
        Modifier.size(size).border(2.dp, state.color, shape)
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        Text(
            date.dayOfMonth.toString(),
            fontSize = (size.value * 0.36f).sp,
            fontWeight = if (state == DotState.TODAY) FontWeight.Bold else FontWeight.Medium,
            color = if (state.filled) Color.White else state.color,
        )
    }
}

@Composable
private fun Legend() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        LegendItem(DotState.PASSED, "経過 · Passed")
        LegendItem(DotState.TODAY, "今日 · Today")
        LegendItem(DotState.HOLIDAY, "日曜・祝日 · Sunday / holiday")
        LegendItem(DotState.FUTURE, "これから · Upcoming")
    }
}

@Composable
private fun LegendItem(state: DotState, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        val m = if (state.filled) {
            Modifier.size(14.dp).clip(CircleShape).background(state.color)
        } else {
            Modifier.size(14.dp).border(2.dp, state.color, CircleShape)
        }
        Box(m)
        Spacer(Modifier.width(10.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun HolidayList(month: YearMonth) {
    val holidays = JapaneseHolidays.forYear(month.year)
        .filterKeys { YearMonth.from(it) == month }
        .toSortedMap()
    Text("祝日 · Holidays", fontWeight = FontWeight.Bold, fontSize = 16.sp)
    Spacer(Modifier.height(6.dp))
    if (holidays.isEmpty()) {
        Text(
            "今月は祝日がありません",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    } else {
        holidays.forEach { (date, name) ->
            Row(Modifier.padding(vertical = 3.dp)) {
                Text(
                    JapaneseCalendar.shortDate(date),
                    modifier = Modifier.width(130.dp),
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(name, style = MaterialTheme.typography.bodyMedium, color = DotColors.Red)
            }
        }
    }
}
