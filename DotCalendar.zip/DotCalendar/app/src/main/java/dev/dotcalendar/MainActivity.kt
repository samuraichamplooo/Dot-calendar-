package dev.dotcalendar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import dev.dotcalendar.ui.DotApp
import dev.dotcalendar.widget.DayChangeScheduler
import dev.dotcalendar.widget.WidgetRefresher
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    /** Bumped on every resume so the app picks up a language switched from a widget. */
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        DayChangeScheduler.scheduleNext(this)
        val app = applicationContext

        setContent {
            val scope = rememberCoroutineScope()
            var settings by remember { mutableStateOf<AppSettings?>(null) }
            val tick = resumeTick.intValue
            LaunchedEffect(tick) { settings = SettingsRepo.flow(app).first() }

            val s = settings
            if (s == null) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color(0xFF1C1C1A)),
                )
            } else {
                // Redraw the widgets shortly after the last change.
                LaunchedEffect(s) {
                    delay(700)
                    WidgetRefresher.refreshAll(app)
                }
                val light = RenderBridge.isLightTheme(s.theme)
                LaunchedEffect(light) {
                    val clear = android.graphics.Color.TRANSPARENT
                    val bars = if (light) SystemBarStyle.light(clear, clear) else SystemBarStyle.dark(clear)
                    this@MainActivity.enableEdgeToEdge(statusBarStyle = bars, navigationBarStyle = bars)
                }
                DotApp(s) { changed ->
                    settings = changed
                    scope.launch { SettingsRepo.update(app) { changed } }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }
}
