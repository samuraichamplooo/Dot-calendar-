package dev.dotcalendar.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import dev.dotcalendar.AppSettings
import dev.dotcalendar.AppTheme
import dev.dotcalendar.Lang
import dev.dotcalendar.ThemeFonts
import dev.dotcalendar.Tx
import dev.dotcalendar.render.Renderer
import dev.dotcalendar.render.Style

/** The phone's sans for body text. */
val UiFont = FontFamily.SansSerif

@Immutable
data class AppFonts(val titleJa: FontFamily, val titleEn: FontFamily)

fun fontsFor(t: AppTheme): AppFonts =
    AppFonts(FontFamily(Font(ThemeFonts.jaRes(t))), FontFamily(Font(ThemeFonts.enRes(t))))

@Immutable
data class Palette(
    val bg: Color,
    val panel: Color,
    val text: Color,
    val sub: Color,
    val button: Color,
    val accent: Color,
    val light: Boolean,
)

private val BLACK: Int = 0xFF000000.toInt()
private val WHITE: Int = 0xFFFFFFFF.toInt()

/** App colours derived from the theme's surface and text. */
fun paletteFor(st: Style): Palette {
    val light = Renderer.luminance(st.surface) > 0.45f
    val panel = if (light) Renderer.mix(st.surface, WHITE, 0.16f) else Renderer.mix(st.surface2, WHITE, 0.07f)
    val button = if (light) Renderer.mix(st.surface, BLACK, 0.12f) else Renderer.mix(st.surface2, WHITE, 0.14f)
    return Palette(
        bg = Color(st.surface),
        panel = Color(panel),
        text = Color(st.text),
        sub = Color(st.sub),
        button = Color(button),
        accent = Color(st.accent),
        light = light,
    )
}

val LocalPalette = staticCompositionLocalOf { paletteFor(Style()) }
val LocalTx = staticCompositionLocalOf { Tx(Lang.JA) }
val LocalSettings = staticCompositionLocalOf { AppSettings() }
val LocalAppStyle = staticCompositionLocalOf { Style() }
val LocalFonts = staticCompositionLocalOf { fontsFor(AppTheme.RONIN) }

/** The theme's display font for the current language. */
@Composable
fun titleFont(ja: Boolean): FontFamily = if (ja) LocalFonts.current.titleJa else LocalFonts.current.titleEn

/** Body text weight: Medium normally, Bold with the bold-text option. */
@Composable
fun bodyWeight(): FontWeight = if (LocalSettings.current.boldText) FontWeight.Bold else FontWeight.Medium

/** Display text weight (synthesised bold for single-weight display fonts). */
@Composable
fun titleWeight(): FontWeight = if (LocalSettings.current.boldText) FontWeight.Bold else FontWeight.Normal
