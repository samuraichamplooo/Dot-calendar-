package dev.dotcalendar.ui

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import dev.dotcalendar.AppSettings
import dev.dotcalendar.Lang
import dev.dotcalendar.R
import dev.dotcalendar.Tx
import dev.dotcalendar.render.Style

/** Ink brush for Japanese, hip-hop marker for English titles, the phone's sans for everything else. */
val BrushFont = FontFamily(Font(R.font.yuji_boku))
val MarkerFont = FontFamily(Font(R.font.permanent_marker))
val UiFont = FontFamily.SansSerif

fun titleFont(japanese: Boolean): FontFamily = if (japanese) BrushFont else MarkerFont

val SealRed = Color(0xFFD23A2A)

@Immutable
data class Palette(
    val bg: Color,
    val panel: Color,
    val text: Color,
    val sub: Color,
    val faint: Color,
    val button: Color,
    val paper: Boolean,
)

val DarkPalette = Palette(
    bg = Color(0xFF1C1C1A),
    panel = Color(0xFF272623),
    text = Color(0xFFE6E2D8),
    sub = Color(0xFF8A867D),
    faint = Color(0xFF3A3935),
    button = Color(0xFF34332F),
    paper = false,
)

val PaperPalette = Palette(
    bg = Color(0xFFECE7DD),
    panel = Color(0xFFE1DBCE),
    text = Color(0xFF22211E),
    sub = Color(0xFF7A7469),
    faint = Color(0xFFCFC8BA),
    button = Color(0xFFD6CFC1),
    paper = true,
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }
val LocalTx = staticCompositionLocalOf { Tx(Lang.JA) }
val LocalSettings = staticCompositionLocalOf { AppSettings() }
val LocalAppStyle = staticCompositionLocalOf { Style() }
