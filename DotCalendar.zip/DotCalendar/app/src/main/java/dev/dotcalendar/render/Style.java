package dev.dotcalendar.render;

import android.graphics.Typeface;

/** The look settings the renderer needs. Built from the user's settings in RenderBridge.kt. */
public final class Style {
    public int passed = Renderer.OFF_WHITE;  // days gone by
    public int today = Renderer.ORANGE;      // today
    public int holiday = Renderer.SEAL;      // upcoming Sundays & holidays
    public int future = Renderer.DIM;        // other upcoming days
    public boolean squares = false;          // false = round dots, true = rounded squares
    public boolean numbers = false;          // print the date inside each dot
    public boolean sunflower = false;        // draw today as a small sunflower
    public boolean paper = false;            // light paper theme instead of dark
    public int background = Renderer.BG_CLEAR;
    public float opacity = 0.5f;             // glass / blur strength, 0..1
    public int text = Renderer.OFF_WHITE;
    public Typeface brush = Typeface.SERIF;      // Japanese ink brush
    public Typeface sans = Typeface.DEFAULT;     // clean numbers and English labels
    public Typeface marker = Typeface.DEFAULT;   // hip-hop marker for English titles
}
