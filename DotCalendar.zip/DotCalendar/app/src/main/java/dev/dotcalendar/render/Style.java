package dev.dotcalendar.render;

import android.graphics.Typeface;

/** Everything the renderer needs for one surface. Colours come from ThemeSpecs plus user overrides. */
public final class Style {
    public int theme = ThemeSpecs.RONIN;

    // Day colours
    public int passed, today, holiday, future;

    // Text and accents on this surface
    public int text;        // primary text
    public int sub;         // secondary text
    public int todayLabel;  // weekday label above / beside today
    public int accent;      // marks, rings, chips

    // Surface (top and bottom of the body gradient)
    public int surface, surface2;

    // Options
    public boolean squares = false;   // rounded squares instead of dots
    public boolean numbers = false;   // print dates inside the dots
    public boolean todayIcon = true;  // theme icon for today (sunflower, burst, orb, splash)
    public boolean todayAlt = false;  // second icon choice where a theme has one (flame, slash)
    public boolean bold = false;      // heavier, slightly larger text
    public boolean langChip = true;   // show the 日 / EN switch on widgets
    public int orb = 0;               // Spirit orb colour: 0 ice … 6 crimson (see Renderer.ORBS)
    public boolean orbSubtle = false; // Spirit orb: a gentle glow instead of the bright one
    public boolean lightWall = false; // widget sits on a light wallpaper: dark text, deeper dots, light glass
    public int shadow = 0;            // text shadow on widgets: 0 normal, 1 soft, 2 off

    // Filled in while drawing a widget: where today's dot landed (dp), for the pulsing glow
    public float todayX = -1f, todayY = -1f, todayCell = 0f;
    public boolean weekOnly = false;  // week widget: just the weekday row and dots, no date block
    public float textScale = 1f;      // widget text size: about 0.88 small, 1 medium, 1.2 large

    // Weekday labels (日 月 火… / SUN MON…): size, font and colours, kept whatever the theme
    public float weekdayScale = 1f;   // 0.7 extra small … 1.2 large
    public Typeface weekdayJa = null; // null = the clean bold label face
    public Typeface weekdayEn = null;
    public float weekdaySkewJa = 0f;  // slant for Japanese when the font has no italic (racing)
    public int wdToday = 0;           // 0 = theme colour
    public int wdSunday = 0;          // Sundays and holidays
    public int wdSaturday = 0;
    public int wdOther = 0;
    public int background = Renderer.BG_SOLID;
    public float opacity = 0.5f;

    // Type
    public Typeface titleJa = Typeface.SERIF;   // theme display font for Japanese
    public Typeface titleEn = Typeface.DEFAULT; // theme display font for English
    public Typeface label = Typeface.DEFAULT;   // clean sans for small text
    public Typeface labelBold = Typeface.DEFAULT_BOLD;
}
