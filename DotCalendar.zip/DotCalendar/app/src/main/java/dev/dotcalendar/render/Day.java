package dev.dotcalendar.render;

/** One day cell: its number, one of Renderer.PASSED / TODAY / HOLIDAY / FUTURE, and optional marks. */
public final class Day {
    public final int number;
    public final int state;
    /** Colour of a ring for one of the user's own dates, or 0 for none. */
    public int mark = 0;
    /** True when the phone calendar has an event that day. */
    public boolean event = false;

    public Day(int number, int state) {
        this.number = number;
        this.state = state;
    }
}
