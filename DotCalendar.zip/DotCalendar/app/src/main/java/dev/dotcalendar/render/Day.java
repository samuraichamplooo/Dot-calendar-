package dev.dotcalendar.render;

/** One day cell: its number and one of Renderer.PASSED / TODAY / HOLIDAY / FUTURE. */
public final class Day {
    public final int number;
    public final int state;

    public Day(int number, int state) {
        this.number = number;
        this.state = state;
    }
}
