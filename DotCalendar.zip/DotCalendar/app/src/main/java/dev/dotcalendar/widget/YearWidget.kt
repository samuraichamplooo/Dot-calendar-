package dev.dotcalendar.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.provideContent
import androidx.glance.currentState
import androidx.glance.layout.Box
import androidx.glance.layout.ContentScale
import androidx.glance.layout.fillMaxSize
import dev.dotcalendar.AppSettings
import dev.dotcalendar.MainActivity
import dev.dotcalendar.RenderBridge
import dev.dotcalendar.SettingsRepo
import dev.dotcalendar.Tx
import kotlinx.coroutines.flow.first
import java.time.LocalDate

/** Year widget: every day of the year as a dot, one row per month. Tap to open the app. */
class YearWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val initial = SettingsRepo.flow(context).first()
        provideContent {
            val flow = remember { SettingsRepo.flow(context) }
            val settings by flow.collectAsState(initial = initial)
            currentState(REFRESH_KEY) // re-render when the day changes
            YearContent(context, settings)
        }
    }
}

@Composable
private fun YearContent(context: Context, s: AppSettings) {
    val size = LocalSize.current
    val w = if (size.width.value > 10f) size.width.value else 320f
    val h = if (size.height.value > 10f) size.height.value else 160f
    val picture = RenderBridge.yearWidgetPicture(context, s, LocalDate.now(), w, h)
    Box(GlanceModifier.fillMaxSize().clickable(actionStartActivity<MainActivity>())) {
        Image(
            provider = ImageProvider(picture.bitmap),
            contentDescription = Tx(s.lang).t("今年のカレンダー", "This year's calendar"),
            modifier = GlanceModifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds,
        )
        picture.pulse?.let { PulseGlow(context, it) }
        picture.spin?.let { SpinningSunflower(context, it) }
    }
}
