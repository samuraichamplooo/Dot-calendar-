package dev.dotcalendar.render;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.util.Random;

/**
 * Minimal dot calendar with four swappable looks (see ThemeSpecs). All coordinates are in dp:
 * callers scale the canvas by the screen density first. Used by both the app and the
 * home-screen widgets so they always match.
 */
public final class Renderer {
    private Renderer() {}

    // Day states
    public static final int PASSED = 0, TODAY = 1, HOLIDAY = 2, FUTURE = 3;
    // Widget backgrounds
    public static final int BG_SOLID = 0, BG_GLASS = 1, BG_BLUR = 2, BG_CLEAR = 3;

    static final int WHITE = 0xFFFFFFFF;
    static final int BLACK = 0xFF000000;
    static final int BONE = 0xFFF2ECDF;
    static final int YELLOW = 0xFFFFD42A;
    static final int CYAN = 0xFF74D6F4;
    static final int GOLD = 0xFFE0B04A;
    static final int GOLD_DARK = 0xFF5E3D10;
    static final int LACQUER = 0xFF15100E;

    // ------------------------------------------------------------------ colour helpers

    public static int withAlpha(int color, float alpha) {
        int a = Math.round(clamp(alpha, 0f, 1f) * 255f);
        return (a << 24) | (color & 0x00FFFFFF);
    }

    public static int mix(int a, int b, float t) {
        t = clamp(t, 0f, 1f);
        int aa = (a >>> 24), ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24), br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return (Math.round(aa + (ba - aa) * t) << 24) | (Math.round(ar + (br - ar) * t) << 16)
                | (Math.round(ag + (bg - ag) * t) << 8) | Math.round(ab + (bb - ab) * t);
    }

    public static float luminance(int c) {
        return (0.299f * ((c >> 16) & 0xFF) + 0.587f * ((c >> 8) & 0xFF) + 0.114f * (c & 0xFF)) / 255f;
    }

    public static int contrastOn(int bg) {
        return luminance(bg) > 0.6f ? 0xFF1B1A18 : WHITE;
    }

    static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    // ------------------------------------------------------------------ paint helpers

    static Paint fill(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        return p;
    }

    static Paint stroke(int color, float width) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(width);
        p.setColor(color);
        return p;
    }

    static Paint text(int color, Typeface tf, float size, Paint.Align align) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        p.setTypeface(tf);
        p.setTextSize(size);
        p.setTextAlign(align);
        return p;
    }

    /** Widget text size multiplier for small labels (Small / Medium / Large in Settings). */
    static float labelK(Style s, boolean widget) {
        return widget ? s.textScale : 1f;
    }

    /** Gentler multiplier for big display text, which is already large. */
    static float titleK(Style s, boolean widget) {
        return widget ? 1f + (s.textScale - 1f) * 0.6f : 1f;
    }

    /** Small clean text (labels, numbers). Bold mode uses the bold face and a touch more size. */
    static Paint label(Style s, int color, float size, Paint.Align align, boolean widget) {
        size *= labelK(s, widget);
        Paint p = text(color, s.bold ? s.labelBold : s.label, s.bold ? size * 1.08f : size, align);
        readable(p, s, widget);
        return p;
    }

    /** Display text in the theme's font. */
    static Paint title(Style s, boolean ja, int color, float size, Paint.Align align, boolean widget) {
        Paint p = text(color, ja ? s.titleJa : s.titleEn, size * titleK(s, widget), align);
        p.setFakeBoldText(s.bold);
        readable(p, s, widget);
        return p;
    }

    /** A soft halo behind text that sits on the wallpaper, so it reads on any picture. */
    static void readable(Paint p, Style s, boolean widget) {
        readable(p, s, widget, false);
    }

    /**
     * A shadow under widget text that sits on the wallpaper, so it reads on any picture. Always a
     * dark drop shadow, never a light glow (a glow round red, blue or green text looks like a halo).
     * {@code tight} keeps it close to the letters, for coloured labels like the weekdays.
     * Nothing on a light wallpaper (dark text needs no help there) or with the shadow turned off.
     */
    static void readable(Paint p, Style s, boolean widget, boolean tight) {
        p.clearShadowLayer();
        if (!widget || s.background == BG_SOLID || s.lightWall || s.shadow == 2) return;
        boolean clear = s.background == BG_CLEAR;
        boolean soft = tight || s.shadow == 1;
        float radius = soft ? (clear ? 1.6f : 1.2f) : (clear ? 2.8f : 2f);
        float alpha = soft ? (clear ? 0.5f : 0.3f) : (clear ? 0.75f : 0.45f);
        p.setShadowLayer(radius, 0f, clear ? 0.9f : 0.5f, withAlpha(BLACK, alpha));
    }

    static void drawCentered(Canvas c, String str, float cx, float cy, Paint p) {
        c.drawText(str, cx, cy - (p.ascent() + p.descent()) / 2f, p);
    }

    static void fit(Paint p, String str, float maxWidth, float minSize) {
        float w = p.measureText(str);
        if (w > maxWidth && w > 0f) p.setTextSize(Math.max(minSize, p.getTextSize() * maxWidth / w));
    }

    static Path roundPath(RectF r, float radius) {
        Path p = new Path();
        p.addRoundRect(r, radius, radius, Path.Direction.CW);
        return p;
    }

    static void glow(Canvas c, float x, float y, float radius, int color) {
        if (radius <= 0f) return;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(x, y, radius, color, color & 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, radius, p);
    }

    // ------------------------------------------------------------------ surfaces

    /** Widget or app body: themed texture (Solid), see-through glass, frosted glass, or nothing. */
    public static void drawSurface(Canvas c, RectF r, float radius, Style s, boolean widget) {
        int mode = widget ? s.background : BG_SOLID;
        if (mode == BG_CLEAR) return;
        Path shape = roundPath(r, radius);
        if (mode == BG_SOLID) {
            c.save();
            c.clipPath(shape);
            texture(c, r, s, widget ? 1f : 0.45f);
            c.restore();
        } else if (mode == BG_GLASS) {
            glass(c, r, radius, shape, s);
        } else {
            frosted(c, r, radius, shape, s);
        }
    }

    static void texture(Canvas c, RectF r, Style s, float density) {
        Paint base = new Paint(Paint.ANTI_ALIAS_FLAG);
        base.setShader(new LinearGradient(r.left, r.top, r.left, r.bottom, s.surface, s.surface2, Shader.TileMode.CLAMP));
        c.drawRect(r, base);
        switch (s.theme) {
            case ThemeSpecs.KI:
                speedLines(c, r);
                break;
            case ThemeSpecs.REI:
                nightSky(c, r, density);
                break;
            case ThemeSpecs.HAGANE:
                iron(c, r, density);
                break;
            case ThemeSpecs.SUMI:
                inkPaper(c, r, density);
                break;
            case ThemeSpecs.DENNOU:
                hud(c, r);
                break;
            case ThemeSpecs.SAMURAI:
                lacquer(c, r, density);
                break;
            case ThemeSpecs.COSMO:
                cosmo(c, r, density);
                break;
            default:
                paperGrain(c, r, density);
                break;
        }
    }

    /** Pale paper with heavy film grain under a soft spotlight. */
    static void inkPaper(Canvas c, RectF r, float density) {
        Random rnd = new Random(13);
        int n = (int) (r.width() * r.height() / 4.5f * density);
        Paint dot = fill(0);
        for (int i = 0; i < n; i++) {
            dot.setColor(rnd.nextInt(3) == 0
                    ? withAlpha(WHITE, 0.10f + rnd.nextFloat() * 0.12f)
                    : withAlpha(BLACK, 0.05f + rnd.nextFloat() * 0.10f));
            c.drawCircle(r.left + rnd.nextFloat() * r.width(), r.top + rnd.nextFloat() * r.height(), 0.25f + rnd.nextFloat() * 0.4f, dot);
        }
        Paint spot = new Paint(Paint.ANTI_ALIAS_FLAG);
        spot.setShader(new RadialGradient(r.centerX(), r.centerY(), Math.max(r.width(), r.height()) * 0.72f,
                new int[]{withAlpha(BLACK, 0f), withAlpha(BLACK, 0f), withAlpha(BLACK, 0.34f)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(r, spot);
    }

    /** Dark HUD glass: soft cyan and magenta light, a fine grid, scanlines and corner brackets. */
    static void hud(Canvas c, RectF r) {
        float big = Math.max(r.width(), r.height());
        glow(c, r.left + r.width() * 0.15f, r.top + r.height() * 0.1f, big * 0.7f, withAlpha(0xFF14E8D6, 0.10f));
        glow(c, r.right, r.bottom, big * 0.6f, withAlpha(0xFFB4FF39, 0.07f));
        Paint grid = stroke(withAlpha(0xFF14E8D6, 0.06f), 0.5f);
        for (float x = r.left + 12f; x < r.right; x += 12f) c.drawLine(x, r.top, x, r.bottom, grid);
        for (float y = r.top + 12f; y < r.bottom; y += 12f) c.drawLine(r.left, y, r.right, y, grid);
        Paint scan = stroke(withAlpha(BLACK, 0.22f), 0.6f);
        for (float y = r.top + 1f; y < r.bottom; y += 2.4f) c.drawLine(r.left, y, r.right, y, scan);
        float len = clamp(Math.min(r.width(), r.height()) * 0.07f, 8f, 18f), in = 6f;
        Paint br = stroke(withAlpha(0xFF14E8D6, 0.6f), 1.2f);
        br.setStrokeCap(Paint.Cap.SQUARE);
        float l = r.left + in, t = r.top + in, rr = r.right - in, b = r.bottom - in;
        c.drawLine(l, t, l + len, t, br); c.drawLine(l, t, l, t + len, br);
        c.drawLine(rr, t, rr - len, t, br); c.drawLine(rr, t, rr, t + len, br);
        c.drawLine(l, b, l + len, b, br); c.drawLine(l, b, l, b - len, br);
        c.drawLine(rr, b, rr - len, b, br); c.drawLine(rr, b, rr, b - len, br);
    }

    /**
     * Black urushi lacquer: a soft gloss, faint rows of armour plates laced with crimson cord
     * (strongest low down, fading out upward), and gold dust drifting from the top corner.
     */
    static void lacquer(Canvas c, RectF r, float density) {
        Paint gloss = new Paint(Paint.ANTI_ALIAS_FLAG);
        gloss.setShader(new LinearGradient(r.left, r.top, r.left + r.width() * 0.55f, r.top + r.height() * 0.9f,
                new int[]{withAlpha(WHITE, 0.08f), withAlpha(WHITE, 0.015f), withAlpha(WHITE, 0f)},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(r, gloss);
        float row = 15f;
        float start = r.top + r.height() * 0.5f;
        Paint shadow = stroke(0, 1f);
        Paint hi = stroke(0, 0.7f);
        Paint cord = stroke(0, 1.1f);
        for (float y = r.bottom - row * 0.6f; y > start; y -= row) {
            float fade = clamp((y - start) / (r.bottom - start), 0f, 1f);
            shadow.setColor(withAlpha(BLACK, 0.32f * fade));
            hi.setColor(withAlpha(WHITE, 0.05f * fade));
            c.drawLine(r.left, y, r.right, y, shadow);
            c.drawLine(r.left, y + 1f, r.right, y + 1f, hi);
            cord.setColor(withAlpha(0xFFC62A2F, 0.15f * fade));
            for (float x = r.left + 16f; x < r.right - 4f; x += 30f) {
                c.drawLine(x, y - row * 0.32f, x, y + row * 0.32f, cord);
                c.drawLine(x + 3.2f, y - row * 0.32f, x + 3.2f, y + row * 0.32f, cord);
            }
        }
        Random rnd = new Random(29);
        int n = (int) (r.width() * r.height() / 160f * Math.max(0.5f, density));
        Paint dust = fill(0);
        for (int i = 0; i < n; i++) {
            float u = (float) Math.pow(rnd.nextFloat(), 2.4), v = (float) Math.pow(rnd.nextFloat(), 2.4);
            dust.setColor(withAlpha(GOLD, 0.10f + rnd.nextFloat() * 0.32f));
            c.drawCircle(r.right - u * r.width(), r.top + v * r.height(), 0.3f + rnd.nextFloat() * 0.55f, dust);
        }
        Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        edge.setShader(new RadialGradient(r.centerX(), r.centerY(), Math.max(r.width(), r.height()) * 0.72f,
                withAlpha(BLACK, 0f), withAlpha(BLACK, 0.4f), Shader.TileMode.CLAMP));
        c.drawRect(r, edge);
    }

    /**
     * Retro space jazz: stars, a faint ringed planet off the top corner, and three flat
     * 70s colour bars (orange, mustard, teal) running along the bottom edge.
     */
    static void cosmo(Canvas c, RectF r, float density) {
        float small = Math.min(r.width(), r.height());
        float pr = clamp(small * 0.42f, 28f, 110f);
        float px = r.right - pr * 0.3f, py = r.top + pr * 0.2f;
        glow(c, px, py, pr * 1.8f, withAlpha(0xFFFF8A3D, 0.09f));
        Paint planet = new Paint(Paint.ANTI_ALIAS_FLAG);
        planet.setShader(new RadialGradient(px - pr * 0.35f, py + pr * 0.35f, pr * 1.3f,
                withAlpha(0xFFF2B63C, 0.22f), withAlpha(0xFFB0502A, 0.08f), Shader.TileMode.CLAMP));
        c.drawCircle(px, py, pr, planet);
        c.save();
        c.rotate(-16f, px, py);
        c.drawOval(new RectF(px - pr * 1.75f, py - pr * 0.3f, px + pr * 1.75f, py + pr * 0.3f),
                stroke(withAlpha(0xFFF5ECDA, 0.13f), Math.max(1f, pr * 0.035f)));
        c.restore();
        Random rnd = new Random(37);
        int n = (int) (r.width() * r.height() / 520f * Math.max(density, 0.6f));
        Paint star = fill(0);
        for (int i = 0; i < n; i++) {
            star.setColor(withAlpha(WHITE, 0.12f + rnd.nextFloat() * 0.4f));
            c.drawCircle(r.left + rnd.nextFloat() * r.width(), r.top + rnd.nextFloat() * r.height(), 0.3f + rnd.nextFloat() * 0.5f, star);
        }
        int[] bars = {0xFF2FB0C2, 0xFFF2B63C, 0xFFFF6A33};
        float bh = 1.6f, gap = 1.3f;
        for (int i = 0; i < 3; i++) {
            float y = r.bottom - 3.5f - (i + 1) * bh - i * gap;
            c.drawRect(r.left, y, r.right, y + bh, fill(withAlpha(bars[i], 0.85f)));
        }
    }

    /** Grey poster paper with fine grain. */
    static void paperGrain(Canvas c, RectF r, float density) {
        Random rnd = new Random(5);
        int n = (int) (r.width() * r.height() / 6f * density);
        Paint dot = fill(0);
        for (int i = 0; i < n; i++) {
            dot.setColor(rnd.nextBoolean()
                    ? withAlpha(WHITE, 0.05f + rnd.nextFloat() * 0.08f)
                    : withAlpha(BLACK, 0.05f + rnd.nextFloat() * 0.09f));
            c.drawCircle(r.left + rnd.nextFloat() * r.width(), r.top + rnd.nextFloat() * r.height(), 0.25f + rnd.nextFloat() * 0.35f, dot);
        }
        Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG);
        shade.setShader(new RadialGradient(r.centerX(), r.centerY(), Math.max(r.width(), r.height()) * 0.75f,
                withAlpha(BLACK, 0f), withAlpha(BLACK, 0.12f), Shader.TileMode.CLAMP));
        c.drawRect(r, shade);
    }

    /** Manga speed lines radiating from beyond the top-right corner. */
    static void speedLines(Canvas c, RectF r) {
        float fx = r.right + r.width() * 0.15f, fy = r.top - r.height() * 0.25f;
        glow(c, r.right, r.top, Math.max(r.width(), r.height()) * 0.7f, withAlpha(0xFFFF8A1A, 0.16f));
        Random rnd = new Random(9);
        float far = (float) Math.hypot(r.width(), r.height()) * 1.6f;
        Paint p = fill(0);
        Path wedge = new Path();
        for (int i = 0; i < 46; i++) {
            double a = Math.toRadians(95 + rnd.nextFloat() * 90);
            float near = far * (0.30f + rnd.nextFloat() * 0.25f);
            float spread = 0.004f + rnd.nextFloat() * 0.006f;
            float x1 = fx + (float) Math.cos(a) * near, y1 = fy + (float) Math.sin(a) * near;
            float x2 = fx + (float) Math.cos(a - spread) * far, y2 = fy + (float) Math.sin(a - spread) * far;
            float x3 = fx + (float) Math.cos(a + spread) * far, y3 = fy + (float) Math.sin(a + spread) * far;
            wedge.reset();
            wedge.moveTo(x1, y1);
            wedge.lineTo(x2, y2);
            wedge.lineTo(x3, y3);
            wedge.close();
            p.setColor(withAlpha(WHITE, 0.035f + rnd.nextFloat() * 0.05f));
            c.drawPath(wedge, p);
        }
    }

    /** Deep teal-blue night: a soft nebula, faint stars and two sparkle glints. */
    static void nightSky(Canvas c, RectF r, float density) {
        float big = Math.max(r.width(), r.height());
        glow(c, r.left + r.width() * 0.85f, r.top + r.height() * 0.2f, big * 0.6f, withAlpha(0xFF22B5B0, 0.26f));
        glow(c, r.left + r.width() * 0.1f, r.bottom, big * 0.5f, withAlpha(0xFF3B6FD8, 0.18f));
        Random rnd = new Random(17);
        int stars = (int) (r.width() * r.height() / 900f * Math.max(density, 0.6f));
        Paint p = fill(0);
        for (int i = 0; i < stars; i++) {
            p.setColor(withAlpha(WHITE, 0.15f + rnd.nextFloat() * 0.35f));
            c.drawCircle(r.left + rnd.nextFloat() * r.width(), r.top + rnd.nextFloat() * r.height(), 0.35f + rnd.nextFloat() * 0.5f, p);
        }
        float k = Math.min(r.width(), r.height());
        drawSparkle(c, r.left + r.width() * 0.58f, r.top + clamp(k * 0.035f, 4f, 9f), clamp(k * 0.06f, 6f, 16f), withAlpha(WHITE, 0.85f));
        drawSparkle(c, r.left + r.width() * 0.97f, r.top + r.height() * 0.55f, clamp(k * 0.04f, 4f, 10f), withAlpha(0xFFBFD8FF, 0.7f));
    }

    /** Dark iron: grit, faint scratches and a teal haze from above. */
    static void iron(Canvas c, RectF r, float density) {
        Paint haze = new Paint(Paint.ANTI_ALIAS_FLAG);
        haze.setShader(new LinearGradient(r.left, r.top, r.left, r.top + r.height() * 0.7f,
                withAlpha(0xFF2D4640, 0.55f), withAlpha(0xFF2D4640, 0f), Shader.TileMode.CLAMP));
        c.drawRect(r, haze);
        Random rnd = new Random(31);
        int n = (int) (r.width() * r.height() / 9f * density);
        Paint dot = fill(0);
        for (int i = 0; i < n; i++) {
            dot.setColor(rnd.nextInt(3) == 0 ? withAlpha(WHITE, 0.04f + rnd.nextFloat() * 0.05f) : withAlpha(BLACK, 0.2f + rnd.nextFloat() * 0.2f));
            c.drawCircle(r.left + rnd.nextFloat() * r.width(), r.top + rnd.nextFloat() * r.height(), 0.3f + rnd.nextFloat() * 0.4f, dot);
        }
        Paint scratch = stroke(0, 0.5f);
        scratch.setStrokeCap(Paint.Cap.ROUND);
        int lines = 6 + (int) (r.width() * r.height() / 9000f);
        for (int i = 0; i < lines; i++) {
            float x = r.left + rnd.nextFloat() * r.width(), y = r.top + rnd.nextFloat() * r.height();
            double a = Math.toRadians(-30 + rnd.nextFloat() * 60);
            float len = 10f + rnd.nextFloat() * 40f;
            scratch.setColor(withAlpha(WHITE, 0.04f + rnd.nextFloat() * 0.05f));
            c.drawLine(x, y, x + (float) Math.cos(a) * len, y + (float) Math.sin(a) * len, scratch);
        }
        Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        edge.setShader(new RadialGradient(r.centerX(), r.centerY(), Math.max(r.width(), r.height()) * 0.72f,
                withAlpha(BLACK, 0f), withAlpha(BLACK, 0.45f), Shader.TileMode.CLAMP));
        c.drawRect(r, edge);
    }

    static void glass(Canvas c, RectF r, float radius, Path shape, Style s) {
        if (s.lightWall) {
            lightGlass(c, r, radius, shape, s, false);
            return;
        }
        int tint = mix(s.surface2, BLACK, 0.35f);
        c.drawPath(shape, fill(withAlpha(tint, 0.18f + 0.5f * s.opacity)));
        c.save();
        c.clipPath(shape);
        Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
        sheen.setShader(new LinearGradient(r.left, r.top, r.left + r.width() * 0.6f, r.bottom,
                new int[]{withAlpha(WHITE, 0.16f), withAlpha(WHITE, 0.03f), withAlpha(WHITE, 0f)},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(r, sheen);
        c.restore();
        RectF e = new RectF(r);
        e.inset(0.5f, 0.5f);
        Paint edge = stroke(0, 1f);
        edge.setShader(new LinearGradient(r.left, r.top, r.left, r.bottom,
                withAlpha(WHITE, 0.45f), withAlpha(WHITE, 0.10f), Shader.TileMode.CLAMP));
        c.drawRoundRect(e, radius - 0.5f, radius - 0.5f, edge);
    }

    /** Android can't blur the wallpaper behind a widget, so this is drawn as frosted glass. */
    static void frosted(Canvas c, RectF r, float radius, Path shape, Style s) {
        if (s.lightWall) {
            lightGlass(c, r, radius, shape, s, true);
            return;
        }
        int tint = mix(s.surface, BLACK, 0.3f);
        c.drawPath(shape, fill(withAlpha(tint, 0.45f + 0.45f * s.opacity)));
        c.save();
        c.clipPath(shape);
        float big = Math.max(r.width(), r.height());
        glow(c, r.left + r.width() * 0.85f, r.top + r.height() * 0.15f, big * 0.55f, withAlpha(s.accent, 0.18f));
        glow(c, r.left + r.width() * 0.1f, r.bottom - r.height() * 0.1f, big * 0.5f, withAlpha(s.today, 0.12f));
        Random rnd = new Random(23);
        int n = (int) (r.width() * r.height() / 14f);
        Paint g = fill(0);
        for (int i = 0; i < n; i++) {
            g.setColor(withAlpha(WHITE, 0.03f + rnd.nextFloat() * 0.05f));
            c.drawCircle(r.left + rnd.nextFloat() * r.width(), r.top + rnd.nextFloat() * r.height(), 0.3f + rnd.nextFloat() * 0.3f, g);
        }
        c.restore();
        RectF e = new RectF(r);
        e.inset(0.5f, 0.5f);
        c.drawRoundRect(e, radius - 0.5f, radius - 0.5f, stroke(withAlpha(WHITE, 0.22f), 1f));
    }

    /** Pale glass (or frosted glass) for a light wallpaper, so dark text sits on a light panel. */
    static void lightGlass(Canvas c, RectF r, float radius, Path shape, Style s, boolean frost) {
        int tint = mix(s.passed, WHITE, 0.9f);
        c.drawPath(shape, fill(withAlpha(tint, frost ? 0.55f + 0.4f * s.opacity : 0.22f + 0.45f * s.opacity)));
        c.save();
        c.clipPath(shape);
        if (frost) {
            Random rnd = new Random(23);
            int n = (int) (r.width() * r.height() / 14f);
            Paint g = fill(0);
            for (int i = 0; i < n; i++) {
                g.setColor(withAlpha(BLACK, 0.02f + rnd.nextFloat() * 0.03f));
                c.drawCircle(r.left + rnd.nextFloat() * r.width(), r.top + rnd.nextFloat() * r.height(), 0.3f + rnd.nextFloat() * 0.3f, g);
            }
        }
        Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
        sheen.setShader(new LinearGradient(r.left, r.top, r.left + r.width() * 0.6f, r.bottom,
                new int[]{withAlpha(WHITE, 0.5f), withAlpha(WHITE, 0.1f), withAlpha(WHITE, 0f)},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(r, sheen);
        c.restore();
        RectF e = new RectF(r);
        e.inset(0.5f, 0.5f);
        c.drawRoundRect(e, radius - 0.5f, radius - 0.5f, stroke(withAlpha(BLACK, 0.12f), 1f));
    }

    // ------------------------------------------------------------------ motifs

    /** Four-point sparkle glint. */
    public static void drawSparkle(Canvas c, float cx, float cy, float size, int color) {
        float r = size / 2f, w = size * 0.07f;
        glow(c, cx, cy, size * 0.45f, withAlpha(color, 0.45f * ((color >>> 24) / 255f)));
        Path p = new Path();
        p.moveTo(cx, cy - r);
        p.quadTo(cx + w, cy - w, cx + r, cy);
        p.quadTo(cx + w, cy + w, cx, cy + r);
        p.quadTo(cx - w, cy + w, cx - r, cy);
        p.quadTo(cx - w, cy - w, cx, cy - r);
        p.close();
        c.drawPath(p, fill(color));
        c.drawCircle(cx, cy, Math.max(0.8f, size * 0.06f), fill(WHITE));
    }

    /** Ukiyo-e cloud with a pale moon behind it. */
    public static void drawCloud(Canvas c, float cx, float cy, float w, int color) {
        float h = w * 0.13f;
        c.drawCircle(cx + w * 0.14f, cy - w * 0.04f, w * 0.17f, fill(withAlpha(color, 0.95f)));
        Paint p = fill(color);
        c.drawRoundRect(new RectF(cx - w * 0.5f, cy - h / 2f, cx + w * 0.22f, cy + h / 2f), h / 2f, h / 2f, p);
        c.drawRoundRect(new RectF(cx - w * 0.22f, cy + h * 0.55f, cx + w * 0.5f, cy + h * 1.55f), h / 2f, h / 2f, p);
        c.drawRoundRect(new RectF(cx - w * 0.38f, cy - h * 1.45f, cx + w * 0.02f, cy - h * 0.45f), h / 2f, h / 2f, p);
    }

    /**
     * A hand-painted ink stroke: thick where the brush lands, tapering out, with dry-brush
     * streaks near the end.
     */
    public static void drawBrushStroke(Canvas c, float x0, float y, float x1, float thickness, int color, long seed) {
        if (x1 - x0 < 4f) return;
        Random rnd = new Random(seed);
        int n = 28;
        float[] top = new float[n + 1], bot = new float[n + 1], xs = new float[n + 1];
        for (int i = 0; i <= n; i++) {
            float t = i / (float) n;
            float w = thickness * (t < 0.12f ? 0.55f + t / 0.12f * 0.45f : 1f - (t - 0.12f) / 0.88f * 0.8f);
            float bend = (float) Math.sin(t * Math.PI) * thickness * 0.35f;
            xs[i] = x0 + (x1 - x0) * t;
            top[i] = y - bend - w / 2f + (rnd.nextFloat() - 0.5f) * thickness * 0.12f;
            bot[i] = y - bend + w / 2f + (rnd.nextFloat() - 0.5f) * thickness * 0.12f;
        }
        Path p = new Path();
        p.moveTo(xs[0], top[0]);
        for (int i = 1; i <= n; i++) p.lineTo(xs[i], top[i]);
        for (int i = n; i >= 0; i--) p.lineTo(xs[i], bot[i]);
        p.close();
        RectF bounds = new RectF(x0 - thickness, y - thickness * 2f, x1 + 2f, y + thickness * 2f);
        int save = c.saveLayer(bounds, null);
        c.drawPath(p, fill(color));
        c.drawCircle(xs[0] + thickness * 0.15f, (top[0] + bot[0]) / 2f, (bot[0] - top[0]) / 2f, fill(color));
        Paint gap = stroke(0, Math.max(0.4f, thickness * 0.09f));
        gap.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        for (int k = 0; k < 3; k++) {
            float start = 0.35f + rnd.nextFloat() * 0.25f;
            float off = (rnd.nextFloat() - 0.5f) * thickness * 0.5f;
            Path g = new Path();
            int i0 = (int) (start * n);
            g.moveTo(xs[i0], (top[i0] + bot[i0]) / 2f + off);
            for (int i = i0 + 1; i <= n; i++) g.lineTo(xs[i], (top[i] + bot[i]) / 2f + off * (1f - (i - i0) / (float) (n - i0)));
            c.drawPath(g, gap);
        }
        c.restoreToCount(save);
    }

    /** The theme's mark under a title or the big date. {@code size} is the text size it sits under. */
    public static void drawTitleMark(Canvas c, float x, float baseline, float width, float size, Style s) {
        switch (s.theme) {
            case ThemeSpecs.KI: {
                float t = Math.max(2.5f, size * 0.15f), y = baseline + size * 0.16f, slant = t * 0.9f;
                Path bar = new Path();
                bar.moveTo(x + slant, y);
                bar.lineTo(x + width * 0.82f + slant, y);
                bar.lineTo(x + width * 0.82f, y + t);
                bar.lineTo(x, y + t);
                bar.close();
                c.drawPath(bar, fill(s.accent));
                Path tip = new Path();
                float tx = x + width * 0.82f + t * 0.8f;
                tip.moveTo(tx + slant, y);
                tip.lineTo(tx + width * 0.18f + slant, y);
                tip.lineTo(tx + width * 0.18f, y + t);
                tip.lineTo(tx, y + t);
                tip.close();
                c.drawPath(tip, fill(YELLOW));
                break;
            }
            case ThemeSpecs.REI: {
                float y = baseline + size * 0.2f;
                Paint line = stroke(s.accent, Math.max(1.3f, size * 0.07f));
                line.setStrokeCap(Paint.Cap.ROUND);
                c.drawLine(x, y, x + width, y, line);
                drawSparkle(c, x + width + size * 0.5f, baseline - size * 0.8f, size * 0.42f, WHITE);
                break;
            }
            case ThemeSpecs.HAGANE: {
                drawBrushStroke(c, x - 2f, baseline + size * 0.18f, x + width + 8f, Math.max(3f, size * 0.24f), withAlpha(s.accent, 0.95f), 3L);
                Random rnd = new Random(4);
                for (int i = 0; i < 4; i++) {
                    float dx = x + width + 6f + rnd.nextFloat() * size * 0.5f;
                    float dy = baseline + size * (0.05f + rnd.nextFloat() * 0.3f);
                    c.drawCircle(dx, dy, 0.6f + rnd.nextFloat() * size * 0.05f, fill(withAlpha(s.accent, 0.9f)));
                }
                break;
            }
            case ThemeSpecs.SUMI:
                drawBrushStroke(c, x - 4f, baseline + size * 0.2f, x + width + 12f, Math.max(3f, size * 0.24f), withAlpha(s.accent, 0.88f), 11L);
                break;
            case ThemeSpecs.COSMO: {
                float th = Math.max(1.4f, size * 0.07f), y = baseline + size * 0.15f;
                int[] cols = {0xFFFF6A33, 0xFFF2B63C, s.accent};
                for (int i = 0; i < 3; i++) {
                    float yy = y + i * th * 1.7f;
                    float x0 = x + i * th * 2.2f;
                    c.drawRect(x0, yy, x + width + size * 0.12f - i * th * 2.2f, yy + th, fill(cols[i]));
                }
                break;
            }
            case ThemeSpecs.SAMURAI:
                drawKatana(c, x - 2f, baseline + size * 0.24f, x + width + size * 0.3f, Math.max(2.2f, size * 0.105f), s.accent);
                break;
            case ThemeSpecs.DENNOU: {
                float y = baseline + size * 0.2f;
                Paint line = stroke(s.accent, Math.max(1.2f, size * 0.06f));
                c.drawLine(x, y, x + width, y, line);
                c.drawRect(x + width - size * 0.3f, y - size * 0.07f, x + width, y + size * 0.07f, fill(s.accent));
                float cx0 = x + width + size * 0.16f;
                c.drawRect(cx0, baseline - size * 0.62f, cx0 + size * 0.28f, baseline, fill(withAlpha(s.todayLabel, 0.9f)));
                break;
            }
            default:
                drawBrushStroke(c, x - 3f, baseline + size * 0.2f, x + width + 10f, Math.max(3f, size * 0.2f), withAlpha(s.accent, 0.92f), 7L);
                break;
        }
    }

    /** The theme's seal: hanko, comic burst, orb, or riveted iron plate. */
    public static void drawSeal(Canvas c, RectF r, String glyph, Style s) {
        float cx = r.centerX(), cy = r.centerY(), w = r.width();
        switch (s.theme) {
            case ThemeSpecs.KI: {
                Path burst = starPath(cx, cy, w * 0.62f, w * 0.42f, 10, 0f, 0L);
                c.drawPath(burst, fill(YELLOW));
                c.drawPath(burst, stroke(0xFFE86A00, Math.max(0.6f, w * 0.05f)));
                Paint t = text(0xFF14244A, s.titleJa, w * 0.5f, Paint.Align.CENTER);
                drawCentered(c, glyph, cx, cy, t);
                break;
            }
            case ThemeSpecs.REI: {
                glow(c, cx, cy, w * 0.75f, withAlpha(CYAN, 0.45f));
                Paint orb = new Paint(Paint.ANTI_ALIAS_FLAG);
                orb.setShader(new RadialGradient(cx - w * 0.12f, cy - w * 0.12f, w * 0.6f, 0xFF9BE6FA, 0xFF3A6FD8, Shader.TileMode.CLAMP));
                c.drawCircle(cx, cy, w * 0.5f, orb);
                Paint t = text(WHITE, s.titleJa, w * 0.54f, Paint.Align.CENTER);
                drawCentered(c, glyph, cx, cy, t);
                break;
            }
            case ThemeSpecs.HAGANE: {
                float rad = w * 0.16f;
                Paint plate = new Paint(Paint.ANTI_ALIAS_FLAG);
                plate.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom, 0xFF5A605C, 0xFF262A28, Shader.TileMode.CLAMP));
                c.drawRoundRect(r, rad, rad, plate);
                c.drawRoundRect(r, rad, rad, stroke(0xFF0B0C0B, Math.max(0.6f, w * 0.04f)));
                float in = w * 0.15f;
                Paint rivet = fill(0xFF8E948F);
                c.drawCircle(r.left + in, r.top + in, w * 0.05f, rivet);
                c.drawCircle(r.right - in, r.top + in, w * 0.05f, rivet);
                c.drawCircle(r.left + in, r.bottom - in, w * 0.05f, rivet);
                c.drawCircle(r.right - in, r.bottom - in, w * 0.05f, rivet);
                Paint t = text(BONE, s.titleJa, w * 0.56f, Paint.Align.CENTER);
                drawCentered(c, glyph, cx, cy, t);
                break;
            }
            case ThemeSpecs.DENNOU: {
                glow(c, cx, cy, w * 0.8f, withAlpha(s.accent, 0.35f));
                Path hex = new Path();
                for (int i = 0; i < 6; i++) {
                    double a = Math.toRadians(30 + i * 60);
                    float x = cx + (float) Math.cos(a) * w * 0.54f, y = cy + (float) Math.sin(a) * w * 0.54f;
                    if (i == 0) hex.moveTo(x, y); else hex.lineTo(x, y);
                }
                hex.close();
                c.drawPath(hex, fill(0xFF071014));
                c.drawPath(hex, stroke(s.accent, Math.max(1f, w * 0.06f)));
                Paint t = text(s.accent, s.titleJa, w * 0.5f, Paint.Align.CENTER);
                drawCentered(c, glyph, cx, cy, t);
                break;
            }
            case ThemeSpecs.COSMO: {
                float pr = w * 0.44f;
                Paint pl = new Paint(Paint.ANTI_ALIAS_FLAG);
                pl.setShader(new RadialGradient(cx - pr * 0.3f, cy - pr * 0.35f, pr * 1.4f, 0xFFF8CF6A, 0xFFE0682C, Shader.TileMode.CLAMP));
                c.drawCircle(cx, cy, pr, pl);
                Paint t = text(0xFF1A1B26, s.titleJa, w * 0.5f, Paint.Align.CENTER);
                drawCentered(c, glyph, cx, cy, t);
                c.save();
                c.rotate(-22f, cx, cy);
                c.drawOval(new RectF(cx - w * 0.66f, cy - w * 0.15f, cx + w * 0.66f, cy + w * 0.15f),
                        stroke(withAlpha(0xFFF5ECDA, 0.95f), Math.max(0.6f, w * 0.055f)));
                c.restore();
                break;
            }
            case ThemeSpecs.SAMURAI: {
                float rad = w * 0.12f;
                Paint plate = new Paint(Paint.ANTI_ALIAS_FLAG);
                plate.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom, 0xFF2C221C, 0xFF0B0908, Shader.TileMode.CLAMP));
                c.drawRoundRect(r, rad, rad, plate);
                c.drawRoundRect(r, rad, rad, stroke(GOLD, Math.max(0.8f, w * 0.06f)));
                RectF in = new RectF(r);
                in.inset(w * 0.14f, r.height() * 0.14f);
                c.drawRoundRect(in, rad * 0.5f, rad * 0.5f, stroke(withAlpha(GOLD, 0.5f), Math.max(0.5f, w * 0.03f)));
                Paint t = text(GOLD, s.titleJa, r.height() * 0.56f, Paint.Align.CENTER);
                drawCentered(c, glyph, cx, cy, t);
                break;
            }
            default: {
                float rad = w * 0.14f;
                c.drawRoundRect(r, rad, rad, fill(s.theme == ThemeSpecs.SUMI ? s.holiday : s.accent));
                RectF in = new RectF(r);
                in.inset(w * 0.1f, r.height() * 0.1f);
                c.drawRoundRect(in, rad * 0.5f, rad * 0.5f, stroke(withAlpha(BONE, 0.85f), Math.max(0.6f, w * 0.045f)));
                Paint t = text(BONE, s.titleJa, r.height() * 0.58f, Paint.Align.CENTER);
                drawCentered(c, glyph, cx, cy, t);
                break;
            }
        }
    }

    /** Small "日 / EN" switch: the active language is bright with an accent dot under it. */
    public static void drawLangChip(Canvas c, RectF r, boolean japanese, Style s, boolean widget) {
        float rad = r.height() / 2f;
        if (widget && s.background == BG_CLEAR) c.drawRoundRect(r, rad, rad, fill(withAlpha(s.lightWall ? WHITE : BLACK, s.lightWall ? 0.5f : 0.28f)));
        c.drawRoundRect(r, rad, rad, stroke(withAlpha(s.text, 0.4f), 1.1f));
        float cw = r.width() / 2f;
        float jx = r.left + cw * 0.58f + 1f, ex = r.left + cw * 1.42f - 1f;
        float k = labelK(s, widget);
        Paint ja = label(s, withAlpha(s.text, japanese ? 1f : 0.45f), r.height() * 0.56f / k, Paint.Align.CENTER, widget);
        Paint en = label(s, withAlpha(s.text, japanese ? 0.45f : 1f), r.height() * 0.46f / k, Paint.Align.CENTER, widget);
        en.setTypeface(s.labelBold);
        drawCentered(c, "日", jx, r.centerY() - 0.5f, ja);
        drawCentered(c, "EN", ex, r.centerY() - 0.5f, en);
        c.drawCircle(japanese ? jx : ex, r.bottom - 2.6f, 1.3f, fill(s.accent == s.holiday ? s.todayLabel : s.accent));
    }

    // ------------------------------------------------------------------ days

    public static void drawDay(Canvas c, float cx, float cy, float cell, Day d, Style s, boolean widget) {
        boolean icon = d.state == TODAY && s.todayIcon;
        if (d.state == TODAY && widget) {
            s.todayX = cx;
            s.todayY = cy;
            s.todayCell = cell;
        }
        if (d.mark != 0) {
            // ring for one of the user's own dates
            float rr = icon ? cell * 0.47f : Math.max(dotSize(cell, s) * 0.5f + Math.max(2.2f, cell * 0.09f), cell * 0.34f);
            Paint ring = stroke(d.mark, Math.max(1.4f, cell * 0.055f));
            if (s.squares && !icon) {
                float k = rr * 0.32f;
                c.drawRoundRect(new RectF(cx - rr, cy - rr, cx + rr, cy + rr), k, k, ring);
            } else {
                c.drawCircle(cx, cy, rr, ring);
            }
        }
        drawDayBody(c, cx, cy, cell, d, s);
        if (d.event) {
            // small mark under the day for a phone-calendar event
            float my = cy + (icon ? cell * 0.47f : Math.min(cell * 0.42f, dotSize(cell, s) * 0.5f + Math.max(3f, cell * 0.12f)));
            c.drawCircle(cx, my, Math.max(1.3f, cell * 0.05f), fill(s.accent == s.passed ? s.text : s.accent));
        }
    }

    static void drawDayBody(Canvas c, float cx, float cy, float cell, Day d, Style s) {
        float dot = dotSize(cell, s);
        float r = dot / 2f;
        if (d.state == TODAY) {
            if (s.todayIcon) {
                int numberColor = drawTodayIcon(c, cx, cy, cell, s);
                if (s.numbers) numberIn(c, cx, cy, dot * 0.9f, d.number, numberColor, s);
                return;
            }
            glow(c, cx, cy, dot * 1.3f, withAlpha(s.today, 0.42f));
        }
        boolean filled = d.state == PASSED || d.state == TODAY;
        int color;
        if (d.state == PASSED) color = s.passed;
        else if (d.state == TODAY) color = s.today;
        else if (d.state == HOLIDAY) color = s.holiday;
        else color = s.future;

        if (filled) {
            if (s.theme == ThemeSpecs.SUMI && !s.squares) {
                c.drawPath(inkBlot(cx, cy, r * 1.14f, d.number * 31L + 7L), fill(withAlpha(color, 0.14f)));
                c.drawPath(inkBlot(cx, cy, r, d.number * 17L + 3L), fill(color));
            } else if (s.theme == ThemeSpecs.SAMURAI) {
                // gold leaf: a lighter top-left catching the light
                Paint leaf = new Paint(Paint.ANTI_ALIAS_FLAG);
                leaf.setShader(new RadialGradient(cx - r * 0.35f, cy - r * 0.4f, r * 1.5f,
                        mix(color, WHITE, 0.35f), mix(color, BLACK, 0.22f), Shader.TileMode.CLAMP));
                shape(c, cx, cy, r, leaf, s);
            } else {
                shape(c, cx, cy, r, fill(color), s);
            }
            if (s.numbers) numberIn(c, cx, cy, dot, d.number, contrastOn(color), s);
        } else if (d.state == HOLIDAY) {
            float lw = Math.max(1.4f, dot * 0.12f);
            shape(c, cx, cy, r - lw / 2f, stroke(color, lw), s);
            if (s.numbers) numberIn(c, cx, cy, dot, d.number, color, s);
        } else {
            shape(c, cx, cy, r, fill(color), s);
            if (s.numbers) numberIn(c, cx, cy, dot, d.number, mix(color, s.text, 0.75f), s);
        }
    }

    /** Draws today's theme icon and returns a readable colour for a number on top of it. */
    static int drawTodayIcon(Canvas c, float cx, float cy, float cell, Style s) {
        switch (s.theme) {
            case ThemeSpecs.KI:
                if (s.todayAlt) drawKiWave(c, cx, cy, cell * 1.0f, s.lightWall);
                else drawKiBurst(c, cx, cy, cell * 0.96f, s);
                return 0xFF14244A;
            case ThemeSpecs.REI:
                drawSpiritOrb(c, cx, cy, cell * 0.95f, s);
                return 0xFF14244A;
            case ThemeSpecs.HAGANE:
                if (s.todayAlt) drawSwordSlash(c, cx, cy, cell * 0.92f, s.today);
                else drawInkSplash(c, cx, cy, cell * 0.9f, s.today);
                return WHITE;
            case ThemeSpecs.SUMI:
                drawEnso(c, cx, cy, cell * 0.92f, s.today, 1f, 5L);
                return s.today;
            case ThemeSpecs.DENNOU:
                drawReticle(c, cx, cy, cell * 0.95f, s.today);
                return WHITE;
            case ThemeSpecs.COSMO:
                drawRocket(c, cx, cy, cell * 1.0f, s);
                return WHITE;
            case ThemeSpecs.SAMURAI:
                if (s.todayAlt) drawKabuto(c, cx, cy, cell * 1.0f, s);
                else drawCrossedKatanas(c, cx, cy, cell * 1.0f, s);
                return WHITE;
            default:
                drawSunflower(c, cx, cy, cell * 1.0f);
                return WHITE;
        }
    }

    static void drawBlank(Canvas c, float cx, float cy, float cell, Style s) {
        float r = dotSize(cell, s) / 2f;
        shape(c, cx, cy, r, fill(withAlpha(s.future, 0.4f)), s);
    }

    static float dotSize(float cell, Style s) {
        return s.numbers ? cell * 0.74f : cell * 0.48f;
    }

    static void shape(Canvas c, float cx, float cy, float r, Paint p, Style s) {
        if (s.squares) {
            float rr = r * 0.32f;
            c.drawRoundRect(new RectF(cx - r, cy - r, cx + r, cy + r), rr, rr, p);
        } else {
            c.drawCircle(cx, cy, r, p);
        }
    }

    static void numberIn(Canvas c, float cx, float cy, float dot, int n, int color, Style s) {
        if (dot < 11f) return;
        Paint t = text(color, s.labelBold, dot * 0.44f, Paint.Align.CENTER);
        drawCentered(c, String.valueOf(n), cx, cy, t);
    }

    static Path petal(float cx, float cy, float inner, float outer, float halfWidth) {
        Path p = new Path();
        float len = outer - inner;
        p.moveTo(cx, cy - inner);
        p.cubicTo(cx + halfWidth, cy - inner - len * 0.2f, cx + halfWidth * 0.75f, cy - outer + len * 0.25f, cx, cy - outer);
        p.cubicTo(cx - halfWidth * 0.75f, cy - outer + len * 0.25f, cx - halfWidth, cy - inner - len * 0.2f, cx, cy - inner);
        p.close();
        return p;
    }

    /** 🌻 Bright yellow petals in two rings, green sepals peeking between, a seeded brown centre. */
    public static void drawSunflower(Canvas c, float cx, float cy, float size) {
        float r = size / 2f;
        glow(c, cx, cy, r * 1.35f, withAlpha(0xFFFFC23A, 0.42f));
        Paint sepal = fill(0xFF4E9B3A);
        Path sp = petal(cx, cy, r * 0.3f, r * 1.0f, r * 0.2f);
        for (int i = 0; i < 8; i++) {
            c.save();
            c.rotate(i * 45f + 22.5f, cx, cy);
            c.drawPath(sp, sepal);
            c.restore();
        }
        Paint backPetal = fill(0xFFF0A21A);
        Path bp = petal(cx, cy, r * 0.32f, r * 0.98f, r * 0.2f);
        Paint frontPetal = new Paint(Paint.ANTI_ALIAS_FLAG);
        frontPetal.setShader(new RadialGradient(cx, cy, r, new int[]{0xFFFFB81C, 0xFFFFD43F, 0xFFFFE27A},
                new float[]{0.35f, 0.7f, 1f}, Shader.TileMode.CLAMP));
        Path fp = petal(cx, cy, r * 0.3f, r * 0.9f, r * 0.19f);
        Paint edge = stroke(0xFFC77C0A, Math.max(0.35f, size * 0.012f));
        for (int i = 0; i < 12; i++) {
            c.save();
            c.rotate(i * 30f + 15f, cx, cy);
            c.drawPath(bp, backPetal);
            c.restore();
        }
        for (int i = 0; i < 12; i++) {
            c.save();
            c.rotate(i * 30f, cx, cy);
            c.drawPath(fp, frontPetal);
            c.drawPath(fp, edge);
            c.restore();
        }
        float cr = r * 0.42f;
        Paint disc = new Paint(Paint.ANTI_ALIAS_FLAG);
        disc.setShader(new RadialGradient(cx - cr * 0.25f, cy - cr * 0.3f, cr * 1.3f, 0xFF8A5626, 0xFF3E220D, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, cr, disc);
        Paint seed = fill(withAlpha(0xFFC08A45, 0.7f));
        double golden = Math.PI * (3 - Math.sqrt(5));
        int seeds = 40;
        for (int i = 3; i <= seeds; i++) {
            float rad = cr * 0.88f * (float) Math.sqrt(i / (double) seeds);
            double a = i * golden;
            c.drawCircle(cx + (float) Math.cos(a) * rad, cy + (float) Math.sin(a) * rad, Math.max(0.25f, cr * 0.05f), seed);
        }
        c.drawCircle(cx, cy, cr, stroke(0xFF2A1407, Math.max(0.5f, size * 0.025f)));
    }

    static Path starPath(float cx, float cy, float outer, float inner, int points, float rotateDeg, long jitterSeed) {
        Random rnd = new Random(jitterSeed);
        Path p = new Path();
        for (int i = 0; i < points * 2; i++) {
            double a = Math.toRadians(rotateDeg - 90 + i * 180.0 / points);
            float rad = (i % 2 == 0) ? outer : inner;
            if (jitterSeed != 0L && i % 2 == 0) rad *= 0.82f + rnd.nextFloat() * 0.28f;
            float x = cx + (float) Math.cos(a) * rad, y = cy + (float) Math.sin(a) * rad;
            if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
        }
        p.close();
        return p;
    }

    /** Comic impact burst: orange outer, yellow inner, white-hot core. */
    static void drawKiBurst(Canvas c, float cx, float cy, float size, Style s) {
        float r = size / 2f;
        glow(c, cx, cy, r * 1.4f, withAlpha(s.accent, 0.5f));
        c.drawPath(starPath(cx, cy, r, r * 0.6f, 12, 0f, 21L), fill(s.accent));
        c.drawPath(starPath(cx, cy, r * 0.74f, r * 0.46f, 12, 15f, 22L), fill(YELLOW));
        Paint core = new Paint(Paint.ANTI_ALIAS_FLAG);
        core.setShader(new RadialGradient(cx, cy, r * 0.42f, WHITE, 0xFFFFF0A0, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r * 0.36f, core);
    }

    /**
     * Spirit orb colours, each {halo, inner glow, body, body edge, rim, label}:
     * 0 ice (the original), 1 jade, 2 sapphire, 3 amethyst, 4 gold, 5 sakura, 6 crimson.
     */
    static final int[][] ORBS = {
            {0xFF6FD6F0, 0xFFB8F0FF, 0xFFE4FAFF, 0xFFA6E8FA, 0xFF8FE3FF, 0xFF6FF5DF},
            {0xFF2FCF8E, 0xFFAEF3D2, 0xFFC8F5DF, 0xFF5ED7A0, 0xFF5FDBA4, 0xFF6FF0B4},
            {0xFF4A78FF, 0xFFB0C6FF, 0xFFCAD7FF, 0xFF7C98FF, 0xFF7D9BFF, 0xFF9DB8FF},
            {0xFFA673FF, 0xFFDAC6FF, 0xFFE4D3FF, 0xFFAE86FF, 0xFFB48FFF, 0xFFC9A8FF},
            {0xFFFFBE3A, 0xFFFFE6A3, 0xFFFFEDB8, 0xFFFFC94A, 0xFFFFCB55, 0xFFFFD36B},
            {0xFFFF79B0, 0xFFFFCDE2, 0xFFFFDCEB, 0xFFFF92BF, 0xFFFF98C2, 0xFFFFA8CB},
            {0xFFFF3348, 0xFFFFB0B8, 0xFFFFC4CA, 0xFFF0434F, 0xFFFF4D5C, 0xFFFF6B76},
    };

    static int[] orb(int i) {
        return ORBS[i >= 0 && i < ORBS.length ? i : 0];
    }

    /** Dot colour for today when the Spirit icon is off, matching the orb. */
    public static int orbToday(int i) {
        return orb(i)[4];
    }

    /** Weekday label colour for today in the Spirit theme, matching the orb. */
    public static int orbLabel(int i) {
        return orb(i)[5];
    }

    /**
     * Glowing ball of light: wide soft halo, coloured rim, white-hot centre. The subtle option keeps
     * the glow close and soft; on a light wallpaper the halo and rim are deepened so the orb shows.
     */
    static void drawSpiritOrb(Canvas c, float cx, float cy, float size, Style s) {
        int[] o = orb(s.orb);
        float r = size / 2f;
        int halo = s.lightWall ? ThemeSpecs.deepen(o[0], 0.5f) : o[0];
        int inner = s.lightWall ? ThemeSpecs.deepen(o[1], 0.6f) : o[1];
        if (s.orbSubtle) {
            glow(c, cx, cy, r * 1.25f, withAlpha(halo, s.lightWall ? 0.22f : 0.16f));
            glow(c, cx, cy, r * 0.85f, withAlpha(inner, s.lightWall ? 0.45f : 0.38f));
        } else {
            glow(c, cx, cy, r * 1.75f, withAlpha(halo, s.lightWall ? 0.45f : 0.38f));
            glow(c, cx, cy, r * 1.05f, withAlpha(inner, 0.75f));
        }
        Paint ball = new Paint(Paint.ANTI_ALIAS_FLAG);
        ball.setShader(new RadialGradient(cx, cy, r * 0.62f,
                new int[]{WHITE, WHITE, o[2], o[3]}, new float[]{0f, 0.45f, 0.75f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r * 0.6f, ball);
        int rimColor = s.lightWall ? ThemeSpecs.deepen(o[4], 0.55f) : o[4];
        Paint rim = stroke(withAlpha(rimColor, s.lightWall ? 0.95f : 0.8f), Math.max(s.lightWall ? 1f : 0.6f, r * (s.lightWall ? 0.08f : 0.05f)));
        c.drawCircle(cx, cy, r * 0.6f, rim);
    }

    /**
     * Energy wave: a charging ball of light firing a beam up to the right. Light blue outside,
     * white-hot core, with a crackling aura round the ball.
     */
    static void drawKiWave(Canvas c, float cx, float cy, float size, boolean light) {
        float r = size / 2f;
        float ox = cx - r * 0.42f, oy = cy + r * 0.26f;
        float ex = cx + r * 1.0f, ey = cy - r * 0.52f;
        float len = (float) Math.hypot(ex - ox, ey - oy);
        float ang = (float) Math.toDegrees(Math.atan2(ey - oy, ex - ox));
        glow(c, (ox + ex) / 2f, (oy + ey) / 2f, r * 1.45f, withAlpha(0xFF3FA9FF, 0.5f));
        c.save();
        c.rotate(ang, ox, oy);
        int n = 10;
        float w0 = r * 0.24f, w1 = r * 0.36f;
        Path beam = new Path();
        beam.moveTo(ox, oy - w0);
        for (int i = 1; i <= n; i++) {
            float k = i / (float) n;
            float w = w0 + (w1 - w0) * k + (i % 2 == 0 ? r * 0.05f : -r * 0.02f);
            beam.lineTo(ox + len * k, oy - w);
        }
        beam.quadTo(ox + len + w1 * 1.2f, oy, ox + len, oy + w1);
        for (int i = n; i >= 1; i--) {
            float k = i / (float) n;
            float w = w0 + (w1 - w0) * k + (i % 2 == 1 ? r * 0.05f : -r * 0.02f);
            beam.lineTo(ox + len * k, oy + w);
        }
        beam.lineTo(ox, oy + w0);
        beam.close();
        c.drawPath(beam, fill(withAlpha(0xFF6CCBFF, 0.95f)));
        if (light) c.drawPath(beam, stroke(0xFF2A86C8, Math.max(0.8f, r * 0.05f)));
        Paint core = new Paint(Paint.ANTI_ALIAS_FLAG);
        core.setShader(new LinearGradient(ox, oy, ox + len, oy, WHITE, 0xFFD8F4FF, Shader.TileMode.CLAMP));
        float cw = w0 * 0.5f;
        c.drawRoundRect(new RectF(ox, oy - cw, ox + len + w1 * 0.3f, oy + cw), cw, cw, core);
        c.restore();
        glow(c, ox, oy, r * 0.8f, withAlpha(0xFFBFEFFF, 0.9f));
        c.drawPath(starPath(ox, oy, r * 0.56f, r * 0.34f, 9, 10f, 51L), fill(withAlpha(0xFF6CCBFF, 0.95f)));
        Paint ball = new Paint(Paint.ANTI_ALIAS_FLAG);
        ball.setShader(new RadialGradient(ox, oy, r * 0.36f, new int[]{WHITE, WHITE, 0xFFC6EEFF},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(ox, oy, r * 0.33f, ball);
    }

    /** A single curved sword slash with a few drops falling from it. */
    static void drawSwordSlash(Canvas c, float cx, float cy, float size, int color) {
        float r = size / 2f;
        glow(c, cx, cy, r * 1.3f, withAlpha(color, 0.35f));
        float x0 = cx - r * 0.78f, y0 = cy + r * 0.62f, x1 = cx + r * 0.82f, y1 = cy - r * 0.72f;
        float w = r * 0.34f;
        Path blade = new Path();
        blade.moveTo(x0, y0);
        blade.quadTo(cx - r * 0.05f - w, cy - r * 0.12f - w, x1, y1);
        blade.quadTo(cx + r * 0.12f + w * 0.4f, cy + r * 0.08f + w * 0.4f, x0, y0);
        blade.close();
        Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        body.setShader(new LinearGradient(x0, y0, x1, y1, mix(color, BLACK, 0.2f), mix(color, WHITE, 0.15f), Shader.TileMode.CLAMP));
        c.drawPath(blade, body);
        Paint drop = fill(mix(color, BLACK, 0.1f));
        c.drawCircle(cx - r * 0.05f, cy + r * 0.38f, r * 0.08f, drop);
        c.drawCircle(cx + r * 0.02f, cy + r * 0.62f, r * 0.06f, drop);
        c.drawCircle(cx - r * 0.3f, cy + r * 0.82f, r * 0.05f, drop);
    }

    /**
     * A katana lying from x0 (pommel) to x1 (tip) along y: gold pommel cap, wrapped handle,
     * gold guard, and a steel blade curving up a little towards the point.
     */
    static void drawKatana(Canvas c, float x0, float y, float x1, float t, int wrapColor) {
        float len = x1 - x0;
        if (len < 10f) return;
        float hl = Math.min(len * 0.26f, Math.max(t * 7f, 14f));
        float gx = x0 + hl;
        RectF handle = new RectF(x0 + t * 0.4f, y - t * 0.55f, gx - t * 0.35f, y + t * 0.55f);
        c.drawRoundRect(handle, t * 0.3f, t * 0.3f, fill(0xFF1A1210));
        Paint wrap = stroke(wrapColor, Math.max(0.5f, t * 0.26f));
        float step = Math.max(t * 1.05f, 1.6f);
        for (float hx = handle.left + step * 0.6f; hx < handle.right - step * 0.2f; hx += step) {
            c.drawLine(hx - step * 0.42f, handle.top, hx + step * 0.42f, handle.bottom, wrap);
            c.drawLine(hx + step * 0.42f, handle.top, hx - step * 0.42f, handle.bottom, wrap);
        }
        c.drawRoundRect(new RectF(x0, y - t * 0.62f, x0 + t * 0.7f, y + t * 0.62f), t * 0.25f, t * 0.25f, fill(GOLD));
        RectF guard = new RectF(gx - t * 0.42f, y - t * 1.15f, gx + t * 0.42f, y + t * 1.15f);
        c.drawOval(guard, fill(GOLD));
        c.drawOval(guard, stroke(GOLD_DARK, Math.max(0.4f, t * 0.12f)));
        float bx = gx + t * 0.45f;
        float bl = x1 - bx;
        if (bl < t * 3f) return;
        float sori = Math.min(t * 1.5f, bl * 0.06f);
        float half = t * 0.4f;
        Path blade = new Path();
        blade.moveTo(bx, y - half);
        blade.quadTo(bx + bl * 0.65f, y - half - sori * 0.45f, x1 - t * 1.5f, y - half - sori);
        blade.lineTo(x1, y - sori - half * 0.6f);
        blade.quadTo(x1 - t * 0.7f, y + half - sori * 0.8f, x1 - t * 2.2f, y + half - sori * 0.88f);
        blade.quadTo(bx + bl * 0.65f, y + half - sori * 0.42f, bx, y + half);
        blade.close();
        Paint steel = new Paint(Paint.ANTI_ALIAS_FLAG);
        steel.setShader(new LinearGradient(0f, y - half - sori, 0f, y + half, 0xFFF2F4F5, 0xFF8C959B, Shader.TileMode.CLAMP));
        c.drawPath(blade, steel);
        c.drawRect(bx - t * 0.05f, y - half * 1.1f, bx + t * 0.55f, y + half * 1.1f, fill(GOLD));
    }

    /** Two katanas crossed, handles down, with a crimson glow. */
    static void drawCrossedKatanas(Canvas c, float cx, float cy, float size, Style s) {
        float r = size / 2f;
        glow(c, cx, cy, r * 1.3f, withAlpha(s.accent, 0.4f));
        float t = Math.max(1.3f, r * 0.13f);
        for (int k = 0; k < 2; k++) {
            c.save();
            if (k == 1) c.scale(-1f, 1f, cx, cy);
            c.rotate(-48f, cx, cy);
            drawKatana(c, cx - r * 0.98f, cy, cx + r * 0.98f, t, s.accent);
            c.restore();
        }
    }

    /** Samurai helmet: black lacquer bowl, gold visor, laced neck guard and gold crescent horns. */
    static void drawKabuto(Canvas c, float cx, float cy, float size, Style s) {
        float r = size / 2f;
        glow(c, cx, cy, r * 1.35f, withAlpha(GOLD, 0.32f));
        float baseY = cy + r * 0.2f;
        float line = Math.max(0.5f, r * 0.04f);
        for (int i = 2; i >= 0; i--) {
            float top = baseY + i * r * 0.19f;
            float half = r * (0.66f + i * 0.13f);
            Path lame = new Path();
            lame.moveTo(cx - half * 0.9f, top);
            lame.quadTo(cx, top - r * 0.1f, cx + half * 0.9f, top);
            lame.lineTo(cx + half, top + r * 0.2f);
            lame.quadTo(cx, top + r * 0.1f, cx - half, top + r * 0.2f);
            lame.close();
            c.drawPath(lame, fill(i == 1 ? mix(s.accent, BLACK, 0.3f) : s.accent));
            c.drawPath(lame, stroke(withAlpha(BLACK, 0.65f), line));
        }
        RectF bowl = new RectF(cx - r * 0.62f, baseY - r * 0.82f, cx + r * 0.62f, baseY + r * 0.82f);
        Paint lac = new Paint(Paint.ANTI_ALIAS_FLAG);
        lac.setShader(new RadialGradient(cx - r * 0.2f, baseY - r * 0.6f, r * 0.9f, 0xFF5C4838, 0xFF1E1612, Shader.TileMode.CLAMP));
        c.drawArc(bowl, 180f, 180f, true, lac);
        c.drawArc(bowl, 180f, 180f, false, stroke(withAlpha(GOLD, 0.7f), Math.max(0.5f, r * 0.045f)));
        Paint rib = stroke(withAlpha(GOLD, 0.35f), Math.max(0.4f, r * 0.03f));
        for (int i = -1; i <= 1; i += 2) {
            RectF rr = new RectF(cx - r * 0.3f, baseY - r * 0.8f, cx + r * 0.3f, baseY + r * 0.8f);
            c.drawArc(rr, i < 0 ? 200f : 290f, 50f, false, rib);
        }
        c.drawRoundRect(new RectF(cx - r * 0.72f, baseY - r * 0.08f, cx + r * 0.72f, baseY + r * 0.07f), r * 0.05f, r * 0.05f, fill(GOLD));
        Paint gold = new Paint(Paint.ANTI_ALIAS_FLAG);
        gold.setShader(new LinearGradient(cx, cy - r, cx, baseY, 0xFFFFE08A, 0xFFC08A2A, Shader.TileMode.CLAMP));
        for (int side = -1; side <= 1; side += 2) {
            float bx = cx + side * r * 0.06f, by = baseY - r * 0.16f;
            Path horn = new Path();
            horn.moveTo(bx, by + r * 0.04f);
            horn.quadTo(cx + side * r * 0.62f, by - r * 0.08f, cx + side * r * 0.86f, cy - r * 0.98f);
            horn.quadTo(cx + side * r * 0.42f, by - r * 0.38f, bx, by - r * 0.16f);
            horn.close();
            c.drawPath(horn, gold);
            c.drawPath(horn, stroke(withAlpha(GOLD_DARK, 0.8f), Math.max(0.35f, r * 0.025f)));
        }
        c.drawCircle(cx, baseY - r * 0.14f, r * 0.12f, fill(GOLD));
        c.drawCircle(cx, baseY - r * 0.14f, r * 0.12f, stroke(GOLD_DARK, Math.max(0.35f, r * 0.03f)));
    }

    /** Retro rocket climbing to the upper right on an orange flame, like 🚀. */
    static void drawRocket(Canvas c, float cx, float cy, float size, Style s) {
        float r = size / 2f;
        glow(c, cx, cy, r * 1.35f, withAlpha(0xFFFF8A3D, 0.42f));
        c.save();
        c.rotate(45f, cx, cy);
        float bw = r * 0.34f;
        float top = cy - r * 0.98f, bottom = cy + r * 0.46f;
        Path flame = new Path();
        flame.moveTo(cx - bw * 0.62f, bottom);
        flame.quadTo(cx - bw * 0.55f, bottom + r * 0.32f, cx, bottom + r * 0.62f);
        flame.quadTo(cx + bw * 0.55f, bottom + r * 0.32f, cx + bw * 0.62f, bottom);
        flame.close();
        c.drawPath(flame, fill(0xFFFF6A33));
        Path inner = new Path();
        inner.moveTo(cx - bw * 0.35f, bottom);
        inner.quadTo(cx - bw * 0.3f, bottom + r * 0.2f, cx, bottom + r * 0.38f);
        inner.quadTo(cx + bw * 0.3f, bottom + r * 0.2f, cx + bw * 0.35f, bottom);
        inner.close();
        c.drawPath(inner, fill(0xFFFFE08A));
        int finColor = 0xFFEC4B3C;
        for (int side = -1; side <= 1; side += 2) {
            Path fin = new Path();
            fin.moveTo(cx + side * bw * 0.85f, cy + r * 0.0f);
            fin.lineTo(cx + side * bw * 1.8f, bottom + r * 0.16f);
            fin.lineTo(cx + side * bw * 1.65f, bottom + r * 0.26f);
            fin.lineTo(cx + side * bw * 0.8f, bottom - r * 0.02f);
            fin.close();
            c.drawPath(fin, fill(finColor));
        }
        Path body = new Path();
        body.moveTo(cx, top);
        body.cubicTo(cx + bw * 1.1f, top + r * 0.38f, cx + bw, cy, cx + bw * 0.86f, bottom);
        body.lineTo(cx - bw * 0.86f, bottom);
        body.cubicTo(cx - bw, cy, cx - bw * 1.1f, top + r * 0.38f, cx, top);
        body.close();
        Paint hull = new Paint(Paint.ANTI_ALIAS_FLAG);
        hull.setShader(new LinearGradient(cx - bw, 0f, cx + bw, 0f, 0xFFFFFAEE, 0xFFBDB6A8, Shader.TileMode.CLAMP));
        c.drawPath(body, hull);
        c.save();
        c.clipPath(body);
        c.drawRect(cx - bw * 1.3f, top, cx + bw * 1.3f, top + r * 0.4f, fill(finColor));
        c.drawRect(cx - bw * 1.3f, bottom - r * 0.12f, cx + bw * 1.3f, bottom, fill(withAlpha(finColor, 0.9f)));
        c.restore();
        float pw = bw * 0.46f, py = cy - r * 0.16f;
        c.drawCircle(cx, py, pw, fill(0xFF2FB0C2));
        c.drawCircle(cx, py, pw, stroke(0xFF3A3F50, Math.max(0.5f, r * 0.05f)));
        c.drawCircle(cx - pw * 0.35f, py - pw * 0.35f, pw * 0.28f, fill(withAlpha(WHITE, 0.85f)));
        c.drawRect(cx - bw * 0.5f, bottom, cx + bw * 0.5f, bottom + r * 0.07f, fill(0xFF545A6C));
        c.restore();
    }

    /** The year as an orbit: a ringed planet, a dotted track, and a rocket at today's point. */
    static void orbitYear(Canvas c, float cx, float cy, float r, float progress, Style s) {
        float or = r * 0.9f;
        Paint dot = fill(withAlpha(s.sub, 0.35f));
        for (int i = 0; i < 60; i++) {
            double a = Math.toRadians(-90 + i * 6);
            c.drawCircle(cx + (float) Math.cos(a) * or, cy + (float) Math.sin(a) * or, Math.max(0.6f, r * 0.018f), dot);
        }
        RectF oval = new RectF(cx - or, cy - or, cx + or, cy + or);
        if (progress > 0f) {
            Paint arc = stroke(s.todayLabel, Math.max(1.5f, r * 0.055f));
            arc.setStrokeCap(Paint.Cap.ROUND);
            c.drawArc(oval, -90f, 360f * progress, false, arc);
        }
        float pr = r * 0.4f;
        Paint pl = new Paint(Paint.ANTI_ALIAS_FLAG);
        pl.setShader(new RadialGradient(cx - pr * 0.3f, cy - pr * 0.35f, pr * 1.4f, 0xFFF8CF6A, 0xFFD45E2A, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, pr, pl);
        Paint band = stroke(withAlpha(0xFF8A3A1C, 0.35f), pr * 0.12f);
        c.save();
        c.clipPath(circlePath(cx, cy, pr));
        c.drawLine(cx - pr, cy - pr * 0.25f, cx + pr, cy - pr * 0.45f, band);
        c.drawLine(cx - pr, cy + pr * 0.25f, cx + pr, cy + pr * 0.05f, band);
        c.restore();
        c.save();
        c.rotate(-18f, cx, cy);
        c.drawOval(new RectF(cx - pr * 1.65f, cy - pr * 0.36f, cx + pr * 1.65f, cy + pr * 0.36f), stroke(withAlpha(0xFFF5ECDA, 0.9f), Math.max(1f, r * 0.03f)));
        c.restore();
        double a = Math.toRadians(-90 + 360 * progress);
        float rx = cx + (float) Math.cos(a) * or, ry = cy + (float) Math.sin(a) * or;
        c.save();
        c.rotate((float) Math.toDegrees(a) + 135f, rx, ry);
        drawRocket(c, rx, ry, r * 0.46f, s);
        c.restore();
    }

    static Path circlePath(float cx, float cy, float r) {
        Path p = new Path();
        p.addCircle(cx, cy, r, Path.Direction.CW);
        return p;
    }

    /** Sword guard (tsuba): gold disc with the blade slot and two side openings. */
    public static void drawTsuba(Canvas c, float cx, float cy, float size) {
        float r = size / 2f;
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new RadialGradient(cx - r * 0.3f, cy - r * 0.35f, r * 1.4f, 0xFFF6D886, 0xFF9A6A1C, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, g);
        c.drawCircle(cx, cy, r, stroke(GOLD_DARK, Math.max(0.6f, r * 0.05f)));
        c.drawCircle(cx, cy, r * 0.84f, stroke(withAlpha(GOLD_DARK, 0.45f), Math.max(0.5f, r * 0.025f)));
        Paint hole = fill(LACQUER);
        Path slot = new Path();
        slot.moveTo(cx, cy - r * 0.44f);
        slot.lineTo(cx + r * 0.13f, cy - r * 0.3f);
        slot.lineTo(cx + r * 0.1f, cy + r * 0.44f);
        slot.lineTo(cx - r * 0.1f, cy + r * 0.44f);
        slot.lineTo(cx - r * 0.13f, cy - r * 0.3f);
        slot.close();
        c.drawPath(slot, hole);
        for (int side = -1; side <= 1; side += 2) {
            float hx = cx + side * r * 0.42f;
            c.drawOval(new RectF(hx - r * 0.11f, cy - r * 0.26f, hx + r * 0.11f, cy + r * 0.26f), hole);
        }
    }

    /** Ink splash with a few flung drops. */
    static void drawInkSplash(Canvas c, float cx, float cy, float size, int color) {
        float r = size / 2f;
        glow(c, cx, cy, r * 1.3f, withAlpha(color, 0.35f));
        Random rnd = new Random(41);
        int n = 14;
        float[] xs = new float[n], ys = new float[n];
        for (int i = 0; i < n; i++) {
            double a = Math.toRadians(i * 360.0 / n);
            float rad = r * 0.68f * (0.84f + rnd.nextFloat() * 0.3f);
            xs[i] = cx + (float) Math.cos(a) * rad;
            ys[i] = cy + (float) Math.sin(a) * rad;
        }
        Path blob = new Path();
        blob.moveTo((xs[n - 1] + xs[0]) / 2f, (ys[n - 1] + ys[0]) / 2f);
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            blob.quadTo(xs[i], ys[i], (xs[i] + xs[j]) / 2f, (ys[i] + ys[j]) / 2f);
        }
        blob.close();
        Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        body.setShader(new RadialGradient(cx - r * 0.15f, cy - r * 0.2f, r * 0.75f, mix(color, WHITE, 0.18f), mix(color, BLACK, 0.25f), Shader.TileMode.CLAMP));
        c.drawPath(blob, body);
        Paint drop = fill(mix(color, BLACK, 0.1f));
        for (int i = 0; i < 4; i++) {
            double a = Math.toRadians(20 + i * 85 + rnd.nextFloat() * 30);
            float rad = r * (0.86f + rnd.nextFloat() * 0.16f);
            c.drawCircle(cx + (float) Math.cos(a) * rad, cy + (float) Math.sin(a) * rad, r * (0.05f + rnd.nextFloat() * 0.07f), drop);
        }
    }

    /** A slightly irregular ink blot, the same shape each time for a given seed. */
    static Path inkBlot(float cx, float cy, float r, long seed) {
        Random rnd = new Random(seed);
        int n = 12;
        float[] xs = new float[n], ys = new float[n];
        for (int i = 0; i < n; i++) {
            double a = Math.toRadians(i * 360.0 / n + rnd.nextFloat() * 10);
            float rad = r * (0.92f + rnd.nextFloat() * 0.13f);
            xs[i] = cx + (float) Math.cos(a) * rad;
            ys[i] = cy + (float) Math.sin(a) * rad;
        }
        Path p = new Path();
        p.moveTo((xs[n - 1] + xs[0]) / 2f, (ys[n - 1] + ys[0]) / 2f);
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            p.quadTo(xs[i], ys[i], (xs[i] + xs[j]) / 2f, (ys[i] + ys[j]) / 2f);
        }
        p.close();
        return p;
    }

    /**
     * Ensō: one brush stroke around a circle, landing heavy and lifting off thin.
     * {@code amount} 0..1 is how much of the circle is painted.
     */
    public static void drawEnso(Canvas c, float cx, float cy, float size, int color, float amount, long seed) {
        float r = size * 0.36f;
        float maxW = Math.max(2f, size * 0.17f);
        c.drawCircle(cx, cy, r, fill(withAlpha(color, 0.10f)));
        RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);
        float sweep = 325f * clamp(amount, 0f, 1f);
        if (sweep <= 0f) return;
        int n = Math.max(8, (int) (sweep / 6f));
        float start = -60f;
        Paint p = stroke(color, maxW);
        p.setStrokeCap(Paint.Cap.ROUND);
        Random rnd = new Random(seed);
        for (int i = 0; i < n; i++) {
            float t = (i + 0.5f) / n * (amount >= 1f ? 1f : 0.5f + 0.5f * amount);
            float w = t < 0.1f ? 0.65f + t / 0.1f * 0.35f : 1f - (t - 0.1f) / 0.9f * 0.78f;
            p.setStrokeWidth(Math.max(0.6f, maxW * w * (0.94f + rnd.nextFloat() * 0.1f)));
            p.setColor(withAlpha(color, 0.92f - t * 0.25f));
            c.drawArc(oval, start + i * sweep / n, sweep / n + 1.2f, false, p);
        }
    }

    /** HUD lock-on reticle: broken ring, inward ticks, glowing centre. */
    static void drawReticle(Canvas c, float cx, float cy, float size, int color) {
        float r = size * 0.4f;
        glow(c, cx, cy, r * 1.6f, withAlpha(color, 0.45f));
        Paint ring = stroke(color, Math.max(1.3f, size * 0.07f));
        RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);
        for (int k = 0; k < 4; k++) c.drawArc(oval, k * 90f + 18f, 54f, false, ring);
        Paint tick = stroke(color, Math.max(1.1f, size * 0.055f));
        tick.setStrokeCap(Paint.Cap.ROUND);
        for (int k = 0; k < 4; k++) {
            double a = Math.toRadians(k * 90);
            float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
            c.drawLine(cx + ca * r * 1.22f, cy + sa * r * 1.22f, cx + ca * r * 0.62f, cy + sa * r * 0.62f, tick);
        }
        c.drawCircle(cx, cy, r * 0.3f, fill(color));
        c.drawCircle(cx, cy, r * 0.12f, fill(WHITE));
    }

    // ------------------------------------------------------------------ month widget

    static float edge(float w, float h) {
        return clamp(Math.min(w, h) * 0.05f, 10f, 16f);
    }

    /** Where the 日/EN switch sits in the month widget: {left, top, width, height} in dp. */
    public static float[] monthLcdRect(float w, float h) {
        float p = edge(w, h);
        float cw = 64f, ch = 28f;
        return new float[]{w - p - cw, p + 2f, cw, ch};
    }

    public static void drawMonthWidget(Canvas c, float w, float h, Style s, MonthData m) {
        RectF all = new RectF(0f, 0f, w, h);
        drawSurface(c, all, 24f, s, true);
        boolean solid = s.background == BG_SOLID;
        float p = edge(w, h);
        float ts = labelK(s, true);
        float headerH = 34f * titleK(s, true);

        float[] l = monthLcdRect(w, h);
        RectF chip = new RectF(l[0], l[1], l[0] + l[2], l[1] + l[3]);
        float sealSize = 24f * titleK(s, true);
        RectF seal = new RectF(p, p + 4f, p + sealSize, p + 4f + sealSize);
        drawSeal(c, seal, ThemeSpecs.seal(s.theme), s);

        Paint tp = title(s, m.japanese, s.text, m.japanese ? 25f : 22f, Paint.Align.LEFT, true);
        float tx = seal.right + 9f;
        float headerRight = s.langChip ? chip.left : w - p;
        fit(tp, m.title, headerRight - 10f - tx, 12f);
        float base = seal.centerY() - (tp.ascent() + tp.descent()) / 2f;
        float titleW = tp.measureText(m.title);
        drawTitleMark(c, tx, base, titleW, tp.getTextSize(), s);
        c.drawText(m.title, tx, base, tp);
        Paint sub = label(s, s.sub, 13.5f, Paint.Align.LEFT, true);
        float sx = tx + titleW + (s.theme == ThemeSpecs.DENNOU ? 20f : 14f);
        if (sx + sub.measureText(m.subtitle) <= headerRight - 6f) c.drawText(m.subtitle, sx, base, sub);
        if (s.langChip) drawLangChip(c, chip, m.japanese, s, true);

        boolean footer = h >= 190f;
        boolean hasInfo = m.info != null && !m.info.isEmpty();
        boolean hasCountdown = m.countdown != null && !m.countdown.isEmpty();
        boolean footer2 = footer && h >= 250f && (hasInfo || hasCountdown);
        float top = p + headerH + 6f;
        float wh = weekdayRowH(s, 18f);
        float gw = w - 2f * p, cw = gw / 7f;
        weekdayRow(c, s, m.weekdays, m.japanese, m.todayColumn, null, p, cw, top + wh / 2f, m.japanese ? 14.5f : 12f, true);

        float gy = top + wh + 2f;
        float gh = h - p - gy - (footer ? (footer2 ? 42f : 22f) * ts : 0f);
        int rows = Math.max(1, m.weeks.length);
        float ch = gh / rows;
        float cell = Math.min(cw, ch);
        for (int r = 0; r < m.weeks.length; r++) {
            for (int col = 0; col < 7; col++) {
                float cx = p + cw * (col + 0.5f), cy = gy + ch * (r + 0.5f);
                Day d = m.weeks[r][col];
                if (d != null) drawDay(c, cx, cy, cell, d, s, true);
                else drawBlank(c, cx, cy, cell, s);
            }
        }

        if (footer) {
            float fy = h - p - 3f - (footer2 ? 20f * ts : 0f);
            float inset = cw * 0.5f - dotSize(cell, s) / 2f;
            float left = p + inset, right = w - p - inset;
            Paint fl = label(s, s.sub, 13.5f, Paint.Align.LEFT, true);
            Paint fr = label(s, s.sub, 13.5f, Paint.Align.RIGHT, true);
            String leftText = m.era;
            String rightText = m.count;
            if (!footer2) {
                // one line only: the countdown takes the right side, the info joins the era if it fits
                if (hasCountdown) {
                    rightText = m.countdown;
                    fr.setColor(s.todayLabel);
                    fr.setTypeface(s.labelBold);
                }
                if (hasInfo && fl.measureText(leftText + " · " + m.info) < (right - left) * 0.55f) leftText = leftText + " · " + m.info;
            }
            fit(fr, rightText, (right - left) * 0.6f, 9f);
            fit(fl, leftText, right - left - fr.measureText(rightText) - 12f, 9f);
            c.drawText(leftText, left, fy, fl);
            c.drawText(rightText, right, fy, fr);
            if (footer2) {
                float fy2 = h - p - 3f;
                Paint il = label(s, s.sub, 12.5f, Paint.Align.LEFT, true);
                Paint cr = label(s, s.todayLabel, 12.5f, Paint.Align.RIGHT, true);
                cr.setTypeface(s.labelBold);
                String cd = hasCountdown ? m.countdown : "";
                String info = hasInfo ? m.info : "";
                fit(cr, cd, (right - left) * 0.62f, 9f);
                fit(il, info, right - left - cr.measureText(cd) - 12f, 9f);
                if (hasInfo) c.drawText(info, left, fy2, il);
                if (hasCountdown) c.drawText(cd, right, fy2, cr);
            }
            if (solid && s.theme == ThemeSpecs.RONIN && !footer2 && !hasCountdown) {
                float eraEnd = p + inset + fl.measureText(m.era);
                float countStart = w - p - inset - fr.measureText(m.count);
                float cloudW = Math.min(52f, w * 0.17f);
                if (countStart - eraEnd > cloudW + 20f) {
                    drawCloud(c, (eraEnd + countStart) / 2f, fy - 5f, cloudW, withAlpha(BONE, 0.95f));
                }
            }
        }
    }

    // ------------------------------------------------------------------ week widget

    /** The date block on the left of the week widget (tap it to switch language): {left, top, width, height}. */
    public static float[] weekLcdRect(float w, float h) {
        return weekLcdRect(w, h, false);
    }

    /** The date block on the left of the week widget: {left, top, width, height} in dp. */
    public static float[] weekLcdRect(float w, float h, boolean longDate) {
        return weekLcdRect(w, h, longDate, 1f);
    }

    /** Same, for a widget text size; larger text gets a slightly wider date block. */
    public static float[] weekLcdRect(float w, float h, boolean longDate, float textScale) {
        float p = 12f;
        float k = 1f + (textScale - 1f) * 0.5f;
        float bw = longDate ? clamp(w * 0.40f * k, 118f, 184f) : clamp(w * 0.31f * k, 92f, 148f);
        return new float[]{p, p, bw, h - 2f * p};
    }

    public static void drawWeekWidget(Canvas c, float w, float h, Style s, WeekData d) {
        RectF all = new RectF(0f, 0f, w, h);
        drawSurface(c, all, Math.min(24f, h * 0.32f), s, true);
        if (s.weekOnly) {
            // minimal: just the weekday row and the dots, across the full width
            float side = clamp(w * 0.04f, 10f, 16f);
            weekDots(c, side, w - side, h, s, d, false, d.japanese ? 15f : 12.5f);
            return;
        }
        float[] l = weekLcdRect(w, h, d.longDate, s.textScale);
        RectF block = new RectF(l[0], l[1], l[0] + l[2], l[1] + l[3]);
        float ts = labelK(s, true);

        Typeface bigFace = s.theme == ThemeSpecs.DENNOU && !d.longDate ? s.titleEn : s.labelBold;
        float bigSize = (d.longDate ? clamp(block.height() * 0.32f, 15f, 24f) : clamp(block.height() * 0.46f, 20f, 40f)) * titleK(s, true);
        Paint big = text(s.text, bigFace, bigSize, Paint.Align.LEFT);
        big.setFakeBoldText(s.bold);
        readable(big, s, true);
        fit(big, d.bigDate, block.width() - 4f, d.longDate ? 10f : 14f);
        Paint day = label(s, s.sub, 14.5f, Paint.Align.LEFT, true);
        float chipH = 22f, chipW = 50f, gap = d.longDate ? 7f : 5f;
        float rowH = s.langChip ? Math.max(chipH, 18f * ts) : 18f * ts;
        float bigH = -big.ascent() + big.descent() * 0.35f;
        float textH = bigH + gap + rowH;
        if (textH > block.height()) {
            // very short widget with large text: shrink the big date to fit
            big.setTextSize(big.getTextSize() * Math.max(0.6f, (block.height() - gap - rowH) / bigH));
            bigH = -big.ascent() + big.descent() * 0.35f;
            textH = bigH + gap + rowH;
        }
        float y0 = block.centerY() - textH / 2f;
        float baseBig = y0 - big.ascent();
        drawTitleMark(c, block.left + 1f, baseBig, big.measureText(d.bigDate) * 0.92f, big.getTextSize() * (d.longDate ? 0.9f : 0.75f), s);
        c.drawText(d.bigDate, block.left, baseBig, big);
        float rowTop = baseBig + big.descent() * 0.35f + gap;
        RectF chip = new RectF(block.right - chipW, rowTop + (rowH - chipH) / 2f, block.right, rowTop + (rowH + chipH) / 2f);
        float room = (s.langChip ? chip.left : block.right) - block.left - 6f;
        String dayName = d.dayName;
        if (!d.japanese) {
            day.setTextSize(day.getTextSize() * 0.92f);
            if (day.measureText(dayName) > room && dayName.length() > 3) dayName = dayName.substring(0, 3);
        }
        float daySize = day.getTextSize();
        fit(day, dayName, room, 9f);
        // too long even at the smallest size: drop trailing " · " parts (節気, then 六曜)
        while (day.measureText(dayName) > room && dayName.contains(" · ")) {
            dayName = dayName.substring(0, dayName.lastIndexOf(" · "));
            day.setTextSize(daySize);
            fit(day, dayName, room, 9f);
        }
        float rowCy = rowTop + rowH / 2f;
        c.drawText(dayName, block.left, rowCy - (day.ascent() + day.descent()) / 2f, day);
        if (s.langChip) drawLangChip(c, chip, d.japanese, s, true);

        weekDots(c, block.right + 14f, w - 12f, h, s, d, true, d.japanese ? 14f : 11.5f);
    }

    /** Weekday labels over seven dots between x0 and x1, centred vertically, with the countdown under them. */
    static void weekDots(Canvas c, float x0, float x1, float h, Style s, WeekData d, boolean countdown, float labelSize) {
        float ts = labelK(s, true);
        float cw = (x1 - x0) / 7f;
        float labelH = weekdayRowH(s, 18f);
        boolean showCountdown = countdown && d.countdown != null && !d.countdown.isEmpty() && h >= 78f;
        float cdH = showCountdown ? 17f * ts : 0f;
        float avail = h - 24f - labelH - 2f - cdH;
        float cell = Math.max(8f, Math.min(cw, avail));
        float groupH = labelH + 2f + cell + cdH;
        float top = (h - groupH) / 2f;
        if (showCountdown) {
            Paint cp = label(s, s.todayLabel, 12.5f, Paint.Align.CENTER, true);
            cp.setTypeface(s.labelBold);
            fit(cp, d.countdown, x1 - x0, 8.5f);
            float cyText = top + labelH + 2f + cell + cdH * 0.55f;
            drawCentered(c, d.countdown, (x0 + x1) / 2f, cyText, cp);
        }
        weekdayRow(c, s, d.weekdays, d.japanese, d.todayIndex, d.redLabels, x0, cw, top + labelH / 2f, labelSize, true);
        for (int i = 0; i < 7; i++) {
            float cx = x0 + cw * (i + 0.5f);
            drawDay(c, cx, top + labelH + 2f + cell / 2f, cell, d.days[i], s, true);
        }
    }

    /**
     * Weekday labels, each sized to fit its column. Today's is in the today colour, Sundays and
     * holidays in the holiday colour; the user can override any of these, plus Saturdays and the
     * rest, and pick the size and font.
     */
    static void weekdayRow(Canvas c, Style s, String[] labels, boolean japanese, int todayIndex, boolean[] red,
                           float x0, float cw, float cy, float size, boolean widget) {
        Paint p = label(s, s.sub, size * s.weekdayScale, Paint.Align.CENTER, widget);
        Typeface face = japanese ? s.weekdayJa : s.weekdayEn;
        p.setTypeface(face != null ? face : s.labelBold);
        if (face != null && japanese) p.setTextSkewX(s.weekdaySkewJa);
        float base = p.getTextSize();
        // Use the short form for the whole row if any full label would have to shrink much.
        boolean shortForm = false;
        if (!japanese) {
            for (String l : labels) {
                if (l.length() > 2 && p.measureText(l) > cw * 0.92f / 0.86f) shortForm = true;
            }
        }
        for (int i = 0; i < 7; i++) {
            p.setColor(weekdayColor(s, i, i == todayIndex, red != null ? red[i] : i == 0));
            readable(p, s, widget, true);
            String lab = shortForm && labels[i].length() > 2 ? labels[i].substring(0, 2) : labels[i];
            p.setTextSize(base);
            fit(p, lab, cw * 0.92f, 6f);
            drawCentered(c, lab, x0 + cw * (i + 0.5f), cy, p);
        }
    }

    /** Colour for weekday column {@code i} (0 = Sunday … 6 = Saturday). */
    static int weekdayColor(Style s, int i, boolean today, boolean red) {
        int c;
        if (today) c = s.wdToday != 0 ? s.wdToday : s.todayLabel;
        else if (red) c = s.wdSunday != 0 ? s.wdSunday : s.holiday;
        else if (i == 6 && s.wdSaturday != 0) c = s.wdSaturday;
        else c = s.wdOther != 0 ? s.wdOther : s.sub;
        // on a light wallpaper even a pale colour the user picked is deepened enough to read
        return s.lightWall ? ThemeSpecs.deepen(c, 0.5f) : c;
    }

    /** Height of the weekday label row: shrinks with smaller labels so the dots get the room. */
    static float weekdayRowH(Style s, float h) {
        return h * labelK(s, true) * (0.45f + 0.55f * s.weekdayScale);
    }

    /** Settings sample: the weekday row over a row of dots on the theme's surface. */
    public static void drawWeekdaySample(Canvas c, float w, float h, Style s, String[] labels, boolean japanese,
                                         int todayIndex, boolean[] red) {
        drawSurface(c, new RectF(0f, 0f, w, h), 16f, s, false);
        float side = 12f, cw = (w - 2f * side) / 7f;
        float labelY = h * 0.34f;
        weekdayRow(c, s, labels, japanese, todayIndex, red, side, cw, labelY, japanese ? 15f : 12.5f, false);
        float cell = Math.min(cw, h * 0.42f);
        for (int i = 0; i < 7; i++) {
            int state = i < todayIndex ? PASSED : i == todayIndex ? TODAY : (red != null && red[i] ? HOLIDAY : FUTURE);
            drawDay(c, side + cw * (i + 0.5f), h * 0.72f, cell, new Day(11 + i, state), s, false);
        }
    }

    // ------------------------------------------------------------------ year widget

    /** Every day of the year as a dot: twelve rows, one per month. */
    public static void drawYearWidget(Canvas c, float w, float h, Style s, YearData y) {
        RectF all = new RectF(0f, 0f, w, h);
        drawSurface(c, all, Math.min(24f, h * 0.2f), s, true);
        float p = clamp(Math.min(w, h) * 0.06f, 10f, 16f);
        float headerH = (h < 150f ? 24f : 30f) * titleK(s, true);

        float sealSize = headerH - 6f;
        RectF seal = new RectF(p, p + 2f, p + sealSize, p + 2f + sealSize);
        drawSeal(c, seal, ThemeSpecs.seal(s.theme), s);
        Paint tp = title(s, y.japanese, s.text, headerH * 0.72f, Paint.Align.LEFT, true);
        float tx = seal.right + 8f;
        float base = seal.centerY() - (tp.ascent() + tp.descent()) / 2f;
        Paint pr = label(s, s.sub, Math.min(13.5f, headerH * 0.5f), Paint.Align.RIGHT, true);
        pr.setTypeface(s.labelBold);
        fit(pr, y.progress, w * 0.4f, 8f);
        float progW = pr.measureText(y.progress);
        fit(tp, y.title, w - p - progW - 16f - tx, 10f);
        float titleW = tp.measureText(y.title);
        drawTitleMark(c, tx, base, titleW, tp.getTextSize(), s);
        c.drawText(y.title, tx, base, tp);
        Paint sub = label(s, s.sub, Math.min(13f, headerH * 0.48f), Paint.Align.LEFT, true);
        float sx = tx + titleW + (s.theme == ThemeSpecs.DENNOU ? 18f : 12f);
        if (sx + sub.measureText(y.subtitle) < w - p - progW - 12f) c.drawText(y.subtitle, sx, base, sub);
        c.drawText(y.progress, w - p, base, pr);

        float top = p + headerH + 4f, bottom = h - p;
        float labelW = (y.japanese ? 28f : 30f) * labelK(s, true);
        float cw = (w - 2f * p - labelW) / 31f;
        float ch = (bottom - top) / 12f;
        float cell = Math.min(cw, ch);
        float dot = cell * 0.66f;
        Paint lp = label(s, s.sub, 11.5f, Paint.Align.LEFT, true);
        lp.setTypeface(s.labelBold);
        // month labels can't be taller than their row, whatever the text size
        float labelSize = Math.min(lp.getTextSize(), ch * 0.84f);
        float todayX = -1f, todayY = -1f;
        for (int m = 0; m < 12; m++) {
            float cy = top + ch * (m + 0.5f);
            String lab = y.monthLabels[m];
            lp.setTextSize(labelSize);
            fit(lp, lab, labelW - 4f, 6f);
            c.drawText(lab, p, cy - (lp.ascent() + lp.descent()) / 2f, lp);
            Day[] days = y.months[m];
            if (days == null) continue;
            for (int i = 0; i < days.length; i++) {
                Day d = days[i];
                float cx = p + labelW + cw * (i + 0.5f);
                if (d.state == TODAY) {
                    todayX = cx;
                    todayY = cy;
                    continue;
                }
                tinyDay(c, cx, cy, dot, d, s);
            }
        }
        if (todayX >= 0f) {
            Day today = null;
            for (Day[] row : y.months) {
                if (row == null) continue;
                for (Day d : row) if (d.state == TODAY) today = d;
            }
            s.todayX = todayX;
            s.todayY = todayY;
            s.todayCell = Math.max(cell * 1.7f, 9f);
            if (s.todayIcon) {
                drawTodayIcon(c, todayX, todayY, Math.max(cell * 1.7f, 9f), s);
            } else {
                glow(c, todayX, todayY, dot * 1.6f, withAlpha(s.today, 0.5f));
                shape(c, todayX, todayY, dot * 0.62f, fill(s.today), s);
            }
            if (today != null && today.mark != 0) c.drawCircle(todayX, todayY, cell * 0.9f, stroke(today.mark, Math.max(1f, cell * 0.1f)));
        }
    }

    static void tinyDay(Canvas c, float cx, float cy, float dot, Day d, Style s) {
        float r = dot / 2f;
        if (d.state == PASSED) {
            shape(c, cx, cy, r, fill(s.passed), s);
        } else if (d.state == HOLIDAY) {
            float lw = Math.max(0.8f, dot * 0.2f);
            shape(c, cx, cy, r - lw / 2f, stroke(s.holiday, lw), s);
        } else {
            shape(c, cx, cy, r, fill(s.future), s);
        }
        if (d.mark != 0) c.drawCircle(cx, cy, r + Math.max(1.2f, dot * 0.3f), stroke(d.mark, Math.max(0.9f, dot * 0.16f)));
    }

    // ------------------------------------------------------------------ app pieces

    public static float monthGridHeight(float w, int rows) {
        return 26f + rows * (w / 7f) * 0.84f;
    }

    public static void drawMonthGrid(Canvas c, float w, Style s, MonthData m) {
        float cw = w / 7f, ch = cw * 0.84f;
        weekdayRow(c, s, m.weekdays, m.japanese, m.todayColumn, null, 0f, cw, 11f, m.japanese ? 15f : 12.5f, false);
        float cell = Math.min(cw, ch);
        for (int r = 0; r < m.weeks.length; r++) {
            for (int col = 0; col < 7; col++) {
                float cx = cw * (col + 0.5f), cy = 26f + ch * (r + 0.5f);
                Day d = m.weeks[r][col];
                if (d != null) drawDay(c, cx, cy, cell, d, s, false);
                else drawBlank(c, cx, cy, cell, s);
            }
        }
    }

    /** The year as the theme's object: a record, a power gauge, the moon, or an iron dial. */
    public static void drawYear(Canvas c, float cx, float cy, float r, float progress, Style s) {
        progress = clamp(progress, 0f, 1f);
        switch (s.theme) {
            case ThemeSpecs.KI:
                powerGauge(c, cx, cy, r, progress, s);
                break;
            case ThemeSpecs.REI:
                moon(c, cx, cy, r, progress, s);
                break;
            case ThemeSpecs.HAGANE:
                ironDial(c, cx, cy, r, progress, s);
                break;
            case ThemeSpecs.SUMI:
                ensoYear(c, cx, cy, r, progress, s);
                break;
            case ThemeSpecs.DENNOU:
                hudRing(c, cx, cy, r, progress, s);
                break;
            case ThemeSpecs.SAMURAI:
                tsubaYear(c, cx, cy, r, progress, s);
                break;
            case ThemeSpecs.COSMO:
                orbitYear(c, cx, cy, r, progress, s);
                break;
            default:
                vinyl(c, cx, cy, r, progress, s);
                break;
        }
    }

    /** The year as a crimson cord winding round a gold sword guard. */
    static void tsubaYear(Canvas c, float cx, float cy, float r, float progress, Style s) {
        glow(c, cx, cy, r * 1.2f, withAlpha(GOLD, 0.12f));
        float ar = r * 0.9f;
        RectF o = new RectF(cx - ar, cy - ar, cx + ar, cy + ar);
        c.drawArc(o, -90f, 360f, false, stroke(withAlpha(s.future, 0.9f), r * 0.12f));
        if (progress > 0f) {
            Paint arc = stroke(s.accent, r * 0.12f);
            c.drawArc(o, -90f, 360f * progress, false, arc);
            Paint cross = stroke(withAlpha(BLACK, 0.35f), Math.max(0.6f, r * 0.02f));
            int ticks = Math.round(progress * 48);
            for (int i = 0; i < ticks; i++) {
                double a = Math.toRadians(-90 + (i + 0.5) * 7.5);
                float r0 = ar - r * 0.06f, r1 = ar + r * 0.06f;
                c.drawLine(cx + (float) Math.cos(a - 0.05) * r0, cy + (float) Math.sin(a - 0.05) * r0,
                        cx + (float) Math.cos(a + 0.05) * r1, cy + (float) Math.sin(a + 0.05) * r1, cross);
            }
        }
        drawTsuba(c, cx, cy, r * 1.36f);
    }

    /** The year painted as an ensō, with a small red seal like a signed scroll. */
    static void ensoYear(Canvas c, float cx, float cy, float r, float progress, Style s) {
        float size = r * 2f / 0.72f;
        c.drawCircle(cx, cy, r, stroke(withAlpha(s.text, 0.10f), Math.max(1f, r * 0.02f)));
        drawEnso(c, cx, cy, size, s.text, progress, 9L);
        float ss = r * 0.32f;
        RectF seal = new RectF(cx + r * 0.72f, cy + r * 0.62f, cx + r * 0.72f + ss, cy + r * 0.62f + ss);
        drawSeal(c, seal, ThemeSpecs.seal(s.theme), s);
    }

    /** A HUD ring: minute-style ticks, a progress arc, a dashed inner ring and the percentage. */
    static void hudRing(Canvas c, float cx, float cy, float r, float progress, Style s) {
        glow(c, cx, cy, r * 1.25f, withAlpha(s.accent, 0.14f));
        c.drawCircle(cx, cy, r, stroke(withAlpha(s.accent, 0.4f), 1f));
        int lit = Math.round(progress * 60);
        for (int i = 0; i < 60; i++) {
            double a = Math.toRadians(-90 + i * 6);
            float len = i % 5 == 0 ? r * 0.12f : r * 0.06f;
            Paint t = stroke(i < lit ? s.accent : withAlpha(s.accent, 0.22f), i % 5 == 0 ? 1.4f : 0.9f);
            float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
            c.drawLine(cx + ca * r * 0.97f, cy + sa * r * 0.97f, cx + ca * (r * 0.97f - len), cy + sa * (r * 0.97f - len), t);
        }
        float ar = r * 0.74f;
        RectF oval = new RectF(cx - ar, cy - ar, cx + ar, cy + ar);
        c.drawArc(oval, -90f, 360f, false, stroke(withAlpha(s.accent, 0.12f), r * 0.09f));
        Paint arc = stroke(s.accent, r * 0.09f);
        if (progress > 0f) c.drawArc(oval, -90f, 360f * progress, false, arc);
        if (progress > 0f) {
            double a = Math.toRadians(-90 + 360 * progress);
            c.drawCircle(cx + (float) Math.cos(a) * ar, cy + (float) Math.sin(a) * ar, r * 0.08f, fill(s.todayLabel));
        }
        float dr = r * 0.56f;
        RectF dov = new RectF(cx - dr, cy - dr, cx + dr, cy + dr);
        Paint dash = stroke(withAlpha(s.accent, 0.45f), 1f);
        for (int i = 0; i < 24; i++) c.drawArc(dov, i * 15f, 8f, false, dash);
        Paint pct = text(s.text, s.titleEn, r * 0.34f, Paint.Align.CENTER);
        drawCentered(c, Math.round(progress * 100) + "%", cx, cy - r * 0.04f, pct);
        Paint lab = text(s.sub, s.labelBold, r * 0.12f, Paint.Align.CENTER);
        drawCentered(c, "YEAR", cx, cy + r * 0.26f, lab);
    }

    static void vinyl(Canvas c, float cx, float cy, float r, float progress, Style s) {
        c.drawCircle(cx, cy + r * 0.04f, r, fill(withAlpha(BLACK, 0.3f)));
        c.drawCircle(cx, cy, r, fill(0xFF141413));
        Paint groove = stroke(withAlpha(WHITE, 0.06f), 0.6f);
        for (float gr = r * 0.93f; gr > r * 0.42f; gr -= r * 0.08f) c.drawCircle(cx, cy, gr, groove);
        Paint arc = stroke(s.today, Math.max(1.5f, r * 0.05f));
        arc.setStrokeCap(Paint.Cap.ROUND);
        float ar = r * 0.88f;
        if (progress > 0f) c.drawArc(new RectF(cx - ar, cy - ar, cx + ar, cy + ar), -90f, 360f * progress, false, arc);
        float lr = r * 0.34f;
        c.drawCircle(cx, cy, lr, fill(s.accent));
        Paint lt = text(BONE, s.titleJa, lr * 0.85f, Paint.Align.CENTER);
        drawCentered(c, ThemeSpecs.seal(s.theme), cx, cy, lt);
        float px = cx + r * 1.0f, py = cy - r * 0.95f;
        float dx = cx - px, dy = cy - py;
        float dist = (float) Math.hypot(dx, dy);
        float armLen = r * 1.15f;
        float rs = r * 0.9f - progress * (r * 0.9f - r * 0.45f);
        float a = (armLen * armLen - rs * rs + dist * dist) / (2f * dist);
        float hgt = (float) Math.sqrt(Math.max(0f, armLen * armLen - a * a));
        float mx = px + a * dx / dist, my = py + a * dy / dist;
        float sx1 = mx + hgt * dy / dist, sy1 = my - hgt * dx / dist;
        float sx2 = mx - hgt * dy / dist, sy2 = my + hgt * dx / dist;
        float sx = sx1 > sx2 ? sx1 : sx2, sy = sx1 > sx2 ? sy1 : sy2;
        Paint arm = stroke(withAlpha(BONE, 0.85f), Math.max(1f, r * 0.03f));
        arm.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(px, py, sx, sy, arm);
        c.drawCircle(px, py, r * 0.08f, fill(BONE));
        c.drawCircle(sx, sy, Math.max(1.5f, r * 0.045f), fill(s.accent));
    }

    static void powerGauge(Canvas c, float cx, float cy, float r, float progress, Style s) {
        int n = 30;
        int lit = Math.round(progress * n);
        float gr = r * 0.82f;
        RectF oval = new RectF(cx - gr, cy - gr, cx + gr, cy + gr);
        glow(c, cx, cy, r * 1.15f, withAlpha(s.accent, 0.18f));
        Paint seg = stroke(0, r * 0.2f);
        for (int i = 0; i < n; i++) {
            seg.setColor(i < lit ? (i >= lit - 3 ? YELLOW : s.accent) : withAlpha(WHITE, 0.12f));
            c.drawArc(oval, -90f + i * (360f / n) + 1.5f, 360f / n - 3f, false, seg);
        }
        c.drawCircle(cx, cy, r * 0.52f, fill(withAlpha(BLACK, 0.35f)));
        if (lit > 0) {
            double a = Math.toRadians(-90 + (lit - 0.5) * 360.0 / n);
            float bx = cx + (float) Math.cos(a) * gr, by = cy + (float) Math.sin(a) * gr;
            c.drawPath(starPath(bx, by, r * 0.22f, r * 0.11f, 8, 0f, 0L), fill(WHITE));
        }
        Paint t = text(YELLOW, s.titleJa, r * 0.56f, Paint.Align.CENTER);
        drawCentered(c, ThemeSpecs.seal(s.theme), cx, cy, t);
    }

    static void moon(Canvas c, float cx, float cy, float r, float progress, Style s) {
        float mr = r * 0.78f;
        glow(c, cx, cy, r * 1.25f, withAlpha(0xFFBFD8FF, 0.28f * (0.4f + progress)));
        c.drawCircle(cx, cy, mr, fill(withAlpha(0xFF061528, 0.85f)));
        c.drawCircle(cx, cy, mr, stroke(withAlpha(0xFFBFD8FF, 0.35f), 1f));
        if (progress > 0f) {
            float k = 0.5523f;
            float tx = mr * (1f - 2f * progress); // terminator half-width (signed)
            Path lit = new Path();
            lit.moveTo(cx, cy - mr);
            lit.cubicTo(cx + mr * k, cy - mr, cx + mr, cy - mr * k, cx + mr, cy);
            lit.cubicTo(cx + mr, cy + mr * k, cx + mr * k, cy + mr, cx, cy + mr);
            lit.cubicTo(cx + tx * k, cy + mr, cx + tx, cy + mr * k, cx + tx, cy);
            lit.cubicTo(cx + tx, cy - mr * k, cx + tx * k, cy - mr, cx, cy - mr);
            lit.close();
            Paint face = new Paint(Paint.ANTI_ALIAS_FLAG);
            face.setShader(new RadialGradient(cx + mr * 0.2f, cy - mr * 0.2f, mr * 1.2f, 0xFFF2FBFF, 0xFFA9DCEB, Shader.TileMode.CLAMP));
            c.drawPath(lit, face);
        }
        drawSparkle(c, cx - r * 0.85f, cy - r * 0.7f, r * 0.34f, WHITE);
        drawSparkle(c, cx + r * 0.9f, cy + r * 0.62f, r * 0.24f, withAlpha(CYAN, 0.9f));
    }

    static void ironDial(Canvas c, float cx, float cy, float r, float progress, Style s) {
        Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        ring.setShader(new LinearGradient(cx - r, cy - r, cx + r, cy + r, 0xFF4E5450, 0xFF1A1D1B, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, ring);
        c.drawCircle(cx, cy, r, stroke(0xFF0A0B0A, 1.2f));
        Paint tick = stroke(withAlpha(BONE, 0.55f), Math.max(1f, r * 0.03f));
        for (int i = 0; i < 12; i++) {
            double a = Math.toRadians(-90 + i * 30);
            float r0 = r * 0.86f, r1 = r * 0.96f;
            c.drawLine(cx + (float) Math.cos(a) * r0, cy + (float) Math.sin(a) * r0, cx + (float) Math.cos(a) * r1, cy + (float) Math.sin(a) * r1, tick);
        }
        Paint arc = stroke(s.accent, r * 0.11f);
        float ar = r * 0.72f;
        c.drawArc(new RectF(cx - ar, cy - ar, cx + ar, cy + ar), -90f, 360f, false, stroke(withAlpha(BLACK, 0.5f), r * 0.11f));
        if (progress > 0f) c.drawArc(new RectF(cx - ar, cy - ar, cx + ar, cy + ar), -90f, 360f * progress, false, arc);
        Paint plate = new Paint(Paint.ANTI_ALIAS_FLAG);
        plate.setShader(new RadialGradient(cx - r * 0.15f, cy - r * 0.15f, r * 0.6f, 0xFF464C48, 0xFF1C1F1D, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r * 0.5f, plate);
        Paint rivet = fill(0xFF8E948F);
        for (int i = 0; i < 4; i++) {
            double a = Math.toRadians(45 + i * 90);
            c.drawCircle(cx + (float) Math.cos(a) * r * 0.38f, cy + (float) Math.sin(a) * r * 0.38f, r * 0.035f, rivet);
        }
        Paint t = text(BONE, s.titleJa, r * 0.5f, Paint.Align.CENTER);
        drawCentered(c, ThemeSpecs.seal(s.theme), cx, cy, t);
    }

    /** Theme choice card for Settings: textured body, seal, name with its mark, and a row of dots. */
    public static void drawThemeCard(Canvas c, float w, float h, Style s, boolean selected) {
        RectF r = new RectF(0f, 0f, w, h);
        float radius = 16f;
        c.save();
        c.clipPath(roundPath(r, radius));
        texture(c, r, s, 1f);
        c.restore();
        if (selected) {
            RectF e = new RectF(r);
            e.inset(1.5f, 1.5f);
            c.drawRoundRect(e, radius - 1.5f, radius - 1.5f, stroke(s.accent == s.holiday ? s.todayLabel : s.accent, 3f));
        }
        float p = 12f;
        RectF seal = new RectF(p, p, p + 18f, p + 18f);
        drawSeal(c, seal, ThemeSpecs.seal(s.theme), s);
        Paint ja = title(s, true, s.text, 17f, Paint.Align.LEFT, false);
        float base = seal.centerY() - (ja.ascent() + ja.descent()) / 2f;
        String name = ThemeSpecs.nameJa(s.theme);
        float nx = seal.right + 8f;
        drawTitleMark(c, nx, base, ja.measureText(name), 17f, s);
        c.drawText(name, nx, base, ja);
        Paint en = title(s, false, s.sub, 12f, Paint.Align.LEFT, false);
        c.drawText(ThemeSpecs.nameEn(s.theme), nx + ja.measureText(name) + 12f, base, en);
        int[] states = {PASSED, PASSED, PASSED, TODAY, FUTURE, HOLIDAY, FUTURE};
        float cw = (w - 2f * p) / 7f;
        float cell = Math.min(cw, h - p - (p + 30f));
        float cy = h - p - cell / 2f;
        for (int i = 0; i < 7; i++) drawDay(c, p + cw * (i + 0.5f), cy, cell, new Day(10 + i, states[i]), s, false);
    }

    /** Colour of the pulsing glow round today: the orb's colour for Spirit, warm gold for the sunflower. */
    public static int pulseColor(Style s) {
        int c;
        if (s.theme == ThemeSpecs.REI) c = orb(s.orb)[0];
        else if (s.theme == ThemeSpecs.RONIN && s.todayIcon) c = 0xFFFFC23A;
        else c = s.today;
        return s.lightWall ? ThemeSpecs.deepen(c, 0.5f) : c;
    }

    /**
     * One frame of the pulsing glow: a soft ring of light round today's dot, clear in the middle so
     * the dot itself stays crisp underneath. The widget cross-fades this frame in and out.
     */
    public static void drawPulseGlow(Canvas c, float cx, float cy, float cell, Style s) {
        int col = pulseColor(s);
        float outer = cell * 1.1f;
        float hole = cell * 0.3f;
        float h = hole / outer;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(cx, cy, outer,
                new int[]{withAlpha(col, 0f), withAlpha(col, 0f), withAlpha(col, s.lightWall ? 0.5f : 0.42f), withAlpha(col, 0.15f), withAlpha(col, 0f)},
                new float[]{0f, h * 0.85f, h + 0.06f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, outer, p);
    }

    /** Settings tile: the theme's surface with today's icon in the middle. */
    public static void drawTodaySample(Canvas c, float w, float h, Style s) {
        RectF r = new RectF(0f, 0f, w, h);
        texture(c, r, s, 1f);
        float cell = Math.min(w, h) * 0.6f;
        drawDay(c, w / 2f, h / 2f, cell, new Day(14, TODAY), s, false);
    }

    /** Settings tile: a scrap of sample wallpaper with a tiny widget on it, using s.background. */
    public static void drawBackgroundSample(Canvas c, float w, float h, Style s) {
        drawBackdrop(c, w, h, s.lightWall);
        float inset = Math.min(w, h) * 0.14f;
        RectF r = new RectF(inset, inset, w - inset, h - inset);
        drawSurface(c, r, Math.min(14f, r.height() * 0.3f), s, true);
        int[] states = {PASSED, PASSED, TODAY, FUTURE, FUTURE};
        int n = states.length;
        float cell = Math.min((r.width() - 12f) / n, r.height() * 0.62f);
        float x0 = r.centerX() - cell * (n - 1) / 2f;
        for (int i = 0; i < n; i++) drawDay(c, x0 + i * cell, r.centerY(), cell, new Day(12 + i, states[i]), s, true);
    }

    /** A dusk "wallpaper" used behind the widget preview in Settings. */
    public static void drawBackdrop(Canvas c, float w, float h) {
        drawBackdrop(c, w, h, false);
    }

    /** The preview wallpaper: dark dusk, or a light off-white one for the light-wallpaper option. */
    public static void drawBackdrop(Canvas c, float w, float h, boolean light) {
        if (light) {
            Paint paper = new Paint(Paint.ANTI_ALIAS_FLAG);
            paper.setShader(new LinearGradient(0f, 0f, 0f, h, 0xFFF6F3EC, 0xFFE4DFD4, Shader.TileMode.CLAMP));
            c.drawRect(0f, 0f, w, h, paper);
            glow(c, w * 0.78f, h * 0.8f, Math.max(w, h) * 0.38f, withAlpha(0xFFF2C6A4, 0.45f));
            glow(c, w * 0.15f, h * 0.2f, Math.max(w, h) * 0.3f, withAlpha(0xFFBFD9E6, 0.4f));
            return;
        }
        Paint sky = new Paint(Paint.ANTI_ALIAS_FLAG);
        sky.setShader(new LinearGradient(0f, 0f, 0f, h,
                new int[]{0xFF1C1C1A, 0xFF2A2320, 0xFF4A2A1E},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0f, 0f, w, h, sky);
        glow(c, w * 0.75f, h * 0.78f, Math.max(w, h) * 0.4f, withAlpha(0xFFFF6B1A, 0.35f));
        c.drawCircle(w * 0.75f, h * 0.78f, Math.min(w, h) * 0.16f, fill(withAlpha(0xFFFF6B1A, 0.75f)));
    }
}
