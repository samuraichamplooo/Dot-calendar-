package dev.dotcalendar.render;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.util.Random;

/**
 * Minimal dot calendar: flat dots on a dark (or paper) ground, one orange dot for today.
 * The Japanese side is carried by type and small accents in a Samurai Champloo spirit:
 * ink-brush kanji, a vermilion hanko seal, hip-hop marker lettering for English titles,
 * an optional sunflower for today, and a vinyl record for the year in the app.
 *
 * All coordinates are in dp: callers scale the canvas by the screen density first.
 * Used by both the app and the home-screen widgets so they always match.
 */
public final class Renderer {
    private Renderer() {}

    // Day states
    public static final int PASSED = 0, TODAY = 1, HOLIDAY = 2, FUTURE = 3;
    // Widget backgrounds
    public static final int BG_SOLID = 0, BG_GLASS = 1, BG_BLUR = 2, BG_CLEAR = 3;

    // Palette
    public static final int DARK_BG = 0xFF1C1C1A;
    public static final int DARK_PANEL = 0xFF272623;
    public static final int PAPER_BG = 0xFFECE7DD;
    public static final int PAPER_PANEL = 0xFFE1DBCE;
    public static final int OFF_WHITE = 0xFFE6E2D8;
    public static final int INK = 0xFF22211E;
    public static final int DIM = 0xFF3A3935;
    public static final int ORANGE = 0xFFFF6B1A;
    public static final int SEAL = 0xFFD23A2A;
    public static final int INK_TEXT = INK;
    public static final int PAPER_TEXT = OFF_WHITE;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int BLACK = 0xFF000000;

    // ------------------------------------------------------------------ colour helpers

    public static int withAlpha(int color, float alpha) {
        int a = Math.round(clamp(alpha, 0f, 1f) * 255f);
        return (a << 24) | (color & 0x00FFFFFF);
    }

    public static int mix(int a, int b, float t) {
        t = clamp(t, 0f, 1f);
        int aa = (a >>> 24), ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24), br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return (Math.round(aa + (ba - aa) * t) << 24) | (Math.round(ar + (br - ar) * t) << 16)
                | (Math.round(ag + (bg - ag) * t) << 8) | Math.round(ab + (bb - ab) * t);
    }

    public static float luminance(int c) {
        return (0.299f * ((c >> 16) & 0xFF) + 0.587f * ((c >> 8) & 0xFF) + 0.114f * (c & 0xFF)) / 255f;
    }

    public static int contrastOn(int bg) {
        return luminance(bg) > 0.6f ? INK : WHITE;
    }

    static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    // ------------------------------------------------------------------ paint helpers

    static Paint fill(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        return p;
    }

    static Paint stroke(int color, float width) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(width);
        p.setColor(color);
        return p;
    }

    static Paint text(int color, Typeface tf, float size, Paint.Align align) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        p.setTypeface(tf);
        p.setTextSize(size);
        p.setTextAlign(align);
        return p;
    }

    /** Soft shadow under text when the widget has no background of its own. */
    static void readable(Paint p, Style s, boolean widget) {
        if (widget && s.background == BG_CLEAR) p.setShadowLayer(3f, 0f, 1f, withAlpha(BLACK, 0.6f));
    }

    static void drawCentered(Canvas c, String str, float cx, float cy, Paint p) {
        c.drawText(str, cx, cy - (p.ascent() + p.descent()) / 2f, p);
    }

    static void fit(Paint p, String str, float maxWidth, float minSize) {
        float w = p.measureText(str);
        if (w > maxWidth && w > 0f) p.setTextSize(Math.max(minSize, p.getTextSize() * maxWidth / w));
    }

    static Path roundPath(RectF r, float radius) {
        Path p = new Path();
        p.addRoundRect(r, radius, radius, Path.Direction.CW);
        return p;
    }

    static int dim(Style s) {
        return withAlpha(s.text, 0.42f);
    }

    // ------------------------------------------------------------------ backgrounds

    /** Widget background: flat panel, glass, frosted ("blur"), or nothing. */
    public static void drawWidgetBackground(Canvas c, RectF r, float radius, Style s) {
        switch (s.background) {
            case BG_SOLID:
                c.drawRoundRect(r, radius, radius, fill(s.paper ? PAPER_PANEL : DARK_PANEL));
                break;
            case BG_GLASS:
                glass(c, r, radius, s);
                break;
            case BG_BLUR:
                frosted(c, r, radius, s);
                break;
            default:
                break;
        }
    }

    static void glass(Canvas c, RectF r, float radius, Style s) {
        Path shape = roundPath(r, radius);
        c.drawPath(shape, fill(withAlpha(s.paper ? WHITE : 0xFF0E0E0D, 0.08f + 0.45f * s.opacity)));
        c.save();
        c.clipPath(shape);
        Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
        sheen.setShader(new LinearGradient(r.left, r.top, r.left + r.width() * 0.6f, r.bottom,
                new int[]{withAlpha(WHITE, 0.16f), withAlpha(WHITE, 0.03f), withAlpha(WHITE, 0f)},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(r, sheen);
        c.restore();
        RectF e = new RectF(r);
        e.inset(0.5f, 0.5f);
        Paint edge = stroke(0, 1f);
        edge.setShader(new LinearGradient(r.left, r.top, r.left, r.bottom,
                withAlpha(WHITE, 0.45f), withAlpha(WHITE, 0.10f), Shader.TileMode.CLAMP));
        c.drawRoundRect(e, radius - 0.5f, radius - 0.5f, edge);
    }

    /** Android can't blur the wallpaper behind a widget, so this is drawn as frosted glass. */
    static void frosted(Canvas c, RectF r, float radius, Style s) {
        Path shape = roundPath(r, radius);
        c.drawPath(shape, fill(withAlpha(s.paper ? 0xFFF2EEE6 : 0xFF2A2927, 0.35f + 0.55f * s.opacity)));
        c.save();
        c.clipPath(shape);
        float big = Math.max(r.width(), r.height());
        glow(c, r.left + r.width() * 0.85f, r.top + r.height() * 0.15f, big * 0.55f, withAlpha(s.today, 0.16f));
        glow(c, r.left + r.width() * 0.1f, r.bottom - r.height() * 0.1f, big * 0.5f, withAlpha(s.holiday, 0.10f));
        Random rnd = new Random(23);
        int n = (int) (r.width() * r.height() / 14f);
        Paint g = fill(0);
        for (int i = 0; i < n; i++) {
            g.setColor(withAlpha(WHITE, 0.03f + rnd.nextFloat() * 0.05f));
            c.drawCircle(r.left + rnd.nextFloat() * r.width(), r.top + rnd.nextFloat() * r.height(), 0.3f + rnd.nextFloat() * 0.3f, g);
        }
        c.restore();
        RectF e = new RectF(r);
        e.inset(0.5f, 0.5f);
        c.drawRoundRect(e, radius - 0.5f, radius - 0.5f, stroke(withAlpha(WHITE, 0.22f), 1f));
    }

    static void glow(Canvas c, float x, float y, float radius, int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(x, y, radius, color, color & 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, radius, p);
    }

    // ------------------------------------------------------------------ small parts

    /** Flat vermilion hanko seal with a brush character. */
    public static void drawSeal(Canvas c, RectF r, String glyph, Typeface brush) {
        float rad = r.width() * 0.14f;
        c.drawRoundRect(r, rad, rad, fill(SEAL));
        RectF in = new RectF(r);
        in.inset(r.width() * 0.1f, r.height() * 0.1f);
        c.drawRoundRect(in, rad * 0.5f, rad * 0.5f, stroke(withAlpha(OFF_WHITE, 0.85f), Math.max(0.6f, r.width() * 0.045f)));
        Paint t = text(OFF_WHITE, brush, r.height() * 0.58f, Paint.Align.CENTER);
        drawCentered(c, glyph, r.centerX(), r.centerY(), t);
    }

    /** Small "日 / EN" switch: the active language is bright, the other dim. */
    public static void drawLangChip(Canvas c, RectF r, boolean japanese, Style s, boolean widget) {
        float rad = r.height() / 2f;
        c.drawRoundRect(r, rad, rad, stroke(withAlpha(s.text, 0.22f), 1f));
        float cw = r.width() / 2f;
        Paint ja = text(withAlpha(s.text, japanese ? 1f : 0.35f), s.brush, r.height() * 0.58f, Paint.Align.CENTER);
        Paint en = text(withAlpha(s.text, japanese ? 0.35f : 1f), s.sans, r.height() * 0.46f, Paint.Align.CENTER);
        readable(ja, s, widget);
        readable(en, s, widget);
        drawCentered(c, "日", r.left + cw * 0.55f + 2f, r.centerY(), ja);
        drawCentered(c, "EN", r.left + cw * 1.45f - 2f, r.centerY(), en);
        float dotX = japanese ? r.left + cw * 0.55f + 2f : r.left + cw * 1.45f - 2f;
        c.drawCircle(dotX, r.bottom - 2.4f, 1.1f, fill(s.today));
    }


    /**
     * A hand-painted ink stroke: thick where the brush lands, tapering out, with dry-brush
     * streaks near the end. Used as a vermilion swipe under titles.
     */
    public static void drawBrushStroke(Canvas c, float x0, float y, float x1, float thickness, int color, long seed) {
        if (x1 - x0 < 4f) return;
        Random rnd = new Random(seed);
        int n = 28;
        float[] top = new float[n + 1], bot = new float[n + 1], xs = new float[n + 1];
        for (int i = 0; i <= n; i++) {
            float t = i / (float) n;
            float w = thickness * (t < 0.12f ? 0.55f + t / 0.12f * 0.45f : 1f - (t - 0.12f) / 0.88f * 0.8f);
            float bend = (float) Math.sin(t * Math.PI) * thickness * 0.35f;
            xs[i] = x0 + (x1 - x0) * t;
            top[i] = y - bend - w / 2f + (rnd.nextFloat() - 0.5f) * thickness * 0.12f;
            bot[i] = y - bend + w / 2f + (rnd.nextFloat() - 0.5f) * thickness * 0.12f;
        }
        Path p = new Path();
        p.moveTo(xs[0], top[0]);
        for (int i = 1; i <= n; i++) p.lineTo(xs[i], top[i]);
        for (int i = n; i >= 0; i--) p.lineTo(xs[i], bot[i]);
        p.close();
        RectF bounds = new RectF(x0 - 2f, y - thickness * 2f, x1 + 2f, y + thickness * 2f);
        int save = c.saveLayer(bounds, null);
        c.drawPath(p, fill(color));
        // round brush head
        c.drawCircle(xs[0] + thickness * 0.15f, (top[0] + bot[0]) / 2f, (bot[0] - top[0]) / 2f, fill(color));
        // dry-brush streaks: thin gaps through the tail
        Paint gap = stroke(0, Math.max(0.4f, thickness * 0.09f));
        gap.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        for (int k = 0; k < 3; k++) {
            float start = 0.35f + rnd.nextFloat() * 0.25f;
            float off = (rnd.nextFloat() - 0.5f) * thickness * 0.5f;
            Path g = new Path();
            int i0 = (int) (start * n);
            g.moveTo(xs[i0], (top[i0] + bot[i0]) / 2f + off);
            for (int i = i0 + 1; i <= n; i++) g.lineTo(xs[i], (top[i] + bot[i]) / 2f + off * (1f - (i - i0) / (float) (n - i0)) );
            c.drawPath(g, gap);
        }
        c.restoreToCount(save);
    }

    // ------------------------------------------------------------------ days

    /**
     * One day. {@code size} is the cell's usable size; the dot itself is smaller unless
     * numbers are shown inside it.
     */
    public static void drawDay(Canvas c, float cx, float cy, float size, Day d, Style s, boolean widget) {
        float dot = dotSize(size, s);
        float r = dot / 2f;
        if (d.state == TODAY) {
            glow(c, cx, cy, dot * 1.25f, withAlpha(s.today, 0.38f));
            if (s.sunflower) {
                drawSunflower(c, cx, cy, dot * 1.25f, s.today);
                if (s.numbers) numberIn(c, cx, cy, dot * 0.85f, d.number, WHITE, s);
                return;
            }
        }
        boolean filled = d.state == PASSED || d.state == TODAY;
        int color;
        if (d.state == PASSED) color = s.passed;
        else if (d.state == TODAY) color = s.today;
        else if (d.state == HOLIDAY) color = s.holiday;
        else color = s.future;

        if (filled) {
            shape(c, cx, cy, r, fill(color), s);
            if (s.numbers) numberIn(c, cx, cy, dot, d.number, contrastOn(color), s);
        } else if (d.state == HOLIDAY) {
            // upcoming Sunday / holiday: a ring in the holiday colour
            float lw = Math.max(1.2f, dot * 0.11f);
            shape(c, cx, cy, r - lw / 2f, stroke(color, lw), s);
            if (s.numbers) numberIn(c, cx, cy, dot, d.number, color, s);
        } else {
            shape(c, cx, cy, r, fill(color), s);
            if (s.numbers) numberIn(c, cx, cy, dot, d.number, withAlpha(s.text, 0.55f), s);
        }
    }

    /** A blank grid cell (before the 1st / after the last day): a very faint dot. */
    static void drawBlank(Canvas c, float cx, float cy, float size, Style s) {
        float r = dotSize(size, s) / 2f;
        shape(c, cx, cy, r, fill(withAlpha(s.future, 0.4f)), s);
    }

    static float dotSize(float cell, Style s) {
        return s.numbers ? cell * 0.74f : cell * 0.46f;
    }

    static void shape(Canvas c, float cx, float cy, float r, Paint p, Style s) {
        if (s.squares) {
            float rr = r * 0.32f;
            c.drawRoundRect(new RectF(cx - r, cy - r, cx + r, cy + r), rr, rr, p);
        } else {
            c.drawCircle(cx, cy, r, p);
        }
    }

    static void numberIn(Canvas c, float cx, float cy, float dot, int n, int color, Style s) {
        if (dot < 11f) return;
        Paint t = text(color, s.sans, dot * 0.42f, Paint.Align.CENTER);
        drawCentered(c, String.valueOf(n), cx, cy, t);
    }

    /** A small flat sunflower: two rings of petals around a dark centre. */
    public static void drawSunflower(Canvas c, float cx, float cy, float size, int petal) {
        float r = size / 2f;
        Paint back = fill(mix(petal, BLACK, 0.25f));
        Paint front = fill(petal);
        RectF petalRect = new RectF(cx - r * 0.16f, cy - r, cx + r * 0.16f, cy - r * 0.4f);
        for (int layer = 0; layer < 2; layer++) {
            for (int i = 0; i < 12; i++) {
                c.save();
                c.rotate(i * 30f + (layer == 0 ? 15f : 0f), cx, cy);
                c.drawOval(petalRect, layer == 0 ? back : front);
                c.restore();
            }
        }
        c.drawCircle(cx, cy, r * 0.46f, fill(0xFF3A2212));
        c.drawCircle(cx, cy, r * 0.46f, stroke(0xFF26150B, Math.max(0.5f, size * 0.02f)));
    }

    // ------------------------------------------------------------------ month widget

    static float edge(float w, float h) {
        return clamp(Math.min(w, h) * 0.05f, 10f, 16f);
    }

    /** Where the 日/EN switch sits in the month widget: {left, top, width, height} in dp. */
    public static float[] monthLcdRect(float w, float h) {
        float p = edge(w, h);
        float cw = 52f, ch = 22f;
        return new float[]{w - p - cw, p + 3f, cw, ch};
    }

    public static void drawMonthWidget(Canvas c, float w, float h, Style s, MonthData m) {
        RectF all = new RectF(0f, 0f, w, h);
        drawWidgetBackground(c, all, 24f, s);
        float p = edge(w, h);
        float headerH = 28f;

        // header: seal, brush (JA) or marker (EN) month, traditional name
        RectF seal = new RectF(p, p + 5f, p + 18f, p + 23f);
        drawSeal(c, seal, m.seal, s.brush);
        float[] l = monthLcdRect(w, h);
        RectF chip = new RectF(l[0], l[1], l[0] + l[2], l[1] + l[3]);
        Paint tp = text(s.text, m.japanese ? s.brush : s.marker, m.japanese ? 21f : 16f, Paint.Align.LEFT);
        readable(tp, s, true);
        float tx = seal.right + 8f;
        fit(tp, m.title, chip.left - 8f - tx, 10f);
        float base = seal.centerY() - (tp.ascent() + tp.descent()) / 2f;
        float titleW = tp.measureText(m.title);
        drawBrushStroke(c, tx - 3f, base + 4.5f, tx + titleW + 10f, 4.2f, withAlpha(SEAL, 0.92f), 7L);
        c.drawText(m.title, tx, base, tp);
        Paint sub = text(dim(s), m.japanese ? s.brush : s.sans, m.japanese ? 11f : 9f, Paint.Align.LEFT);
        readable(sub, s, true);
        float sx = tx + titleW + 13f;
        if (sx + sub.measureText(m.subtitle) <= chip.left - 6f) c.drawText(m.subtitle, sx, base, sub);
        drawLangChip(c, chip, m.japanese, s, true);

        // weekday initials
        boolean footer = h >= 190f;
        float top = p + headerH + 6f;
        float wh = 14f;
        float gw = w - 2f * p, cw = gw / 7f;
        Paint wp = text(0, m.japanese ? s.brush : s.sans, m.japanese ? 10f : 8f, Paint.Align.CENTER);
        readable(wp, s, true);
        for (int i = 0; i < 7; i++) {
            wp.setColor(i == m.todayColumn ? s.today : (i == 0 ? withAlpha(s.holiday, 0.85f) : dim(s)));
            drawCentered(c, m.weekdays[i], p + cw * (i + 0.5f), top + wh / 2f, wp);
        }

        // dots
        float gy = top + wh + 2f;
        float gh = h - p - gy - (footer ? 18f : 0f);
        int rows = Math.max(1, m.weeks.length);
        float ch = gh / rows;
        float cell = Math.min(cw, ch);
        for (int r = 0; r < m.weeks.length; r++) {
            for (int col = 0; col < 7; col++) {
                float cx = p + cw * (col + 0.5f), cy = gy + ch * (r + 0.5f);
                Day d = m.weeks[r][col];
                if (d != null) drawDay(c, cx, cy, cell, d, s, true);
                else drawBlank(c, cx, cy, cell, s);
            }
        }

        // footer: era on the left, days passed on the right
        if (footer) {
            float fy = h - p - 3f;
            Paint fl = text(dim(s), m.japanese ? s.brush : s.sans, m.japanese ? 10.5f : 9f, Paint.Align.LEFT);
            Paint fr = text(dim(s), s.sans, 9.5f, Paint.Align.RIGHT);
            readable(fl, s, true);
            readable(fr, s, true);
            c.drawText(m.era, p + cw * 0.5f - dotSize(cell, s) / 2f, fy, fl);
            c.drawText(m.count, w - p - cw * 0.5f + dotSize(cell, s) / 2f, fy, fr);
        }
    }

    // ------------------------------------------------------------------ week widget

    /** The date block on the left of the week widget (tap it to switch language): {left, top, width, height}. */
    public static float[] weekLcdRect(float w, float h) {
        float p = 12f;
        float bw = clamp(w * 0.28f, 80f, 124f);
        return new float[]{p, p, bw, h - 2f * p};
    }

    public static void drawWeekWidget(Canvas c, float w, float h, Style s, WeekData d) {
        RectF all = new RectF(0f, 0f, w, h);
        drawWidgetBackground(c, all, Math.min(24f, h * 0.32f), s);
        float[] l = weekLcdRect(w, h);
        RectF block = new RectF(l[0], l[1], l[0] + l[2], l[1] + l[3]);

        // big date, clean sans like a clock face
        Paint big = text(s.text, s.sans, clamp(block.height() * 0.42f, 16f, 34f), Paint.Align.LEFT);
        readable(big, s, true);
        fit(big, d.bigDate, block.width(), 12f);
        Paint day = text(dim(s), d.japanese ? s.brush : s.sans, d.japanese ? 13f : 10f, Paint.Align.LEFT);
        readable(day, s, true);
        float chipH = 18f, chipW = 42f;
        float gap = 3f;
        float textH = (-big.ascent() + big.descent() * 0.4f) + gap + chipH;
        float y0 = block.centerY() - textH / 2f;
        float baseBig = y0 - big.ascent();
        c.drawText(d.bigDate, block.left, baseBig, big);
        RectF chip = new RectF(block.right - chipW, baseBig + big.descent() * 0.4f + gap,
                block.right, baseBig + big.descent() * 0.4f + gap + chipH);
        fit(day, d.dayName, chip.left - block.left - 6f, 7f);
        c.drawText(d.dayName, block.left, chip.centerY() - (day.ascent() + day.descent()) / 2f, day);
        drawLangChip(c, chip, d.japanese, s, true);

        // seven dots with weekday initials
        float x0 = block.right + 14f, x1 = w - 12f, cw = (x1 - x0) / 7f;
        float labelH = 14f;
        float avail = h - 24f - labelH - 2f;
        float cell = Math.min(cw, avail);
        float groupH = labelH + 2f + cell;
        float top = (h - groupH) / 2f;
        Paint lp = text(0, d.japanese ? s.brush : s.sans, d.japanese ? 10.5f : 8f, Paint.Align.CENTER);
        readable(lp, s, true);
        for (int i = 0; i < 7; i++) {
            float cx = x0 + cw * (i + 0.5f);
            lp.setColor(i == d.todayIndex ? s.today : (d.redLabels[i] ? withAlpha(s.holiday, 0.85f) : dim(s)));
            drawCentered(c, d.weekdays[i], cx, top + labelH / 2f, lp);
            drawDay(c, cx, top + labelH + 2f + cell / 2f, cell, d.days[i], s, true);
        }
    }

    // ------------------------------------------------------------------ app pieces

    /** Height of the in-app month grid for a given width (dp). */
    public static float monthGridHeight(float w, int rows) {
        return 24f + rows * (w / 7f) * 0.82f;
    }

    /** Month grid without a background, for the app screen. */
    public static void drawMonthGrid(Canvas c, float w, Style s, MonthData m) {
        float cw = w / 7f, ch = cw * 0.82f;
        Paint wp = text(0, m.japanese ? s.brush : s.sans, m.japanese ? 13f : 10f, Paint.Align.CENTER);
        for (int i = 0; i < 7; i++) {
            wp.setColor(i == m.todayColumn ? s.today : (i == 0 ? withAlpha(s.holiday, 0.85f) : dim(s)));
            drawCentered(c, m.weekdays[i], cw * (i + 0.5f), 10f, wp);
        }
        float cell = Math.min(cw, ch);
        for (int r = 0; r < m.weeks.length; r++) {
            for (int col = 0; col < 7; col++) {
                float cx = cw * (col + 0.5f), cy = 24f + ch * (r + 0.5f);
                Day d = m.weeks[r][col];
                if (d != null) drawDay(c, cx, cy, cell, d, s, false);
                else drawBlank(c, cx, cy, cell, s);
            }
        }
    }

    /**
     * The year as a record: the tonearm moves from the outer groove (1 January) toward the
     * label (31 December) and an orange arc traces the days that have passed.
     */
    public static void drawVinyl(Canvas c, float cx, float cy, float r, float progress, Style s, String label) {
        progress = clamp(progress, 0f, 1f);
        c.drawCircle(cx, cy, r, fill(s.paper ? 0xFF1E1D1B : 0xFF121211));
        Paint groove = stroke(withAlpha(WHITE, 0.05f), 0.6f);
        for (float gr = r * 0.93f; gr > r * 0.42f; gr -= r * 0.09f) c.drawCircle(cx, cy, gr, groove);

        Paint arc = stroke(s.today, Math.max(1.5f, r * 0.045f));
        arc.setStrokeCap(Paint.Cap.ROUND);
        float ar = r * 0.88f;
        if (progress > 0f) c.drawArc(new RectF(cx - ar, cy - ar, cx + ar, cy + ar), -90f, 360f * progress, false, arc);

        float lr = r * 0.34f;
        c.drawCircle(cx, cy, lr, fill(SEAL));
        Paint lt = text(OFF_WHITE, s.brush, lr * 0.85f, Paint.Align.CENTER);
        drawCentered(c, label, cx, cy, lt);

        // tonearm
        float px = cx + r * 1.0f, py = cy - r * 0.95f;
        float dx = cx - px, dy = cy - py;
        float dist = (float) Math.hypot(dx, dy);
        float armLen = r * 1.15f;
        float rs = r * 0.9f - progress * (r * 0.9f - r * 0.45f);
        float a = (armLen * armLen - rs * rs + dist * dist) / (2f * dist);
        float hgt = (float) Math.sqrt(Math.max(0f, armLen * armLen - a * a));
        float mx = px + a * dx / dist, my = py + a * dy / dist;
        float sx1 = mx + hgt * dy / dist, sy1 = my - hgt * dx / dist;
        float sx2 = mx - hgt * dy / dist, sy2 = my + hgt * dx / dist;
        float sx = sx1 > sx2 ? sx1 : sx2, sy = sx1 > sx2 ? sy1 : sy2;
        int armColor = s.paper ? INK : OFF_WHITE;
        Paint arm = stroke(withAlpha(armColor, 0.75f), Math.max(1f, r * 0.03f));
        arm.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(px, py, sx, sy, arm);
        c.drawCircle(px, py, r * 0.08f, fill(withAlpha(armColor, 0.85f)));
        c.drawCircle(sx, sy, Math.max(1.5f, r * 0.04f), fill(s.today));
    }

    /** A dusk "wallpaper" used behind the widget preview in Settings. */
    public static void drawBackdrop(Canvas c, float w, float h) {
        Paint sky = new Paint(Paint.ANTI_ALIAS_FLAG);
        sky.setShader(new LinearGradient(0f, 0f, 0f, h,
                new int[]{0xFF1C1C1A, 0xFF2A2320, 0xFF4A2A1E},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0f, 0f, w, h, sky);
        glow(c, w * 0.75f, h * 0.78f, Math.max(w, h) * 0.4f, withAlpha(ORANGE, 0.35f));
        c.drawCircle(w * 0.75f, h * 0.78f, Math.min(w, h) * 0.16f, fill(withAlpha(ORANGE, 0.75f)));
    }
}
