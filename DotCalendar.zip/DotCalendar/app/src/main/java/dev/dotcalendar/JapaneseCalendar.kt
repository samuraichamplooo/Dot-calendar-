package dev.dotcalendar

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

/** Japanese labels: era years (令和), kanji weekdays, traditional month names. Weeks start on Sunday. */
object JapaneseCalendar {

    val WEEKDAYS = listOf("日", "月", "火", "水", "木", "金", "土")

    private val TRADITIONAL_MONTHS = listOf(
        "睦月", "如月", "弥生", "卯月", "皐月", "水無月",
        "文月", "葉月", "長月", "神無月", "霜月", "師走",
    )

    fun traditionalMonth(month: Int): String = TRADITIONAL_MONTHS[month - 1]

    fun weekdayKanji(date: LocalDate): String = WEEKDAYS[date.dayOfWeek.value % 7]

    /** e.g. 令和8年 (the first year of an era is written 元年). Computed by hand so older Android versions know 令和. */
    fun eraYear(date: LocalDate): String {
        val (era, n) = when {
            date >= LocalDate.of(2019, 5, 1) -> "令和" to date.year - 2018
            date >= LocalDate.of(1989, 1, 8) -> "平成" to date.year - 1988
            date >= LocalDate.of(1926, 12, 25) -> "昭和" to date.year - 1925
            date >= LocalDate.of(1912, 7, 30) -> "大正" to date.year - 1911
            else -> "明治" to date.year - 1867
        }
        return if (n == 1) "${era}元年" else "$era${n}年"
    }

    /** e.g. 令和8年10月13日（火） */
    fun fullDate(date: LocalDate): String =
        "${eraYear(date)}${date.monthValue}月${date.dayOfMonth}日（${weekdayKanji(date)}）"

    /** Shorter form for list rows, e.g. 10月12日（月） */
    fun shortDate(date: LocalDate): String =
        "${date.monthValue}月${date.dayOfMonth}日（${weekdayKanji(date)}）"

    /** Calendar grid for a month: rows of 7 (Sunday first), with nulls for blank cells. */
    fun monthWeeks(month: YearMonth): List<List<LocalDate?>> {
        val leading = month.atDay(1).dayOfWeek.value % 7
        val cells = MutableList<LocalDate?>(leading) { null }
        for (d in 1..month.lengthOfMonth()) cells += month.atDay(d)
        while (cells.size % 7 != 0) cells += null
        return cells.chunked(7)
    }

    /** The Sunday-to-Saturday week containing [date]. */
    fun weekOf(date: LocalDate): List<LocalDate> {
        val sunday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY))
        return (0L..6L).map { sunday.plusDays(it) }
    }
}
