package dev.dotcalendar

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

/** Japanese calendar facts: eras, month names, grid layout. Weeks start on Sunday. */
object JapaneseCalendar {

    private val KANJI_MONTHS = listOf(
        "一月", "二月", "三月", "四月", "五月", "六月",
        "七月", "八月", "九月", "十月", "十一月", "十二月",
    )

    private val TRADITIONAL_MONTHS = listOf(
        "睦月", "如月", "弥生", "卯月", "皐月", "水無月",
        "文月", "葉月", "長月", "神無月", "霜月", "師走",
    )

    private val TRADITIONAL_ROMAJI = listOf(
        "Mutsuki", "Kisaragi", "Yayoi", "Uzuki", "Satsuki", "Minazuki",
        "Fumizuki", "Hazuki", "Nagatsuki", "Kannazuki", "Shimotsuki", "Shiwasu",
    )

    val WEEKDAYS_JA = listOf("日", "月", "火", "水", "木", "金", "土")

    fun kanjiMonth(month: Int): String = KANJI_MONTHS[month - 1]
    fun traditionalMonth(month: Int): String = TRADITIONAL_MONTHS[month - 1]
    fun traditionalRomaji(month: Int): String = TRADITIONAL_ROMAJI[month - 1]
    fun weekdayKanji(date: LocalDate): String = WEEKDAYS_JA[date.dayOfWeek.value % 7]

    /** Era as (kanji name, romaji name, year of era). Computed by hand so older Android versions know 令和. */
    fun era(date: LocalDate): Triple<String, String, Int> = when {
        date >= LocalDate.of(2019, 5, 1) -> Triple("令和", "Reiwa", date.year - 2018)
        date >= LocalDate.of(1989, 1, 8) -> Triple("平成", "Heisei", date.year - 1988)
        date >= LocalDate.of(1926, 12, 25) -> Triple("昭和", "Showa", date.year - 1925)
        date >= LocalDate.of(1912, 7, 30) -> Triple("大正", "Taisho", date.year - 1911)
        else -> Triple("明治", "Meiji", date.year - 1867)
    }

    /** e.g. 令和8年 (the first year of an era is written 元年). */
    fun eraYear(date: LocalDate): String {
        val (kanji, _, n) = era(date)
        return if (n == 1) "${kanji}元年" else "$kanji${n}年"
    }

    /** e.g. 令和八年, with the year in kanji numerals (元年 for the first year). */
    fun eraYearKanji(date: LocalDate): String {
        val (kanji, _, n) = era(date)
        return if (n == 1) "${kanji}元年" else "$kanji${kanjiNumber(n)}年"
    }

    /** 1–99 in kanji numerals: 8 → 八, 12 → 十二, 20 → 二十. */
    fun kanjiNumber(n: Int): String {
        val digits = listOf("", "一", "二", "三", "四", "五", "六", "七", "八", "九")
        if (n !in 1..99) return n.toString()
        val tens = n / 10
        val ones = n % 10
        val tensPart = when (tens) {
            0 -> ""
            1 -> "十"
            else -> digits[tens] + "十"
        }
        return tensPart + digits[ones]
    }

    /** e.g. REIWA 8 */
    fun eraYearRomaji(date: LocalDate): String {
        val (_, romaji, n) = era(date)
        return "${romaji.uppercase()} $n"
    }

    /** Calendar grid for a month: rows of 7 (Sunday first), with nulls for blank cells. */
    fun monthWeeks(month: YearMonth): List<List<LocalDate?>> {
        val leading = month.atDay(1).dayOfWeek.value % 7
        val cells = MutableList<LocalDate?>(leading) { null }
        for (d in 1..month.lengthOfMonth()) cells += month.atDay(d)
        while (cells.size % 7 != 0) cells += null
        return cells.chunked(7)
    }

    /** The Sunday-to-Saturday week containing [date]. */
    fun weekOf(date: LocalDate): List<LocalDate> {
        val sunday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY))
        return (0L..6L).map { sunday.plusDays(it) }
    }
}
