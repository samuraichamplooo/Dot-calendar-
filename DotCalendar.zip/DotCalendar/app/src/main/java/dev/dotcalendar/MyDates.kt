package dev.dotcalendar

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** One of the user's own dates: a birthday, a trip, an exam… */
data class MyDate(
    val id: Long,
    val name: String,
    val date: LocalDate,
    val yearly: Boolean,
    val color: Int,
) {
    /** This date in year [y] (29 Feb falls back to 28 Feb in other years). */
    fun inYear(y: Int): LocalDate = date.withYear(y)

    fun occursOn(d: LocalDate): Boolean = if (yearly) inYear(d.year) == d else date == d

    /** The next time it comes round, on or after [from]; null if it's over and doesn't repeat. */
    fun nextFrom(from: LocalDate): LocalDate? {
        if (!yearly) return if (date.isBefore(from)) null else date
        val thisYear = inYear(from.year)
        return if (thisYear.isBefore(from)) inYear(from.year + 1) else thisYear
    }
}

object MyDates {
    /** Ring colours offered for dates. */
    val COLORS: List<Int> = listOf(
        0xFFE24A8D, 0xFFF2B531, 0xFF5FA35A, 0xFF4FA3E0, 0xFF9B6BE0, 0xFFE8603C,
    ).map { it.toInt() }

    fun encode(list: List<MyDate>): String {
        val arr = JSONArray()
        list.forEach { d ->
            arr.put(
                JSONObject()
                    .put("id", d.id)
                    .put("name", d.name)
                    .put("date", d.date.toString())
                    .put("yearly", d.yearly)
                    .put("color", d.color),
            )
        }
        return arr.toString()
    }

    fun decode(json: String?): List<MyDate> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                try {
                    MyDate(
                        id = o.optLong("id", i.toLong()),
                        name = o.optString("name", ""),
                        date = LocalDate.parse(o.getString("date")),
                        yearly = o.optBoolean("yearly", false),
                        color = o.optInt("color", COLORS[0]),
                    )
                } catch (e: Exception) {
                    null
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Ring colour for [day], or 0 if none of the dates falls on it. */
    fun markFor(list: List<MyDate>, day: LocalDate): Int = list.firstOrNull { it.occursOn(day) }?.color ?: 0

    /** The nearest upcoming date (today counts) within a year, with how many days away it is. */
    fun next(list: List<MyDate>, today: LocalDate): Pair<MyDate, Long>? =
        list.mapNotNull { d -> d.nextFrom(today)?.let { d to ChronoUnit.DAYS.between(today, it) } }
            .filter { it.second <= 366 }
            .minByOrNull { it.second }

    /** All dates sorted by when they next come round; past one-off dates go last. */
    fun sorted(list: List<MyDate>, today: LocalDate): List<Pair<MyDate, LocalDate?>> =
        list.map { it to it.nextFrom(today) }
            .sortedWith(compareBy({ it.second == null }, { it.second ?: it.first.date }))
}
