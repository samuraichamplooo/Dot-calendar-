package dev.dotcalendar.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.dotcalendar.AppSettings
import dev.dotcalendar.AppTheme
import dev.dotcalendar.DotShape
import dev.dotcalendar.HolidayRegion
import dev.dotcalendar.Lang
import dev.dotcalendar.RenderBridge
import dev.dotcalendar.Surface
import dev.dotcalendar.WidgetBg
import dev.dotcalendar.render.Renderer
import dev.dotcalendar.render.ThemeSpecs
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.min

private enum class Slot { PASSED, TODAY, HOLIDAY, FUTURE, TEXT }

@Composable
fun SettingsScreen(s: AppSettings, onChange: (AppSettings) -> Unit, onBack: () -> Unit) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val appStyle = LocalAppStyle.current
    var open by remember { mutableStateOf<Slot?>(null) }
    fun toggle(slot: Slot) {
        open = if (open == slot) null else slot
    }

    fun themeName(t: AppTheme): String =
        if (tx.ja) ThemeSpecs.nameJa(t.id) else ThemeSpecs.nameEn(t.id)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FlatIconButton(Icons.AutoMirrored.Filled.ArrowBack, tx.t("戻る", "Back"), onBack)
            Spacer(Modifier.width(14.dp))
            ThemeTitle(tx.t("設定", "SETTINGS"), if (tx.ja) 27.sp else 24.sp)
        }

        Spacer(Modifier.height(20.dp))
        WidgetPreview(s)

        Spacer(Modifier.height(16.dp))
        Panel {
            SectionTitle("テーマ", "Theme")
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AppTheme.entries.forEach { t ->
                    ThemeOption(s, t, s.theme == t, themeName(t)) {
                        // A new theme brings its own colours, so custom colours are cleared.
                        onChange(s.withoutColorOverrides().copy(theme = t))
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("言語", "Language")
            SegmentGrid(listOf("日本語", "English"), if (s.lang == Lang.JA) 0 else 1) {
                onChange(s.copy(lang = if (it == 0) Lang.JA else Lang.EN))
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("祝日", "Holidays")
            val regions = listOf(HolidayRegion.JP, HolidayRegion.US, HolidayRegion.BOTH)
            SegmentGrid(
                listOf(tx.t("日本", "Japan"), tx.t("アメリカ", "US"), tx.t("両方", "Both")),
                regions.indexOf(s.holidays),
            ) { onChange(s.copy(holidays = regions[it])) }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("文字と表示", "Text & display")
            ToggleRow(tx.t("太字テキスト（読みやすく）", "Bold text (easier to read)"), s.boldText) { onChange(s.copy(boldText = it)) }
            ToggleRow(tx.t("今日をテーマのアイコンで表示（🌻 など）", "Theme icon for today (🌻 etc.)"), s.todayIcon) { onChange(s.copy(todayIcon = it)) }
            if (s.todayIcon) {
                Label("気のアイコン", "Ki icon")
                SegmentGrid(listOf(tx.t("炎", "Flame"), tx.t("爆発", "Burst")), if (s.kiFlame) 0 else 1) {
                    onChange(s.copy(kiFlame = it == 0))
                }
                Spacer(Modifier.height(6.dp))
                Label("鋼のアイコン", "Steel icon")
                SegmentGrid(listOf(tx.t("斬撃", "Slash"), tx.t("飛沫", "Splash")), if (s.steelSlash) 0 else 1) {
                    onChange(s.copy(steelSlash = it == 0))
                }
                Spacer(Modifier.height(6.dp))
            }
            ToggleRow(tx.t("ドットに日付を表示", "Show dates on the dots"), s.numbers) { onChange(s.copy(numbers = it)) }
            Spacer(Modifier.height(6.dp))
            Label("ドットの形", "Dot shape")
            SegmentGrid(listOf(tx.t("まる", "Dots"), tx.t("しかく", "Squares")), if (s.shape == DotShape.DOT) 0 else 1) {
                onChange(s.copy(shape = if (it == 0) DotShape.DOT else DotShape.SQUARE))
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("ドットの色", "Dot colors")
            ColorRow(
                tx.t("過ぎた日", "Days passed"), s.passed ?: appStyle.passed,
                open == Slot.PASSED, { toggle(Slot.PASSED) }, { onChange(s.copy(passed = it)) },
                sampleState = Renderer.PASSED, isAuto = s.passed == null, onAuto = { onChange(s.copy(passed = null)) },
            )
            ColorRow(
                tx.t("今日", "Today"), s.today ?: appStyle.today,
                open == Slot.TODAY, { toggle(Slot.TODAY) }, { onChange(s.copy(today = it)) },
                sampleState = Renderer.TODAY, isAuto = s.today == null, onAuto = { onChange(s.copy(today = null)) },
            )
            ColorRow(
                tx.t("日曜・祝日", "Sundays & holidays"), s.holiday ?: appStyle.holiday,
                open == Slot.HOLIDAY, { toggle(Slot.HOLIDAY) }, { onChange(s.copy(holiday = it)) },
                sampleState = Renderer.HOLIDAY, isAuto = s.holiday == null, onAuto = { onChange(s.copy(holiday = null)) },
            )
            ColorRow(
                tx.t("これからの日", "Upcoming days"), s.future ?: appStyle.future,
                open == Slot.FUTURE, { toggle(Slot.FUTURE) }, { onChange(s.copy(future = it)) },
                sampleState = Renderer.FUTURE, isAuto = s.future == null, onAuto = { onChange(s.copy(future = null)) },
            )
            Text(
                tx.t(
                    "「今日」の色はアイコンをオフにしたときのドットに使われます。",
                    "The Today colour is used when the theme icon is turned off.",
                ),
                fontFamily = UiFont,
                fontWeight = bodyWeight(),
                fontSize = 12.sp,
                color = pal.sub,
                modifier = Modifier.padding(top = 6.dp),
            )
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("ウィジェット", "Widgets")
            val choices: List<AppTheme?> = listOf(null) + AppTheme.entries
            val choiceNames = choices.map { if (it == null) tx.t("アプリと同じ", "Same as app") else themeName(it) }
            Label("週ウィジェットのテーマ", "Week widget theme")
            SegmentGrid(choiceNames, choices.indexOf(s.weekTheme), columns = 3) {
                onChange(s.copy(weekTheme = choices[it]))
            }
            Spacer(Modifier.height(10.dp))
            Label("月ウィジェットのテーマ", "Month widget theme")
            SegmentGrid(choiceNames, choices.indexOf(s.monthTheme), columns = 3) {
                onChange(s.copy(monthTheme = choices[it]))
            }

            Spacer(Modifier.height(14.dp))
            Label("背景", "Background")
            val bgs = listOf(WidgetBg.CLEAR, WidgetBg.SOLID, WidgetBg.GLASS, WidgetBg.BLUR)
            SegmentGrid(
                listOf(tx.t("透明", "Clear"), tx.t("テーマ", "Theme"), tx.t("ガラス", "Glass"), tx.t("ぼかし", "Blur")),
                bgs.indexOf(s.widgetBg),
                columns = 2,
            ) { onChange(s.copy(widgetBg = bgs[it])) }
            Text(
                when (s.widgetBg) {
                    WidgetBg.SOLID -> tx.t("テーマの背景（和紙・夜空・鉄など）を表示します。", "Shows the theme's own backdrop (paper, night sky, iron…).")
                    WidgetBg.BLUR -> tx.t(
                        "※ Androidのウィジェットは壁紙を直接ぼかせないため、すりガラス風に描いています。",
                        "Android widgets can't blur the wallpaper itself, so this is drawn as frosted glass.",
                    )
                    else -> tx.t("壁紙の上に直接表示します。文字には影がつきます。", "Sits right on your wallpaper; text gets a soft shadow so it stays readable.")
                },
                fontFamily = UiFont,
                fontWeight = bodyWeight(),
                fontSize = 12.sp,
                color = pal.sub,
                modifier = Modifier.padding(top = 8.dp),
            )
            if (s.widgetBg == WidgetBg.GLASS || s.widgetBg == WidgetBg.BLUR) {
                Spacer(Modifier.height(8.dp))
                Label("濃さ", "Strength")
                Slider(
                    value = s.widgetOpacity,
                    onValueChange = { onChange(s.copy(widgetOpacity = it)) },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = pal.accent, activeTrackColor = pal.accent, inactiveTrackColor = pal.button),
                )
            }
            Spacer(Modifier.height(10.dp))
            ColorRow(
                tx.t("文字の色", "Text color"),
                RenderBridge.widgetTextColor(s),
                open == Slot.TEXT, { toggle(Slot.TEXT) }, { onChange(s.copy(widgetText = it)) },
                isAuto = s.widgetText == null,
                onAuto = { onChange(s.copy(widgetText = null)) },
            )
        }

        Spacer(Modifier.height(16.dp))
        FlatButton(
            tx.t("初期設定に戻す", "Reset to defaults"),
            { onChange(AppSettings(lang = s.lang)) },
            Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ThemeOption(s: AppSettings, t: AppTheme, selected: Boolean, name: String, onClick: () -> Unit) {
    val context = LocalContext.current
    val style = remember(t, s.lang, s.shape, s.numbers, s.todayIcon, s.kiFlame, s.steelSlash, s.boldText) {
        RenderBridge.style(context, s.withoutColorOverrides().copy(theme = t), Surface.APP)
    }
    ThemeCard(style, selected, name, onClick)
}

/** Live preview of both widgets over a sample wallpaper, so each background can be judged. */
@Composable
private fun WidgetPreview(s: AppSettings) {
    val context = LocalContext.current
    val today = remember { LocalDate.now() }
    val weekStyle = remember(s) { RenderBridge.style(context, s, Surface.WEEK) }
    val monthStyle = remember(s) { RenderBridge.style(context, s, Surface.MONTH) }
    val week = remember(s.lang, s.holidays, today) { RenderBridge.week(today, s.lang, s.holidays) }
    val month = remember(s.lang, s.holidays, today) { RenderBridge.month(YearMonth.from(today), today, s.lang, s.holidays) }
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val w = maxWidth.value
        val weekH = 88f
        val monthW = min(w - 24f, 290f)
        val totalH = 12f + weekH + 12f + monthW + 12f
        RenderCanvas(
            Modifier
                .fillMaxWidth()
                .height(totalH.dp)
                .clip(RoundedCornerShape(20.dp)),
        ) { c, cw, _ ->
            Renderer.drawBackdrop(c, cw, totalH)
            val save = c.save()
            c.translate(12f, 12f)
            Renderer.drawWeekWidget(c, cw - 24f, weekH, weekStyle, week)
            c.restoreToCount(save)
            val save2 = c.save()
            c.translate((cw - monthW) / 2f, 12f + weekH + 12f)
            Renderer.drawMonthWidget(c, monthW, monthW, monthStyle, month)
            c.restoreToCount(save2)
        }
    }
}
