package dev.dotcalendar.ui

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.dotcalendar.AppSettings
import dev.dotcalendar.Body
import dev.dotcalendar.DotShape
import dev.dotcalendar.Lang
import dev.dotcalendar.RenderBridge
import dev.dotcalendar.WidgetBg
import dev.dotcalendar.render.Renderer
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.min

private enum class Slot { PASSED, TODAY, HOLIDAY, FUTURE, TEXT }

@Composable
fun SettingsScreen(s: AppSettings, onChange: (AppSettings) -> Unit, onBack: () -> Unit) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val accent = Color(s.today)
    var open by remember { mutableStateOf<Slot?>(null) }
    fun toggle(slot: Slot) {
        open = if (open == slot) null else slot
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FlatIconButton(Icons.AutoMirrored.Filled.ArrowBack, tx.t("戻る", "Back"), onBack)
            Spacer(Modifier.width(14.dp))
            BrushTitle(tx.t("設定", "SETTINGS"), if (tx.ja) 26.sp else 22.sp)
        }

        Spacer(Modifier.height(20.dp))
        WidgetPreview(s)

        Spacer(Modifier.height(16.dp))
        Panel {
            SectionTitle("言語", "Language")
            SegmentGrid(listOf("日本語", "English"), if (s.lang == Lang.JA) 0 else 1) {
                onChange(s.copy(lang = if (it == 0) Lang.JA else Lang.EN))
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("スタイル", "Style")
            Label("テーマ", "Theme")
            SegmentGrid(listOf(tx.t("墨（ダーク）", "Dark"), tx.t("和紙（ライト）", "Paper")), if (s.body == Body.DARK) 0 else 1) {
                onChange(s.copy(body = if (it == 0) Body.DARK else Body.PAPER))
            }
            Spacer(Modifier.height(10.dp))
            Label("ドットの形", "Dot shape")
            SegmentGrid(listOf(tx.t("まる", "Dots"), tx.t("しかく", "Squares")), if (s.shape == DotShape.DOT) 0 else 1) {
                onChange(s.copy(shape = if (it == 0) DotShape.DOT else DotShape.SQUARE))
            }
            Spacer(Modifier.height(8.dp))
            ToggleRow(tx.t("ドットに日付を表示", "Show dates on the dots"), s.numbers) { onChange(s.copy(numbers = it)) }
            ToggleRow(tx.t("今日をひまわりで表示", "Show today as a sunflower"), s.sunflower) { onChange(s.copy(sunflower = it)) }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("ドットの色", "Dot colors")
            ColorRow(
                tx.t("過ぎた日", "Days passed"),
                s.passed ?: RenderBridge.autoPassed(s, widget = false),
                open == Slot.PASSED, { toggle(Slot.PASSED) }, { onChange(s.copy(passed = it)) },
                sampleState = Renderer.PASSED,
                isAuto = s.passed == null,
                onAuto = { onChange(s.copy(passed = null)) },
            )
            ColorRow(
                tx.t("今日", "Today"), s.today,
                open == Slot.TODAY, { toggle(Slot.TODAY) }, { onChange(s.copy(today = it)) },
                sampleState = Renderer.TODAY,
            )
            ColorRow(
                tx.t("日曜・祝日", "Sundays & holidays"), s.holiday,
                open == Slot.HOLIDAY, { toggle(Slot.HOLIDAY) }, { onChange(s.copy(holiday = it)) },
                sampleState = Renderer.HOLIDAY,
            )
            ColorRow(
                tx.t("これからの日", "Upcoming days"),
                s.future ?: RenderBridge.autoFuture(s, widget = false),
                open == Slot.FUTURE, { toggle(Slot.FUTURE) }, { onChange(s.copy(future = it)) },
                sampleState = Renderer.FUTURE,
                isAuto = s.future == null,
                onAuto = { onChange(s.copy(future = null)) },
            )
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("ウィジェット", "Widgets")
            Label("背景", "Background")
            val bgs = listOf(WidgetBg.CLEAR, WidgetBg.SOLID, WidgetBg.GLASS, WidgetBg.BLUR)
            SegmentGrid(
                listOf(tx.t("透明", "Clear"), tx.t("ソリッド", "Solid"), tx.t("ガラス", "Glass"), tx.t("ぼかし", "Blur")),
                bgs.indexOf(s.widgetBg),
                columns = 2,
            ) { onChange(s.copy(widgetBg = bgs[it])) }
            if (s.widgetBg == WidgetBg.BLUR) {
                Text(
                    tx.t(
                        "※ Androidのウィジェットは壁紙を直接ぼかせないため、すりガラス風に描いています。",
                        "Android widgets can't blur the wallpaper itself, so this is drawn as frosted glass.",
                    ),
                    fontFamily = UiFont,
                    fontSize = 12.sp,
                    color = pal.sub,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
            if (s.widgetBg == WidgetBg.GLASS || s.widgetBg == WidgetBg.BLUR) {
                Spacer(Modifier.height(8.dp))
                Label("濃さ", "Strength")
                Slider(
                    value = s.widgetOpacity,
                    onValueChange = { onChange(s.copy(widgetOpacity = it)) },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = pal.button),
                )
            }
            Spacer(Modifier.height(10.dp))
            ColorRow(
                tx.t("文字の色", "Text color"),
                RenderBridge.widgetTextColor(s),
                open == Slot.TEXT, { toggle(Slot.TEXT) }, { onChange(s.copy(widgetText = it)) },
                isAuto = s.widgetText == null,
                onAuto = { onChange(s.copy(widgetText = null)) },
            )
            Text(
                tx.t(
                    "背景が「ソリッド」以外のときは、壁紙の上に直接描かれます。",
                    "With Clear, Glass and Blur the widget sits on your wallpaper, so pick a text color that reads on it.",
                ),
                fontFamily = UiFont,
                fontSize = 12.sp,
                color = pal.sub,
                modifier = Modifier.padding(top = 6.dp),
            )
        }

        Spacer(Modifier.height(16.dp))
        FlatButton(
            tx.t("初期設定に戻す", "Reset to defaults"),
            { onChange(AppSettings(lang = s.lang)) },
            Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(24.dp))
    }
}

/** Live preview of both widgets over a sample wallpaper, so Clear / Glass / Blur can be judged. */
@Composable
private fun WidgetPreview(s: AppSettings) {
    val context = LocalContext.current
    val today = remember { LocalDate.now() }
    val style = remember(s) { RenderBridge.style(context, s, widget = true) }
    val week = remember(s.lang, today) { RenderBridge.week(today, s.lang) }
    val month = remember(s.lang, today) { RenderBridge.month(YearMonth.from(today), today, s.lang) }
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val w = maxWidth.value
        val weekH = 84f
        val monthW = min(w - 24f, 280f)
        val totalH = 12f + weekH + 12f + monthW + 12f
        RenderCanvas(
            Modifier
                .fillMaxWidth()
                .height(totalH.dp)
                .clip(RoundedCornerShape(20.dp)),
        ) { c, cw, ch ->
            Renderer.drawBackdrop(c, cw, ch)
            val save = c.save()
            c.translate(12f, 12f)
            Renderer.drawWeekWidget(c, cw - 24f, weekH, style, week)
            c.restoreToCount(save)
            val save2 = c.save()
            c.translate((cw - monthW) / 2f, 12f + weekH + 12f)
            Renderer.drawMonthWidget(c, monthW, monthW, style, month)
            c.restoreToCount(save2)
        }
    }
}
