package dev.dotcalendar.ui

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.dotcalendar.AppSettings
import dev.dotcalendar.AppTheme
import dev.dotcalendar.DotShape
import dev.dotcalendar.HolidayRegion
import dev.dotcalendar.JaDateStyle
import dev.dotcalendar.Lang
import dev.dotcalendar.PhoneCalendar
import dev.dotcalendar.R
import dev.dotcalendar.RenderBridge
import dev.dotcalendar.SpiritOrb
import dev.dotcalendar.Surface
import dev.dotcalendar.WeekdayFont
import dev.dotcalendar.WeekdaySize
import dev.dotcalendar.WidgetBg
import dev.dotcalendar.WidgetTextSize
import dev.dotcalendar.render.Renderer
import dev.dotcalendar.render.ThemeSpecs
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.min

/** The Settings home and its sub-menus. */
private enum class Page { HOME, THEME, WIDGETS, WEEKDAYS, DOTS, LANGUAGE, EXTRAS }

/** Which colour row is open (only one at a time). */
private enum class Slot { PASSED, TODAY, HOLIDAY, FUTURE, TEXT, WD_TODAY, WD_SUNDAY, WD_SATURDAY, WD_OTHER }

/**
 * Settings: a short menu with a live widget preview, each entry opening its own page.
 * Everything here reads in both Japanese and English, the app's language first.
 */
@Composable
fun SettingsScreen(s: AppSettings, onChange: (AppSettings) -> Unit, onBack: () -> Unit) {
    var page by rememberSaveable { mutableStateOf(Page.HOME) }
    BackHandler(enabled = page != Page.HOME) { page = Page.HOME }
    val home = { page = Page.HOME }
    when (page) {
        Page.HOME -> SettingsHome(s, onChange, onBack) { page = it }
        Page.THEME -> ThemePage(s, onChange, home)
        Page.WIDGETS -> WidgetsPage(s, onChange, home)
        Page.WEEKDAYS -> WeekdaysPage(s, onChange, home)
        Page.DOTS -> DotsPage(s, onChange, home)
        Page.LANGUAGE -> LanguagePage(s, onChange, home)
        Page.EXTRAS -> ExtrasPage(s, onChange, home)
    }
}

// ---------------------------------------------------------------- names in both languages

/** "日本語 English" in the app's language order, for one-line summaries. */
@Composable
private fun both(ja: String, en: String): String {
    val (first, second) = biPair(ja, en)
    return if (second.isEmpty() || second == first) first else "$first $second"
}

private fun themePair(t: AppTheme): Pair<String, String> = ThemeSpecs.nameJa(t.id) to ThemeSpecs.nameEn(t.id)

private fun bgPair(bg: WidgetBg): Pair<String, String> = when (bg) {
    WidgetBg.CLEAR -> "透明" to "Transparent"
    WidgetBg.BLUR -> "ぼかし" to "Blur"
    WidgetBg.GLASS -> "ガラス" to "Glass"
    WidgetBg.SOLID -> "不透明" to "Solid"
}

private val TEXT_SIZES = listOf(WidgetTextSize.SMALL, WidgetTextSize.MEDIUM, WidgetTextSize.LARGE)
private val TEXT_SIZE_NAMES = listOf("小さめ" to "Small", "ふつう" to "Medium", "大きめ" to "Large")

private val WEEKDAY_SIZES = listOf(WeekdaySize.XSMALL, WeekdaySize.SMALL, WeekdaySize.MEDIUM, WeekdaySize.LARGE)
private val WEEKDAY_SIZE_NAMES = listOf("極小" to "Extra small", "小さめ" to "Small", "ふつう" to "Medium", "大きめ" to "Large")

private val WEEKDAY_FONT_NAMES = mapOf(
    WeekdayFont.STANDARD to ("標準" to "Standard"),
    WeekdayFont.THEME to ("テーマ" to "Theme"),
    WeekdayFont.MANGA to ("マンガ" to "Manga"),
    WeekdayFont.RACING to ("レース" to "Racing"),
)

private val ORB_NAMES = mapOf(
    SpiritOrb.ICE to ("氷" to "Ice"),
    SpiritOrb.JADE to ("翡翠" to "Jade"),
    SpiritOrb.SAPPHIRE to ("瑠璃" to "Sapphire"),
    SpiritOrb.AMETHYST to ("紫水晶" to "Amethyst"),
    SpiritOrb.GOLD to ("金" to "Gold"),
    SpiritOrb.SAKURA to ("桜" to "Sakura"),
)

private val DATE_STYLES = listOf(JaDateStyle.STANDARD, JaDateStyle.ERA, JaDateStyle.MONTH_DAY)
private val DATE_STYLE_NAMES = listOf("10.14（令和八年）" to "Standard", "令和8年10月14日" to "Era date", "10月14日" to "Month and day")

// ---------------------------------------------------------------- page frame and menu

/** One settings page: back button, title in both languages, then the content. */
@Composable
private fun SettingsPage(ja: String, en: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val (first, second) = biPair(ja, en)
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FlatIconButton(Icons.AutoMirrored.Filled.ArrowBack, "戻る Back", onBack)
            Spacer(Modifier.width(14.dp))
            Column {
                ThemeTitle(first, if (tx.ja) 25.sp else 22.sp)
                Text(second, fontFamily = UiFont, fontWeight = FontWeight.Medium, fontSize = 13.sp, color = pal.sub)
            }
        }
        Spacer(Modifier.height(18.dp))
        content()
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun SettingsHome(s: AppSettings, onChange: (AppSettings) -> Unit, onBack: () -> Unit, open: (Page) -> Unit) {
    val (tj, te) = themePair(s.theme)
    val (bj, be) = bgPair(s.widgetBg)
    val (sj, se) = TEXT_SIZE_NAMES[TEXT_SIZES.indexOf(s.widgetTextSize)]
    val (fj, fe) = WEEKDAY_FONT_NAMES.getValue(s.weekdayFont)
    val (wj, we) = WEEKDAY_SIZE_NAMES[WEEKDAY_SIZES.indexOf(s.weekdaySize)]
    val (dj, de) = DATE_STYLE_NAMES[DATE_STYLES.indexOf(s.jaDateStyle)]
    val (oj, oe) = ORB_NAMES.getValue(s.spiritOrb)

    val orbName = both(oj, oe)
    val themeSummary = "$tj $te" + if (s.theme == AppTheme.REI) " · $orbName" else ""
    val widgetSummary = both(bj, be) + " · " + both(sj, se)
    val weekdaySummary = both(fj, fe) + " · " + both(wj, we)
    val shapeName = if (s.shape == DotShape.DOT) both("まる", "Dots") else both("しかく", "Squares")
    val withDates = both("日付つき", "With dates")
    val dotSummary = shapeName + if (s.numbers) " · $withDates" else ""
    val langSummary = (if (s.lang == Lang.JA) "日本語" else "English") + " · " + both(dj, de)
    val countdownName = both("カウントダウン", "Countdown")
    val eventsName = both("予定", "Events")
    val offName = both("オフ", "Off")
    val extras = listOfNotNull(
        "六曜".takeIf { s.showRokuyo },
        "節気".takeIf { s.showSekki },
        countdownName.takeIf { s.showCountdown },
        eventsName.takeIf { s.phoneEvents },
    )
    val extrasSummary = if (extras.isEmpty()) offName else extras.joinToString(" · ")

    SettingsPage("設定", "Settings", onBack) {
        WidgetPreview(s)
        Spacer(Modifier.height(14.dp))
        Panel {
            MenuRow("彩", "テーマ", "Theme", themeSummary) { open(Page.THEME) }
            MenuDivider()
            MenuRow("窓", "ウィジェット", "Widgets", widgetSummary) { open(Page.WIDGETS) }
            MenuDivider()
            MenuRow("曜", "曜日", "Weekdays", weekdaySummary) { open(Page.WEEKDAYS) }
            MenuDivider()
            MenuRow("点", "ドット", "Dots", dotSummary) { open(Page.DOTS) }
            MenuDivider()
            MenuRow("語", "言語と日付", "Language & dates", langSummary) { open(Page.LANGUAGE) }
            MenuDivider()
            MenuRow("暦", "暦と予定", "Calendar extras", extrasSummary) { open(Page.EXTRAS) }
        }
        Spacer(Modifier.height(16.dp))
        BiButton(
            "初期設定に戻す",
            "Reset to defaults",
            // keeps the language and the user's own dates
            { onChange(AppSettings(lang = s.lang, myDates = s.myDates)) },
            Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(6.dp))
        Note(
            "テーマ・色・ウィジェットの設定を元に戻します。マイ記念日は消えません。",
            "Puts themes, colours and widget settings back. Your own dates are kept.",
            Modifier.padding(horizontal = 4.dp),
        )
    }
}

/** A menu entry: a kanji badge, the name in both languages, what it's set to now, and a chevron. */
@Composable
private fun MenuRow(glyph: String, ja: String, en: String, summary: String, onClick: () -> Unit) {
    val pal = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(pal.accent.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(glyph, fontFamily = UiFont, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = pal.text)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            BiText(ja, en, size = 16.sp)
            if (summary.isNotEmpty()) {
                Text(
                    summary,
                    fontFamily = UiFont,
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp,
                    color = pal.sub.copy(alpha = 0.85f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 3.dp),
                )
            }
        }
        Text("›", fontSize = 26.sp, color = pal.sub, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
private fun MenuDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = 56.dp)
            .height(1.dp)
            .background(LocalPalette.current.sub.copy(alpha = 0.15f)),
    )
}

// ---------------------------------------------------------------- テーマ Theme

@Composable
private fun ThemePage(s: AppSettings, onChange: (AppSettings) -> Unit, onBack: () -> Unit) {
    SettingsPage("テーマ", "Theme", onBack) {
        Panel {
            SectionTitle("アプリのテーマ", "App theme")
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AppTheme.entries.forEach { t ->
                    val (ja, en) = themePair(t)
                    ThemeOption(s, t, s.theme == t, "$ja $en") {
                        // A new theme brings its own colours, so custom dot colours are cleared.
                        onChange(s.withoutColorOverrides().copy(theme = t))
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("今日のアイコン", "Today icon")
            ToggleRow("今日をテーマのアイコンで表示（🌻 など）", "Theme icon for today (🌻 etc.)", s.todayIcon) {
                onChange(s.copy(todayIcon = it))
            }
            if (s.todayIcon) {
                Spacer(Modifier.height(8.dp))
                Label("霊 — 光の色", "Spirit — orb colour")
                IconChoices(
                    AppTheme.REI,
                    SpiritOrb.entries.map { o -> Triple(ORB_NAMES.getValue(o).first, ORB_NAMES.getValue(o).second, s.copy(spiritOrb = o)) },
                    SpiritOrb.entries.indexOf(s.spiritOrb),
                    columns = 3,
                    onPick = onChange,
                )
                Spacer(Modifier.height(12.dp))
                Label("気", "Ki")
                IconChoices(
                    AppTheme.KI,
                    listOf(Triple("気功波", "Energy wave", s.copy(kiWave = true)), Triple("爆発", "Burst", s.copy(kiWave = false))),
                    if (s.kiWave) 0 else 1,
                    onPick = onChange,
                )
                Spacer(Modifier.height(12.dp))
                Label("鋼", "Steel")
                IconChoices(
                    AppTheme.HAGANE,
                    listOf(Triple("斬撃", "Slash", s.copy(steelSlash = true)), Triple("飛沫", "Splash", s.copy(steelSlash = false))),
                    if (s.steelSlash) 0 else 1,
                    onPick = onChange,
                )
                Spacer(Modifier.height(12.dp))
                Label("侍", "Samurai")
                IconChoices(
                    AppTheme.SAMURAI,
                    listOf(Triple("兜", "Helmet", s.copy(samuraiKabuto = true)), Triple("刀", "Katanas", s.copy(samuraiKabuto = false))),
                    if (s.samuraiKabuto) 0 else 1,
                    onPick = onChange,
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("ウィジェットごとのテーマ", "Per widget")
            val choices: List<AppTheme?> = listOf(null) + AppTheme.entries
            val names = choices.map { if (it == null) "アプリと同じ" to "Same as app" else themePair(it) }
            Label("週ウィジェット", "Week widget")
            BiSegment(names, choices.indexOf(s.weekTheme), columns = 3) { onChange(s.copy(weekTheme = choices[it])) }
            Spacer(Modifier.height(12.dp))
            Label("月ウィジェット", "Month widget")
            BiSegment(names, choices.indexOf(s.monthTheme), columns = 3) { onChange(s.copy(monthTheme = choices[it])) }
            Spacer(Modifier.height(12.dp))
            Label("年ウィジェット", "Year widget")
            BiSegment(names, choices.indexOf(s.yearTheme), columns = 3) { onChange(s.copy(yearTheme = choices[it])) }
        }
    }
}

/**
 * Picture tiles for one theme's today-icon choices. Each option carries the settings it would
 * apply, and its tile shows that theme's surface with the icon drawn exactly as it will look.
 */
@Composable
private fun IconChoices(
    theme: AppTheme,
    options: List<Triple<String, String, AppSettings>>,
    selected: Int,
    columns: Int = options.size,
    onPick: (AppSettings) -> Unit,
) {
    val context = LocalContext.current
    val pal = LocalPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        options.chunked(columns).forEachIndexed { r, row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEachIndexed { c, (ja, en, result) ->
                    val index = r * columns + c
                    val isSelected = index == selected
                    val style = remember(result, theme) {
                        RenderBridge.style(context, result.withoutColorOverrides().copy(theme = theme, todayIcon = true), Surface.APP)
                    }
                    val shape = RoundedCornerShape(14.dp)
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(shape)
                            .border(if (isSelected) 2.5.dp else 1.dp, if (isSelected) pal.accent else pal.button, shape)
                            .clickable { onPick(result) },
                    ) {
                        RenderCanvas(Modifier.fillMaxWidth().height(62.dp)) { cv, w, h ->
                            Renderer.drawTodaySample(cv, w, h, style)
                        }
                        TileLabel(ja, en, isSelected)
                    }
                }
                repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

/** Centred two-line caption under a picture tile. */
@Composable
private fun TileLabel(ja: String, en: String, selected: Boolean) {
    val pal = LocalPalette.current
    val (first, second) = biPair(ja, en)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            first,
            fontFamily = UiFont,
            fontWeight = if (selected) FontWeight.Bold else bodyWeight(),
            fontSize = 13.sp,
            color = if (selected) pal.text else pal.sub,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (second.isNotEmpty() && second != first) {
            Text(
                second,
                fontFamily = UiFont,
                fontWeight = FontWeight.Medium,
                fontSize = 10.5.sp,
                color = pal.sub.copy(alpha = 0.8f),
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun ThemeOption(s: AppSettings, t: AppTheme, selected: Boolean, name: String, onClick: () -> Unit) {
    val context = LocalContext.current
    val style = remember(t, s.lang, s.shape, s.numbers, s.todayIcon, s.kiWave, s.steelSlash, s.samuraiKabuto, s.spiritOrb, s.boldText) {
        RenderBridge.style(context, s.withoutColorOverrides().copy(theme = t), Surface.APP)
    }
    ThemeCard(style, selected, name, onClick)
}

// ---------------------------------------------------------------- ウィジェット Widgets

@Composable
private fun WidgetsPage(s: AppSettings, onChange: (AppSettings) -> Unit, onBack: () -> Unit) {
    val pal = LocalPalette.current
    var open by remember { mutableStateOf<Slot?>(null) }
    SettingsPage("ウィジェット", "Widgets", onBack) {
        WidgetPreview(s)

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("背景", "Background")
            BackgroundPicker(s, onChange)
            val (nj, ne) = when (s.widgetBg) {
                WidgetBg.SOLID -> "テーマの背景（和紙・夜空・鉄など）で塗りつぶします。" to "Filled with the theme's own backdrop (paper, night sky, iron…)."
                WidgetBg.GLASS -> "透けるガラス。下の「濃さ」で調整できます。" to "See-through glass. Adjust it with Strength below."
                WidgetBg.BLUR -> "Androidのウィジェットは壁紙を直接ぼかせないため、すりガラス風に描いています。" to
                    "Android widgets can't blur the wallpaper itself, so Blur is drawn as frosted glass."
                WidgetBg.CLEAR -> "壁紙の上に直接表示します。文字には影がつきます。" to "Sits right on your wallpaper; text gets a soft shadow so it stays readable."
            }
            Note(nj, ne, Modifier.padding(top = 8.dp))
            if (s.widgetBg == WidgetBg.GLASS || s.widgetBg == WidgetBg.BLUR) {
                Spacer(Modifier.height(8.dp))
                Label("濃さ", "Strength")
                Slider(
                    value = s.widgetOpacity,
                    onValueChange = { onChange(s.copy(widgetOpacity = it)) },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = pal.accent, activeTrackColor = pal.accent, inactiveTrackColor = pal.button),
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("文字", "Text")
            Label("大きさ", "Size")
            BiSegment(TEXT_SIZE_NAMES, TEXT_SIZES.indexOf(s.widgetTextSize)) { onChange(s.copy(widgetTextSize = TEXT_SIZES[it])) }
            Spacer(Modifier.height(10.dp))
            ColorRow(
                "文字の色", "Text colour",
                RenderBridge.widgetTextColor(s),
                open == Slot.TEXT, { open = if (open == Slot.TEXT) null else Slot.TEXT }, { onChange(s.copy(widgetText = it)) },
                isAuto = s.widgetText == null,
                onAuto = { onChange(s.copy(widgetText = null)) },
            )
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("レイアウト", "Layout")
            Label("週ウィジェット", "Week widget")
            BiSegment(listOf("日付＋週" to "Date + week", "週だけ" to "Week only"), if (s.weekOnly) 1 else 0) {
                onChange(s.copy(weekOnly = it == 1))
            }
            Spacer(Modifier.height(6.dp))
            ToggleRow("言語ボタン（日 / EN）を表示", "Show language button (日 / EN)", s.showLangChip) {
                onChange(s.copy(showLangChip = it))
            }
            if (s.weekOnly && s.showLangChip) {
                Note(
                    "「週だけ」の週ウィジェットにはボタンが出ません。言語はこのアプリの上部で切り替えられます。",
                    "The week-only widget has no button. You can switch language at the top of this app.",
                    Modifier.padding(bottom = 6.dp),
                )
            } else if (!s.showLangChip) {
                Note(
                    "言語はこのアプリの上部で切り替えられます。",
                    "You can still switch language at the top of this app.",
                    Modifier.padding(bottom = 6.dp),
                )
            }
            Spacer(Modifier.height(6.dp))
            Note(
                "週・月・年のウィジェットは、ホーム画面のウィジェット一覧から追加できます。",
                "Add the week, month and year widgets from your home screen's widget list.",
            )
        }
    }
}

/** Transparent / Blur / Glass / Solid, each shown as a little widget on a scrap of wallpaper. */
@Composable
private fun BackgroundPicker(s: AppSettings, onChange: (AppSettings) -> Unit) {
    val pal = LocalPalette.current
    val context = LocalContext.current
    val options = listOf(WidgetBg.CLEAR, WidgetBg.BLUR, WidgetBg.GLASS, WidgetBg.SOLID)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        options.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { bg ->
                    val selected = s.widgetBg == bg
                    val style = remember(s, bg) { RenderBridge.style(context, s.copy(widgetBg = bg), Surface.WEEK) }
                    val shape = RoundedCornerShape(14.dp)
                    val (ja, en) = bgPair(bg)
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(shape)
                            .border(if (selected) 2.5.dp else 1.dp, if (selected) pal.accent else pal.button, shape)
                            .clickable { onChange(s.copy(widgetBg = bg)) },
                    ) {
                        RenderCanvas(Modifier.fillMaxWidth().height(64.dp)) { c, w, h ->
                            Renderer.drawBackgroundSample(c, w, h, style)
                        }
                        TileLabel(ja, en, selected)
                    }
                }
            }
        }
    }
}

/** Live preview of both widgets over a sample wallpaper, so each background can be judged. */
@Composable
private fun WidgetPreview(s: AppSettings) {
    val context = LocalContext.current
    val today = remember { LocalDate.now() }
    val weekStyle = remember(s) { RenderBridge.style(context, s, Surface.WEEK) }
    val monthStyle = remember(s) { RenderBridge.style(context, s, Surface.MONTH) }
    val week = remember(s, today) { RenderBridge.week(today, s) }
    val month = remember(s, today) { RenderBridge.month(YearMonth.from(today), today, s) }
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val w = maxWidth.value
        val weekH = 88f
        val monthW = min(w - 24f, 290f)
        val totalH = 12f + weekH + 12f + monthW + 12f
        RenderCanvas(
            Modifier
                .fillMaxWidth()
                .height(totalH.dp)
                .clip(RoundedCornerShape(20.dp)),
        ) { c, cw, _ ->
            Renderer.drawBackdrop(c, cw, totalH)
            val save = c.save()
            c.translate(12f, 12f)
            Renderer.drawWeekWidget(c, cw - 24f, weekH, weekStyle, week)
            c.restoreToCount(save)
            val save2 = c.save()
            c.translate((cw - monthW) / 2f, 12f + weekH + 12f)
            Renderer.drawMonthWidget(c, monthW, monthW, monthStyle, month)
            c.restoreToCount(save2)
        }
    }
}

// ---------------------------------------------------------------- 曜日 Weekdays

@Composable
private fun WeekdaysPage(s: AppSettings, onChange: (AppSettings) -> Unit, onBack: () -> Unit) {
    var open by remember { mutableStateOf<Slot?>(null) }
    fun toggle(slot: Slot) {
        open = if (open == slot) null else slot
    }
    val weekStyle = remember(s) { RenderBridge.colors(s, Surface.WEEK) }
    SettingsPage("曜日", "Weekdays", onBack) {
        WeekdaySample(s)

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("大きさとフォント", "Size & font")
            Label("大きさ", "Size")
            BiSegment(WEEKDAY_SIZE_NAMES, WEEKDAY_SIZES.indexOf(s.weekdaySize), columns = 2) {
                onChange(s.copy(weekdaySize = WEEKDAY_SIZES[it]))
            }
            Spacer(Modifier.height(12.dp))
            Label("フォント", "Font")
            WeekdayFontPicker(s, onChange)
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("色", "Colours")
            Note("テーマを変えても、ここで選んだ色はそのままです。", "These stay the same when you change theme.", Modifier.padding(bottom = 6.dp))
            ColorRow(
                "今日", "Today", s.wdToday ?: weekStyle.todayLabel,
                open == Slot.WD_TODAY, { toggle(Slot.WD_TODAY) }, { onChange(s.copy(wdToday = it)) },
                isAuto = s.wdToday == null, onAuto = { onChange(s.copy(wdToday = null)) },
            )
            ColorRow(
                "日曜・祝日", "Sundays & holidays", s.wdSunday ?: weekStyle.holiday,
                open == Slot.WD_SUNDAY, { toggle(Slot.WD_SUNDAY) }, { onChange(s.copy(wdSunday = it)) },
                isAuto = s.wdSunday == null, onAuto = { onChange(s.copy(wdSunday = null)) },
            )
            ColorRow(
                "土曜", "Saturdays", s.wdSaturday ?: (s.wdOther ?: weekStyle.sub),
                open == Slot.WD_SATURDAY, { toggle(Slot.WD_SATURDAY) }, { onChange(s.copy(wdSaturday = it)) },
                isAuto = s.wdSaturday == null, onAuto = { onChange(s.copy(wdSaturday = null)) },
            )
            ColorRow(
                "ほかの曜日", "Other days", s.wdOther ?: weekStyle.sub,
                open == Slot.WD_OTHER, { toggle(Slot.WD_OTHER) }, { onChange(s.copy(wdOther = it)) },
                isAuto = s.wdOther == null, onAuto = { onChange(s.copy(wdOther = null)) },
            )
        }
    }
}

/** Live sample of the weekday row with the chosen size, font and colours. */
@Composable
private fun WeekdaySample(s: AppSettings) {
    val context = LocalContext.current
    val tx = LocalTx.current
    val style = remember(s) { RenderBridge.style(context, s, Surface.WEEK) }
    val today = remember { LocalDate.now().dayOfWeek.value % 7 }
    val labels = remember(tx.lang) { tx.weekdayInitials.toTypedArray() }
    val red = remember { BooleanArray(7) { it == 0 } }
    RenderCanvas(
        Modifier
            .fillMaxWidth()
            .height(76.dp)
            .clip(RoundedCornerShape(16.dp)),
    ) { c, w, h ->
        Renderer.drawWeekdaySample(c, w, h, style, labels, tx.ja, today, red)
    }
}

/** Standard / Theme / Manga / Racing, each button written in its own font. */
@Composable
private fun WeekdayFontPicker(s: AppSettings, onChange: (AppSettings) -> Unit) {
    val tx = LocalTx.current
    val manga = remember(tx.ja) { FontFamily(Font(if (tx.ja) R.font.wd_manga_ja else R.font.bangers)) }
    val racing = remember(tx.ja) { FontFamily(Font(if (tx.ja) R.font.wd_racing_ja else R.font.wd_racing_en)) }
    val families = mapOf(
        WeekdayFont.STANDARD to UiFont,
        WeekdayFont.THEME to titleFont(tx.ja),
        WeekdayFont.MANGA to manga,
        WeekdayFont.RACING to racing,
    )
    val sample = if (tx.ja) "月火水" else "MON TUE"
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        WeekdayFont.entries.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { font ->
                    val (ja, en) = WEEKDAY_FONT_NAMES.getValue(font)
                    // first line: the sample weekdays in that font; second line: its name in both languages
                    BiButton(
                        sample,
                        "$ja · $en",
                        { onChange(s.copy(weekdayFont = font)) },
                        Modifier.weight(1f),
                        selected = s.weekdayFont == font,
                        fontFamily = families.getValue(font),
                        fixedOrder = true,
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- ドット Dots

@Composable
private fun DotsPage(s: AppSettings, onChange: (AppSettings) -> Unit, onBack: () -> Unit) {
    val appStyle = LocalAppStyle.current
    var open by remember { mutableStateOf<Slot?>(null) }
    fun toggle(slot: Slot) {
        open = if (open == slot) null else slot
    }
    SettingsPage("ドット", "Dots", onBack) {
        Panel {
            SectionTitle("形と日付", "Shape & dates")
            Label("ドットの形", "Dot shape")
            BiSegment(listOf("まる" to "Dots", "しかく" to "Squares"), if (s.shape == DotShape.DOT) 0 else 1) {
                onChange(s.copy(shape = if (it == 0) DotShape.DOT else DotShape.SQUARE))
            }
            Spacer(Modifier.height(6.dp))
            ToggleRow("ドットに日付を表示", "Show dates on the dots", s.numbers) { onChange(s.copy(numbers = it)) }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("ドットの色", "Dot colours")
            ColorRow(
                "過ぎた日", "Days passed", s.passed ?: appStyle.passed,
                open == Slot.PASSED, { toggle(Slot.PASSED) }, { onChange(s.copy(passed = it)) },
                sampleState = Renderer.PASSED, isAuto = s.passed == null, onAuto = { onChange(s.copy(passed = null)) },
            )
            ColorRow(
                "今日", "Today", s.today ?: appStyle.today,
                open == Slot.TODAY, { toggle(Slot.TODAY) }, { onChange(s.copy(today = it)) },
                sampleState = Renderer.TODAY, isAuto = s.today == null, onAuto = { onChange(s.copy(today = null)) },
            )
            ColorRow(
                "日曜・祝日", "Sundays & holidays", s.holiday ?: appStyle.holiday,
                open == Slot.HOLIDAY, { toggle(Slot.HOLIDAY) }, { onChange(s.copy(holiday = it)) },
                sampleState = Renderer.HOLIDAY, isAuto = s.holiday == null, onAuto = { onChange(s.copy(holiday = null)) },
            )
            ColorRow(
                "これからの日", "Upcoming days", s.future ?: appStyle.future,
                open == Slot.FUTURE, { toggle(Slot.FUTURE) }, { onChange(s.copy(future = it)) },
                sampleState = Renderer.FUTURE, isAuto = s.future == null, onAuto = { onChange(s.copy(future = null)) },
            )
            Note(
                "「今日」の色は、テーマのアイコンをオフにしたときのドットに使われます。テーマを変えると色は元に戻ります。",
                "The Today colour is used when the theme icon is off. Changing theme resets these colours.",
                Modifier.padding(top = 6.dp),
            )
        }
    }
}

// ---------------------------------------------------------------- 言語と日付 Language & dates

@Composable
private fun LanguagePage(s: AppSettings, onChange: (AppSettings) -> Unit, onBack: () -> Unit) {
    SettingsPage("言語と日付", "Language & dates", onBack) {
        Panel {
            SectionTitle("言語", "Language")
            BiSegment(listOf("日本語" to "Japanese", "英語" to "English"), if (s.lang == Lang.JA) 0 else 1) {
                onChange(s.copy(lang = if (it == 0) Lang.JA else Lang.EN))
            }
            Note(
                "カレンダーとウィジェットの言語です。設定画面はいつも日本語と英語の両方で表示されます。",
                "The language for the calendar and widgets. Settings always show both languages.",
                Modifier.padding(top = 8.dp),
            )
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("日本語の日付", "Japanese date style")
            BiSegment(DATE_STYLE_NAMES, DATE_STYLES.indexOf(s.jaDateStyle), columns = 1) {
                onChange(s.copy(jaDateStyle = DATE_STYLES[it]))
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("祝日", "Holidays")
            val regions = listOf(HolidayRegion.JP, HolidayRegion.US, HolidayRegion.BOTH)
            BiSegment(listOf("日本" to "Japan", "アメリカ" to "US", "両方" to "Both"), regions.indexOf(s.holidays)) {
                onChange(s.copy(holidays = regions[it]))
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("読みやすさ", "Readability")
            ToggleRow("太字テキスト", "Bold text", s.boldText) { onChange(s.copy(boldText = it)) }
        }
    }
}

// ---------------------------------------------------------------- 暦と予定 Calendar extras

/** 六曜, 二十四節気, phone-calendar marks and the countdown. */
@Composable
private fun ExtrasPage(s: AppSettings, onChange: (AppSettings) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        onChange(s.copy(phoneEvents = granted))
    }
    SettingsPage("暦と予定", "Calendar extras", onBack) {
        Panel {
            SectionTitle("暦", "Japanese calendar")
            ToggleRow("六曜を表示（大安・仏滅など）", "Show rokuyō (Taian, Butsumetsu…)", s.showRokuyo) {
                onChange(s.copy(showRokuyo = it))
            }
            ToggleRow("二十四節気を表示（寒露など）", "Show the 24 seasonal terms (Cold Dew…)", s.showSekki) {
                onChange(s.copy(showSekki = it))
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("予定", "Plans")
            ToggleRow("マイ記念日のカウントダウン", "Countdown to my dates", s.showCountdown) {
                onChange(s.copy(showCountdown = it))
            }
            ToggleRow(
                "スマホのカレンダーの予定に印をつける",
                "Mark days with phone calendar events",
                s.phoneEvents && PhoneCalendar.hasPermission(context),
            ) { on ->
                when {
                    !on -> onChange(s.copy(phoneEvents = false))
                    PhoneCalendar.hasPermission(context) -> onChange(s.copy(phoneEvents = true))
                    else -> permission.launch(Manifest.permission.READ_CALENDAR)
                }
            }
            Note(
                "予定のある日はドットの下に小さな点がつきます。予定の内容は読み取りません。マイ記念日はメイン画面の下で追加できます。",
                "Days with events get a small dot underneath; only the dates are read. Add your own dates at the bottom of the main screen.",
                Modifier.padding(top = 4.dp),
            )
        }
    }
}
