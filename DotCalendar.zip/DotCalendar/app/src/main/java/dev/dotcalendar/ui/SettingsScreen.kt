package dev.dotcalendar.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.dotcalendar.AppSettings
import dev.dotcalendar.AppTheme
import dev.dotcalendar.DotShape
import dev.dotcalendar.HolidayRegion
import dev.dotcalendar.JaDateStyle
import dev.dotcalendar.PhoneCalendar
import dev.dotcalendar.Lang
import dev.dotcalendar.RenderBridge
import dev.dotcalendar.Surface
import dev.dotcalendar.WidgetBg
import dev.dotcalendar.WidgetTextSize
import dev.dotcalendar.WeekdayFont
import dev.dotcalendar.WeekdaySize
import dev.dotcalendar.R
import dev.dotcalendar.render.Renderer
import dev.dotcalendar.render.ThemeSpecs
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.min

private enum class Slot { PASSED, TODAY, HOLIDAY, FUTURE, TEXT, WD_TODAY, WD_SUNDAY, WD_SATURDAY, WD_OTHER }

@Composable
fun SettingsScreen(s: AppSettings, onChange: (AppSettings) -> Unit, onBack: () -> Unit) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val appStyle = LocalAppStyle.current
    var open by remember { mutableStateOf<Slot?>(null) }
    fun toggle(slot: Slot) {
        open = if (open == slot) null else slot
    }

    val weekStyle = remember(s) { RenderBridge.colors(s, Surface.WEEK) }

    fun themeName(t: AppTheme): String =
        if (tx.ja) ThemeSpecs.nameJa(t.id) else ThemeSpecs.nameEn(t.id)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FlatIconButton(Icons.AutoMirrored.Filled.ArrowBack, tx.t("戻る", "Back"), onBack)
            Spacer(Modifier.width(14.dp))
            ThemeTitle(tx.t("設定", "SETTINGS"), if (tx.ja) 27.sp else 24.sp)
        }

        Spacer(Modifier.height(20.dp))
        WidgetPreview(s)

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("ウィジェットの見た目", "Widget look")
            Label("背景", "Background")
            BackgroundPicker(s, onChange)
            Text(
                when (s.widgetBg) {
                    WidgetBg.SOLID -> tx.t("テーマの背景（和紙・夜空・鉄など）で塗りつぶします。", "Filled with the theme's own backdrop (paper, night sky, iron…).")
                    WidgetBg.GLASS -> tx.t("透けるガラス。下の「濃さ」で調整できます。", "See-through glass. Adjust it with Strength below.")
                    WidgetBg.BLUR -> tx.t(
                        "※ Androidのウィジェットは壁紙を直接ぼかせないため、すりガラス風に描いています。",
                        "Android widgets can't blur the wallpaper itself, so Blur is drawn as frosted glass.",
                    )
                    else -> tx.t("壁紙の上に直接表示します。文字には影がつきます。", "Sits right on your wallpaper; text gets a soft shadow so it stays readable.")
                },
                fontFamily = UiFont,
                fontWeight = bodyWeight(),
                fontSize = 12.sp,
                color = pal.sub,
                modifier = Modifier.padding(top = 8.dp),
            )
            if (s.widgetBg == WidgetBg.GLASS || s.widgetBg == WidgetBg.BLUR) {
                Spacer(Modifier.height(8.dp))
                Label("濃さ", "Strength")
                Slider(
                    value = s.widgetOpacity,
                    onValueChange = { onChange(s.copy(widgetOpacity = it)) },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = pal.accent, activeTrackColor = pal.accent, inactiveTrackColor = pal.button),
                )
            }
            Spacer(Modifier.height(10.dp))
            ColorRow(
                tx.t("文字の色", "Text color"),
                RenderBridge.widgetTextColor(s),
                open == Slot.TEXT, { toggle(Slot.TEXT) }, { onChange(s.copy(widgetText = it)) },
                isAuto = s.widgetText == null,
                onAuto = { onChange(s.copy(widgetText = null)) },
            )
            Spacer(Modifier.height(10.dp))
            Label("文字の大きさ", "Text size")
            val sizes = listOf(WidgetTextSize.SMALL, WidgetTextSize.MEDIUM, WidgetTextSize.LARGE)
            SegmentGrid(
                listOf(tx.t("小さめ", "Small"), tx.t("ふつう", "Medium"), tx.t("大きめ", "Large")),
                sizes.indexOf(s.widgetTextSize),
            ) { onChange(s.copy(widgetTextSize = sizes[it])) }
            Spacer(Modifier.height(12.dp))
            Label("週ウィジェット", "Week widget")
            SegmentGrid(
                listOf(tx.t("日付＋週", "Date + week"), tx.t("週だけ", "Week only")),
                if (s.weekOnly) 1 else 0,
            ) { onChange(s.copy(weekOnly = it == 1)) }
            Spacer(Modifier.height(6.dp))
            ToggleRow(tx.t("言語ボタン（日 / EN）を表示", "Show language button (日 / EN)"), s.showLangChip) {
                onChange(s.copy(showLangChip = it))
            }
            if (!s.showLangChip || s.weekOnly) {
                Text(
                    if (s.weekOnly && s.showLangChip) {
                        tx.t("「週だけ」の週ウィジェットにはボタンが出ません。言語はこのアプリの上部で切り替えられます。", "The week-only widget has no button. You can switch language at the top of this app.")
                    } else {
                        tx.t("言語はこのアプリの上部で切り替えられます。", "You can still switch language at the top of this app.")
                    },
                    fontFamily = UiFont,
                    fontWeight = bodyWeight(),
                    fontSize = 12.sp,
                    color = pal.sub,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("曜日", "Weekdays")
            WeekdaySample(s)
            Spacer(Modifier.height(10.dp))
            Label("大きさ", "Size")
            val wdSizes = listOf(WeekdaySize.XSMALL, WeekdaySize.SMALL, WeekdaySize.MEDIUM, WeekdaySize.LARGE)
            SegmentGrid(
                listOf(tx.t("極小", "Extra small"), tx.t("小さめ", "Small"), tx.t("ふつう", "Medium"), tx.t("大きめ", "Large")),
                wdSizes.indexOf(s.weekdaySize),
                columns = 2,
            ) { onChange(s.copy(weekdaySize = wdSizes[it])) }
            Spacer(Modifier.height(12.dp))
            Label("フォント", "Font")
            WeekdayFontPicker(s, onChange)
            Spacer(Modifier.height(12.dp))
            Label("色（テーマを変えてもそのまま）", "Colours (kept when you change theme)")
            ColorRow(
                tx.t("今日", "Today"), s.wdToday ?: weekStyle.todayLabel,
                open == Slot.WD_TODAY, { toggle(Slot.WD_TODAY) }, { onChange(s.copy(wdToday = it)) },
                isAuto = s.wdToday == null, onAuto = { onChange(s.copy(wdToday = null)) },
            )
            ColorRow(
                tx.t("日曜・祝日", "Sundays & holidays"), s.wdSunday ?: weekStyle.holiday,
                open == Slot.WD_SUNDAY, { toggle(Slot.WD_SUNDAY) }, { onChange(s.copy(wdSunday = it)) },
                isAuto = s.wdSunday == null, onAuto = { onChange(s.copy(wdSunday = null)) },
            )
            ColorRow(
                tx.t("土曜", "Saturdays"), s.wdSaturday ?: (s.wdOther ?: weekStyle.sub),
                open == Slot.WD_SATURDAY, { toggle(Slot.WD_SATURDAY) }, { onChange(s.copy(wdSaturday = it)) },
                isAuto = s.wdSaturday == null, onAuto = { onChange(s.copy(wdSaturday = null)) },
            )
            ColorRow(
                tx.t("ほかの曜日", "Other days"), s.wdOther ?: weekStyle.sub,
                open == Slot.WD_OTHER, { toggle(Slot.WD_OTHER) }, { onChange(s.copy(wdOther = it)) },
                isAuto = s.wdOther == null, onAuto = { onChange(s.copy(wdOther = null)) },
            )
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("テーマ", "Theme")
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AppTheme.entries.forEach { t ->
                    ThemeOption(s, t, s.theme == t, themeName(t)) {
                        // A new theme brings its own colours, so custom colours are cleared.
                        onChange(s.withoutColorOverrides().copy(theme = t))
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("言語", "Language")
            SegmentGrid(listOf("日本語", "English"), if (s.lang == Lang.JA) 0 else 1) {
                onChange(s.copy(lang = if (it == 0) Lang.JA else Lang.EN))
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("祝日", "Holidays")
            val regions = listOf(HolidayRegion.JP, HolidayRegion.US, HolidayRegion.BOTH)
            SegmentGrid(
                listOf(tx.t("日本", "Japan"), tx.t("アメリカ", "US"), tx.t("両方", "Both")),
                regions.indexOf(s.holidays),
            ) { onChange(s.copy(holidays = regions[it])) }
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("文字と表示", "Text & display")
            ToggleRow(tx.t("太字テキスト（読みやすく）", "Bold text (easier to read)"), s.boldText) { onChange(s.copy(boldText = it)) }
            Spacer(Modifier.height(4.dp))
            Label("日本語の日付の書き方", "Japanese date style")
            val styles = listOf(JaDateStyle.STANDARD, JaDateStyle.ERA, JaDateStyle.MONTH_DAY)
            SegmentGrid(
                listOf(
                    tx.t("10.14（令和八年）", "10.14 (令和八年)"),
                    "令和8年10月14日",
                    "10月14日",
                ),
                styles.indexOf(s.jaDateStyle),
                columns = 1,
            ) { onChange(s.copy(jaDateStyle = styles[it])) }
            Spacer(Modifier.height(6.dp))
            ToggleRow(tx.t("今日をテーマのアイコンで表示（🌻 など）", "Theme icon for today (🌻 etc.)"), s.todayIcon) { onChange(s.copy(todayIcon = it)) }
            if (s.todayIcon) {
                Label("気のアイコン", "Ki icon")
                SegmentGrid(listOf(tx.t("気功波", "Energy wave"), tx.t("爆発", "Burst")), if (s.kiWave) 0 else 1) {
                    onChange(s.copy(kiWave = it == 0))
                }
                Spacer(Modifier.height(6.dp))
                Label("鋼のアイコン", "Steel icon")
                SegmentGrid(listOf(tx.t("斬撃", "Slash"), tx.t("飛沫", "Splash")), if (s.steelSlash) 0 else 1) {
                    onChange(s.copy(steelSlash = it == 0))
                }
                Spacer(Modifier.height(6.dp))
                Label("侍のアイコン", "Samurai icon")
                SegmentGrid(listOf(tx.t("兜", "Helmet"), tx.t("刀", "Katanas")), if (s.samuraiKabuto) 0 else 1) {
                    onChange(s.copy(samuraiKabuto = it == 0))
                }
                Spacer(Modifier.height(6.dp))
            }
            ToggleRow(tx.t("ドットに日付を表示", "Show dates on the dots"), s.numbers) { onChange(s.copy(numbers = it)) }
            Spacer(Modifier.height(6.dp))
            Label("ドットの形", "Dot shape")
            SegmentGrid(listOf(tx.t("まる", "Dots"), tx.t("しかく", "Squares")), if (s.shape == DotShape.DOT) 0 else 1) {
                onChange(s.copy(shape = if (it == 0) DotShape.DOT else DotShape.SQUARE))
            }
        }

        Spacer(Modifier.height(12.dp))
        CalendarExtras(s, onChange)

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("ドットの色", "Dot colors")
            ColorRow(
                tx.t("過ぎた日", "Days passed"), s.passed ?: appStyle.passed,
                open == Slot.PASSED, { toggle(Slot.PASSED) }, { onChange(s.copy(passed = it)) },
                sampleState = Renderer.PASSED, isAuto = s.passed == null, onAuto = { onChange(s.copy(passed = null)) },
            )
            ColorRow(
                tx.t("今日", "Today"), s.today ?: appStyle.today,
                open == Slot.TODAY, { toggle(Slot.TODAY) }, { onChange(s.copy(today = it)) },
                sampleState = Renderer.TODAY, isAuto = s.today == null, onAuto = { onChange(s.copy(today = null)) },
            )
            ColorRow(
                tx.t("日曜・祝日", "Sundays & holidays"), s.holiday ?: appStyle.holiday,
                open == Slot.HOLIDAY, { toggle(Slot.HOLIDAY) }, { onChange(s.copy(holiday = it)) },
                sampleState = Renderer.HOLIDAY, isAuto = s.holiday == null, onAuto = { onChange(s.copy(holiday = null)) },
            )
            ColorRow(
                tx.t("これからの日", "Upcoming days"), s.future ?: appStyle.future,
                open == Slot.FUTURE, { toggle(Slot.FUTURE) }, { onChange(s.copy(future = it)) },
                sampleState = Renderer.FUTURE, isAuto = s.future == null, onAuto = { onChange(s.copy(future = null)) },
            )
            Text(
                tx.t(
                    "「今日」の色はアイコンをオフにしたときのドットに使われます。",
                    "The Today colour is used when the theme icon is turned off.",
                ),
                fontFamily = UiFont,
                fontWeight = bodyWeight(),
                fontSize = 12.sp,
                color = pal.sub,
                modifier = Modifier.padding(top = 6.dp),
            )
        }

        Spacer(Modifier.height(12.dp))
        Panel {
            SectionTitle("ウィジェットのテーマ", "Widget themes")
            val choices: List<AppTheme?> = listOf(null) + AppTheme.entries
            val choiceNames = choices.map { if (it == null) tx.t("アプリと同じ", "Same as app") else themeName(it) }
            Label("週ウィジェットのテーマ", "Week widget theme")
            SegmentGrid(choiceNames, choices.indexOf(s.weekTheme), columns = 3) {
                onChange(s.copy(weekTheme = choices[it]))
            }
            Spacer(Modifier.height(10.dp))
            Label("月ウィジェットのテーマ", "Month widget theme")
            SegmentGrid(choiceNames, choices.indexOf(s.monthTheme), columns = 3) {
                onChange(s.copy(monthTheme = choices[it]))
            }
            Spacer(Modifier.height(10.dp))
            Label("年ウィジェットのテーマ", "Year widget theme")
            SegmentGrid(choiceNames, choices.indexOf(s.yearTheme), columns = 3) {
                onChange(s.copy(yearTheme = choices[it]))
            }
        }

        Spacer(Modifier.height(16.dp))
        FlatButton(
            tx.t("初期設定に戻す", "Reset to defaults"),
            { onChange(AppSettings(lang = s.lang)) },
            Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(24.dp))
    }
}

/** Transparent / Blur / Glass / Solid, each shown as a little widget on a scrap of wallpaper. */
@Composable
private fun BackgroundPicker(s: AppSettings, onChange: (AppSettings) -> Unit) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val context = LocalContext.current
    val options = listOf(
        WidgetBg.CLEAR to tx.t("透明", "Transparent"),
        WidgetBg.BLUR to tx.t("ぼかし", "Blur"),
        WidgetBg.GLASS to tx.t("ガラス", "Glass"),
        WidgetBg.SOLID to tx.t("不透明（テーマ）", "Solid (theme)"),
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        options.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (bg, name) ->
                    val selected = s.widgetBg == bg
                    val style = remember(s, bg) { RenderBridge.style(context, s.copy(widgetBg = bg), Surface.WEEK) }
                    val shape = RoundedCornerShape(14.dp)
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(shape)
                            .border(if (selected) 2.5.dp else 1.dp, if (selected) pal.accent else pal.button, shape)
                            .clickable { onChange(s.copy(widgetBg = bg)) },
                    ) {
                        RenderCanvas(Modifier.fillMaxWidth().height(64.dp)) { c, w, h ->
                            Renderer.drawBackgroundSample(c, w, h, style)
                        }
                        Text(
                            name,
                            fontFamily = UiFont,
                            fontWeight = if (selected) FontWeight.Bold else bodyWeight(),
                            fontSize = 14.sp,
                            color = if (selected) pal.text else pal.sub,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        )
                    }
                }
            }
        }
    }
}

/** Live sample of the weekday row with the chosen size, font and colours. */
@Composable
private fun WeekdaySample(s: AppSettings) {
    val context = LocalContext.current
    val tx = LocalTx.current
    val style = remember(s) { RenderBridge.style(context, s, Surface.WEEK) }
    val today = remember { LocalDate.now().dayOfWeek.value % 7 }
    val labels = remember(tx.lang) { tx.weekdayInitials.toTypedArray() }
    val red = remember { BooleanArray(7) { it == 0 } }
    RenderCanvas(
        Modifier
            .fillMaxWidth()
            .height(76.dp)
            .clip(RoundedCornerShape(16.dp)),
    ) { c, w, h ->
        Renderer.drawWeekdaySample(c, w, h, style, labels, tx.ja, today, red)
    }
}

/** Standard / Theme / Manga / Racing, each button written in its own font. */
@Composable
private fun WeekdayFontPicker(s: AppSettings, onChange: (AppSettings) -> Unit) {
    val tx = LocalTx.current
    val sample = if (tx.ja) "月火水" else "MON"
    val manga = remember(tx.ja) { FontFamily(Font(if (tx.ja) R.font.wd_manga_ja else R.font.bangers)) }
    val racing = remember(tx.ja) { FontFamily(Font(if (tx.ja) R.font.wd_racing_ja else R.font.wd_racing_en)) }
    val options = listOf(
        Triple(WeekdayFont.STANDARD, tx.t("標準", "Standard"), UiFont),
        Triple(WeekdayFont.THEME, tx.t("テーマ", "Theme"), titleFont(tx.ja)),
        Triple(WeekdayFont.MANGA, tx.t("マンガ", "Manga"), manga),
        Triple(WeekdayFont.RACING, tx.t("レース", "Racing"), racing),
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (font, name, family) ->
                    FlatButton(
                        "$name  $sample",
                        { onChange(s.copy(weekdayFont = font)) },
                        Modifier.weight(1f),
                        selected = s.weekdayFont == font,
                        fontFamily = family,
                        fontSize = 15.sp,
                    )
                }
            }
        }
    }
}

@Composable
private fun ThemeOption(s: AppSettings, t: AppTheme, selected: Boolean, name: String, onClick: () -> Unit) {
    val context = LocalContext.current
    val style = remember(t, s.lang, s.shape, s.numbers, s.todayIcon, s.kiWave, s.steelSlash, s.samuraiKabuto, s.boldText) {
        RenderBridge.style(context, s.withoutColorOverrides().copy(theme = t), Surface.APP)
    }
    ThemeCard(style, selected, name, onClick)
}

/** Live preview of both widgets over a sample wallpaper, so each background can be judged. */
@Composable
private fun WidgetPreview(s: AppSettings) {
    val context = LocalContext.current
    val today = remember { LocalDate.now() }
    val weekStyle = remember(s) { RenderBridge.style(context, s, Surface.WEEK) }
    val monthStyle = remember(s) { RenderBridge.style(context, s, Surface.MONTH) }
    val week = remember(s, today) { RenderBridge.week(today, s) }
    val month = remember(s, today) { RenderBridge.month(YearMonth.from(today), today, s) }
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val w = maxWidth.value
        val weekH = 88f
        val monthW = min(w - 24f, 290f)
        val totalH = 12f + weekH + 12f + monthW + 12f
        RenderCanvas(
            Modifier
                .fillMaxWidth()
                .height(totalH.dp)
                .clip(RoundedCornerShape(20.dp)),
        ) { c, cw, _ ->
            Renderer.drawBackdrop(c, cw, totalH)
            val save = c.save()
            c.translate(12f, 12f)
            Renderer.drawWeekWidget(c, cw - 24f, weekH, weekStyle, week)
            c.restoreToCount(save)
            val save2 = c.save()
            c.translate((cw - monthW) / 2f, 12f + weekH + 12f)
            Renderer.drawMonthWidget(c, monthW, monthW, monthStyle, month)
            c.restoreToCount(save2)
        }
    }
}

/** 六曜, 二十四節気, phone-calendar marks and the countdown. */
@Composable
private fun CalendarExtras(s: AppSettings, onChange: (AppSettings) -> Unit) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val context = LocalContext.current
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        onChange(s.copy(phoneEvents = granted))
    }
    Panel {
        SectionTitle("暦と予定", "Calendar extras")
        ToggleRow(tx.t("六曜を表示（大安・仏滅など）", "Show rokuyō (Taian, Butsumetsu…)"), s.showRokuyo) {
            onChange(s.copy(showRokuyo = it))
        }
        ToggleRow(tx.t("二十四節気を表示（寒露など）", "Show the 24 seasonal terms (Cold Dew…)"), s.showSekki) {
            onChange(s.copy(showSekki = it))
        }
        ToggleRow(tx.t("マイ記念日のカウントダウン", "Countdown to my dates"), s.showCountdown) {
            onChange(s.copy(showCountdown = it))
        }
        ToggleRow(
            tx.t("スマホのカレンダーの予定に印をつける", "Mark days with phone calendar events"),
            s.phoneEvents && PhoneCalendar.hasPermission(context),
        ) { on ->
            when {
                !on -> onChange(s.copy(phoneEvents = false))
                PhoneCalendar.hasPermission(context) -> onChange(s.copy(phoneEvents = true))
                else -> permission.launch(Manifest.permission.READ_CALENDAR)
            }
        }
        Text(
            tx.t(
                "予定のある日はドットの下に小さな点がつきます。予定の内容は読み取りません。",
                "Days with events get a small dot underneath. Only the dates are read, never the event details.",
            ),
            fontFamily = UiFont,
            fontWeight = bodyWeight(),
            fontSize = 12.sp,
            color = pal.sub,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}
