package dev.dotcalendar.widget

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.size
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.datastore.preferences.core.longPreferencesKey
import dev.dotcalendar.DotState
import dev.dotcalendar.R
import java.time.LocalDate

/** Written on every refresh so the widget re-renders with the new date. */
internal val REFRESH_KEY = longPreferencesKey("refreshed_at")

internal val textPrimary = ColorProvider(R.color.widget_text)
internal val textSecondary = ColorProvider(R.color.widget_text_secondary)
internal val textRed = ColorProvider(R.color.dot_holiday)

/** One dot. Drawn from shape drawables so it's a true circle on every Android version. */
@Composable
internal fun WidgetDot(date: LocalDate, today: LocalDate, size: Dp) {
    val state = DotState.of(date, today)
    val numberColor = when (state) {
        DotState.PASSED, DotState.TODAY -> ColorProvider(Color.White)
        DotState.HOLIDAY -> textRed
        DotState.FUTURE -> textSecondary
    }
    Box(GlanceModifier.size(size), contentAlignment = Alignment.Center) {
        Image(
            provider = ImageProvider(state.widgetDrawable),
            contentDescription = null,
            modifier = GlanceModifier.fillMaxSize(),
        )
        // Skip the number when the dot gets too small to read it.
        if (size >= 16.dp) {
            Text(
                text = date.dayOfMonth.toString(),
                style = TextStyle(
                    fontSize = (size.value * 0.4f).sp,
                    fontWeight = if (state == DotState.TODAY) FontWeight.Bold else FontWeight.Medium,
                    color = numberColor,
                    textAlign = TextAlign.Center,
                ),
            )
        }
    }
}
