package dev.dotcalendar.render;

/** Text and day cells for the current week, already in the chosen language. */
public final class WeekData {
    public String bigDate = "";      // 10.14 / 令和8年10月14日 / 10月14日
    public String dayName = "";      // 水曜日 / WEDNESDAY, possibly with 六曜 / 節気 after it
    public String extra = "";        // era year, or today's holiday name
    public String[] weekdays = new String[7];
    public Day[] days = new Day[7];
    public boolean[] redLabels = new boolean[7];
    public int todayIndex = -1;
    public boolean japanese = true;
    public boolean longDate = false; // bigDate is a full date such as 令和8年10月14日
    public String countdown = "";    // shown under the dots when there is room
}
