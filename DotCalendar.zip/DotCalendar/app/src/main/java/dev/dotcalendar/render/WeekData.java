package dev.dotcalendar.render;

/** Text and day cells for the current week, already in the chosen language. */
public final class WeekData {
    public String bigDate = "";      // 10.13
    public String dayName = "";      // 火曜日 / TUESDAY
    public String extra = "";        // era year, or today's holiday name
    public String[] weekdays = new String[7];
    public Day[] days = new Day[7];
    public boolean[] redLabels = new boolean[7];
    public int todayIndex = -1;
    public boolean japanese = true;
}
