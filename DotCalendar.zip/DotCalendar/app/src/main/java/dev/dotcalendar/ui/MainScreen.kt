package dev.dotcalendar.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.dotcalendar.AppSettings
import dev.dotcalendar.Holiday
import dev.dotcalendar.HolidayRegion
import dev.dotcalendar.Holidays
import dev.dotcalendar.JaDateStyle
import dev.dotcalendar.JapaneseCalendar
import dev.dotcalendar.MyDate
import dev.dotcalendar.MyDates
import dev.dotcalendar.PhoneCalendar
import dev.dotcalendar.Lang
import dev.dotcalendar.RenderBridge
import dev.dotcalendar.render.Renderer
import dev.dotcalendar.render.ThemeSpecs
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun MainScreen(s: AppSettings, onChange: (AppSettings) -> Unit, openSettings: () -> Unit) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val today = remember { LocalDate.now() }
    var month by remember { mutableStateOf(YearMonth.from(today)) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        // Title bar: seal + app name, language switch, settings
        Row(verticalAlignment = Alignment.CenterVertically) {
            SealMark(28.dp)
            Spacer(Modifier.width(10.dp))
            Text(
                tx.t("ドット暦", "DOT KOYOMI"),
                fontFamily = titleFont(tx.ja),
                fontWeight = titleWeight(),
                fontSize = 21.sp,
                color = pal.text,
                modifier = Modifier.weight(1f),
            )
            LangSwitch(s.lang) { onChange(s.copy(lang = if (s.lang == Lang.JA) Lang.EN else Lang.JA)) }
            Spacer(Modifier.width(10.dp))
            FlatIconButton(Icons.Filled.Settings, tx.t("設定", "Settings"), openSettings)
        }

        Spacer(Modifier.height(26.dp))
        TodayHeader(today)
        Spacer(Modifier.height(22.dp))
        YearPanel(today)
        Spacer(Modifier.height(26.dp))

        MonthHeader(
            month = month,
            isCurrent = month == YearMonth.from(today),
            onPrev = { month = month.minusMonths(1) },
            onNext = { month = month.plusMonths(1) },
            onToday = { month = YearMonth.from(today) },
        )
        Spacer(Modifier.height(14.dp))
        MonthGrid(
            month = month,
            today = today,
            onSwipePrev = { month = month.minusMonths(1) },
            onSwipeNext = { month = month.plusMonths(1) },
        )

        Spacer(Modifier.height(20.dp))
        MyDatesPanel(s, today, onChange)
        Spacer(Modifier.height(12.dp))
        HolidayList(month)
        Spacer(Modifier.height(12.dp))
        Legend()
        Spacer(Modifier.height(16.dp))
        Text(
            tx.t(
                "ホーム画面を長押し → ウィジェット → Dot Calendar で追加。ウィジェットの「日 / EN」をタップすると言語が切り替わります。",
                "Add widgets: long-press your home screen → Widgets → Dot Calendar. Tap 日 / EN on a widget to switch language.",
            ),
            fontFamily = UiFont,
            fontWeight = bodyWeight(),
            fontSize = 13.sp,
            color = pal.sub,
        )
        Spacer(Modifier.height(24.dp))
    }
}

/** Big clock-style date, then the day in the theme's font, era and old month name underneath. */
@Composable
private fun TodayHeader(today: LocalDate) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val style = LocalAppStyle.current
    val s = LocalSettings.current
    val holidaysToday = Holidays.on(today, s.holidays)
    val info = RenderBridge.info(today, s)
    val countdown = RenderBridge.countdown(today, s)
    Row(verticalAlignment = Alignment.Bottom) {
        Text(
            "${today.monthValue}.${today.dayOfMonth}",
            fontFamily = UiFont,
            fontWeight = FontWeight.Bold,
            fontSize = 54.sp,
            color = pal.text,
        )
        Spacer(Modifier.width(12.dp))
        ThemeTitle(
            tx.dayName(today),
            if (tx.ja) 24.sp else 20.sp,
            Modifier.padding(bottom = 8.dp),
            color = Color(style.todayLabel),
        )
    }
    Text(
        if (tx.ja && s.jaDateStyle == JaDateStyle.ERA) "${tx.eraDate(today)}　${JapaneseCalendar.traditionalMonth(today.monthValue)}"
        else if (tx.ja) "${tx.eraLine(today)}　${JapaneseCalendar.traditionalMonth(today.monthValue)}"
        else "${tx.eraLine(today)} · ${JapaneseCalendar.traditionalRomaji(today.monthValue).uppercase()}",
        fontFamily = UiFont,
        fontWeight = bodyWeight(),
        fontSize = 15.sp,
        color = pal.sub,
    )
    if (info.isNotEmpty()) {
        Spacer(Modifier.height(4.dp))
        Text(info, fontFamily = UiFont, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = pal.text)
    }
    if (countdown.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        Text(countdown, fontFamily = UiFont, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(style.todayLabel))
    }
    holidaysToday.forEach { h ->
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(Color(style.holiday)),
            )
            Spacer(Modifier.width(8.dp))
            Text(
                if (tx.ja) h.nameJa else h.nameEn,
                fontFamily = UiFont,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color(style.holiday),
            )
        }
    }
}

/** The year as the theme's object: record, power gauge, moon or iron dial. */
@Composable
private fun YearPanel(today: LocalDate) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val style = LocalAppStyle.current
    val day = today.dayOfYear
    val total = today.lengthOfYear()
    val progress = day / total.toFloat()
    val pct = (progress * 100).toInt()
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RenderCanvas(Modifier.size(116.dp)) { c, w, h ->
                val record = style.theme == ThemeSpecs.RONIN
                Renderer.drawYear(c, w * (if (record) 0.45f else 0.5f), h * (if (record) 0.55f else 0.5f), w * (if (record) 0.40f else 0.42f), progress, style)
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    tx.t("今年", "THIS YEAR"),
                    fontFamily = titleFont(tx.ja),
                    fontWeight = titleWeight(),
                    fontSize = 15.sp,
                    color = pal.sub,
                )
                Text("$day / $total", fontFamily = UiFont, fontWeight = FontWeight.Bold, fontSize = 30.sp, color = pal.text)
                Text(
                    tx.t("${pct}% · 残り${total - day}日", "$pct% · ${total - day} days left"),
                    fontFamily = UiFont,
                    fontWeight = bodyWeight(),
                    fontSize = 14.sp,
                    color = pal.sub,
                )
            }
        }
    }
}

@Composable
private fun MonthHeader(month: YearMonth, isCurrent: Boolean, onPrev: () -> Unit, onNext: () -> Unit, onToday: () -> Unit) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            ThemeTitle(tx.monthTitle(month.monthValue), if (tx.ja) 32.sp else 28.sp)
            Spacer(Modifier.height(4.dp))
            Text(tx.monthLine(month), fontFamily = UiFont, fontWeight = bodyWeight(), fontSize = 14.sp, color = pal.sub)
        }
        if (!isCurrent) {
            FlatButton(tx.t("今日", "Today"), onToday, selected = true)
            Spacer(Modifier.width(8.dp))
        }
        FlatButton("‹", onPrev, fontSize = 20.sp)
        Spacer(Modifier.width(8.dp))
        FlatButton("›", onNext, fontSize = 20.sp)
    }
}

@Composable
private fun MonthGrid(month: YearMonth, today: LocalDate, onSwipePrev: () -> Unit, onSwipeNext: () -> Unit) {
    val style = LocalAppStyle.current
    val lang = LocalTx.current.lang
    val s = LocalSettings.current
    val context = LocalContext.current
    val events by produceState(initialValue = emptySet<LocalDate>(), month, s.phoneEvents) {
        value = if (s.phoneEvents) {
            withContext(Dispatchers.IO) { PhoneCalendar.eventDays(context, month.atDay(1), month.atEndOfMonth()) }
        } else {
            emptySet()
        }
    }
    val data = remember(month, today, lang, s, events) { RenderBridge.month(month, today, s, events) }
    val prev by rememberUpdatedState(onSwipePrev)
    val next by rememberUpdatedState(onSwipeNext)
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val h = Renderer.monthGridHeight(maxWidth.value, data.weeks.size)
        RenderCanvas(
            Modifier
                .fillMaxWidth()
                .height(h.dp)
                .pointerInput(Unit) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = {
                            if (total > 120f) prev() else if (total < -120f) next()
                            total = 0f
                        },
                    ) { _, dx -> total += dx }
                },
        ) { c, w, _ -> Renderer.drawMonthGrid(c, w, style, data) }
    }
}

@Composable
private fun Legend() {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    Panel {
        SectionTitle("凡例", "Key")
        val items = listOf(
            Renderer.PASSED to tx.t("過ぎた日", "Days passed"),
            Renderer.TODAY to tx.t("今日", "Today"),
            Renderer.HOLIDAY to tx.t("これからの日曜・祝日", "Upcoming Sundays & holidays"),
            Renderer.FUTURE to tx.t("これからの日", "Upcoming days"),
        )
        items.forEach { (state, label) ->
            Row(Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                DaySample(state, 7, 32.dp)
                Spacer(Modifier.width(10.dp))
                Text(label, fontFamily = UiFont, fontWeight = bodyWeight(), fontSize = 15.sp, color = pal.text)
            }
        }
    }
}

@Composable
private fun HolidayList(month: YearMonth) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val style = LocalAppStyle.current
    val region = LocalSettings.current.holidays
    val holidays = Holidays.forMonth(month, region)
    val showTags = region == HolidayRegion.BOTH
    Panel {
        SectionTitle("祝日・記念日", "Holidays")
        if (holidays.isEmpty()) {
            Text(
                tx.t("今月は祝日がありません", "No holidays this month"),
                fontFamily = UiFont,
                fontWeight = bodyWeight(),
                fontSize = 15.sp,
                color = pal.sub,
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                holidays.forEach { h -> HolidayRow(h, showTags, Color(style.holiday)) }
            }
        }
    }
}

@Composable
private fun HolidayRow(h: Holiday, showTag: Boolean, dot: Color) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(dot),
        )
        Spacer(Modifier.width(10.dp))
        Text(
            tx.shortDate(h.date),
            fontFamily = UiFont,
            fontWeight = bodyWeight(),
            fontSize = 14.sp,
            color = pal.sub,
            modifier = Modifier.width(124.dp),
        )
        Column(Modifier.weight(1f)) {
            Text(if (tx.ja) h.nameJa else h.nameEn, fontFamily = UiFont, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = pal.text)
            Text(if (tx.ja) h.nameEn else h.nameJa, fontFamily = UiFont, fontWeight = bodyWeight(), fontSize = 12.sp, color = pal.sub)
        }
        if (showTag) {
            Spacer(Modifier.width(8.dp))
            Text(
                if (h.us) tx.t("米国", "US") else tx.t("日本", "JP"),
                fontFamily = UiFont,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = pal.sub,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(pal.button)
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
    }
}

/** The user's own dates: birthdays, trips, exams. Tap one to edit it. */
@Composable
private fun MyDatesPanel(s: AppSettings, today: LocalDate, onChange: (AppSettings) -> Unit) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    var editing by remember { mutableStateOf<MyDate?>(null) }
    var adding by remember { mutableStateOf(false) }
    Panel {
        SectionTitle("マイ記念日", "My dates")
        val list = MyDates.sorted(s.myDates, today)
        if (list.isEmpty()) {
            Text(
                tx.t(
                    "誕生日や旅行、試験の日などを追加すると、カレンダーに色の輪で表示され、ウィジェットにカウントダウンが出ます。",
                    "Add birthdays, trips or exam days. They get a coloured ring on the calendar and a countdown on the widgets.",
                ),
                fontFamily = UiFont,
                fontWeight = bodyWeight(),
                fontSize = 14.sp,
                color = pal.sub,
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                list.forEach { (d, next) ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { editing = d }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(Color(d.color)),
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.name, fontFamily = UiFont, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = pal.text)
                            Text(
                                tx.shortDate(next ?: d.date) + if (d.yearly) tx.t("　毎年", " · every year") else "",
                                fontFamily = UiFont,
                                fontWeight = bodyWeight(),
                                fontSize = 13.sp,
                                color = pal.sub,
                            )
                        }
                        Text(
                            if (next == null) tx.t("終了", "Past") else tx.daysAway(ChronoUnit.DAYS.between(today, next)),
                            fontFamily = UiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (next == null) pal.sub else Color(d.color),
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        FlatButton(tx.t("＋ 日付を追加", "+ Add a date"), { adding = true }, Modifier.fillMaxWidth())
    }

    val current = editing
    if (adding || current != null) {
        val deleteAction: (() -> Unit)? = if (current == null) {
            null
        } else {
            fun() {
                onChange(s.copy(myDates = s.myDates.filter { it.id != current.id }))
                editing = null
            }
        }
        MyDateDialog(
            initial = current,
            onDismiss = {
                adding = false
                editing = null
            },
            onSave = { saved ->
                onChange(s.copy(myDates = s.myDates.filter { it.id != saved.id } + saved))
                adding = false
                editing = null
            },
            onDelete = deleteAction,
        )
    }
}

@Composable
private fun MyDateDialog(initial: MyDate?, onDismiss: () -> Unit, onSave: (MyDate) -> Unit, onDelete: (() -> Unit)?) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val context = LocalContext.current
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var date by remember { mutableStateOf(initial?.date ?: LocalDate.now()) }
    var yearly by remember { mutableStateOf(initial?.yearly ?: false) }
    var color by remember { mutableStateOf(initial?.color ?: MyDates.COLORS[0]) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = pal.panel,
        titleContentColor = pal.text,
        textContentColor = pal.text,
        title = {
            Text(
                if (initial == null) tx.t("日付を追加", "Add a date") else tx.t("日付を編集", "Edit date"),
                fontFamily = UiFont,
                fontWeight = FontWeight.Bold,
            )
        },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    label = { Text(tx.t("名前（例：期末試験）", "Name (e.g. Finals)")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(12.dp))
                FlatButton(
                    tx.t("日付：", "Date: ") + tx.shortDate(date) + " " + date.year,
                    {
                        android.app.DatePickerDialog(
                            context,
                            { _, y, m, d -> date = LocalDate.of(y, m + 1, d) },
                            date.year,
                            date.monthValue - 1,
                            date.dayOfMonth,
                        ).show()
                    },
                    Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(6.dp))
                ToggleRow(tx.t("毎年くり返す（誕生日など）", "Repeat every year (birthdays)"), yearly) { yearly = it }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MyDates.COLORS.forEach { c ->
                        val selected = c == color
                        Box(
                            Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .border(if (selected) 2.dp else 0.dp, if (selected) pal.text else Color.Transparent, CircleShape)
                                .padding(if (selected) 5.dp else 3.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .clickable { color = c },
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(MyDate(initial?.id ?: System.currentTimeMillis(), name.trim(), date, yearly, color))
                    }
                },
            ) {
                Text(tx.t("保存", "Save"), color = pal.text, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) { Text(tx.t("削除", "Delete"), color = Color(0xFFE5544B)) }
                }
                TextButton(onClick = onDismiss) { Text(tx.t("キャンセル", "Cancel"), color = pal.sub) }
            }
        },
    )
}
