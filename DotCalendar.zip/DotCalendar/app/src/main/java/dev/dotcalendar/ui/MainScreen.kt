package dev.dotcalendar.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.dotcalendar.AppSettings
import dev.dotcalendar.JapaneseCalendar
import dev.dotcalendar.JapaneseHolidays
import dev.dotcalendar.Lang
import dev.dotcalendar.RenderBridge
import dev.dotcalendar.render.Renderer
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun MainScreen(s: AppSettings, onChange: (AppSettings) -> Unit, openSettings: () -> Unit) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val today = remember { LocalDate.now() }
    var month by remember { mutableStateOf(YearMonth.from(today)) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        // Title bar: seal + name, language switch, settings
        Row(verticalAlignment = Alignment.CenterVertically) {
            SealMark(26.dp)
            Spacer(Modifier.width(10.dp))
            Text(
                tx.t("ドット暦", "DOT KOYOMI"),
                fontFamily = titleFont(tx.ja),
                fontSize = 20.sp,
                color = pal.text,
                modifier = Modifier.weight(1f),
            )
            LangSwitch(s.lang) { onChange(s.copy(lang = if (s.lang == Lang.JA) Lang.EN else Lang.JA)) }
            Spacer(Modifier.width(10.dp))
            FlatIconButton(Icons.Filled.Settings, tx.t("設定", "Settings"), openSettings)
        }

        Spacer(Modifier.height(28.dp))
        TodayHeader(today)
        Spacer(Modifier.height(24.dp))
        YearRecord(today)
        Spacer(Modifier.height(28.dp))

        MonthHeader(
            month = month,
            isCurrent = month == YearMonth.from(today),
            onPrev = { month = month.minusMonths(1) },
            onNext = { month = month.plusMonths(1) },
            onToday = { month = YearMonth.from(today) },
        )
        Spacer(Modifier.height(14.dp))
        MonthGrid(
            month = month,
            today = today,
            onSwipePrev = { month = month.minusMonths(1) },
            onSwipeNext = { month = month.plusMonths(1) },
        )

        Spacer(Modifier.height(20.dp))
        HolidayList(month)
        Spacer(Modifier.height(12.dp))
        Legend()
        Spacer(Modifier.height(16.dp))
        Text(
            tx.t(
                "ホーム画面を長押し → ウィジェット → Dot Calendar で追加。ウィジェットの「日 / EN」をタップすると言語が切り替わります。",
                "Add widgets: long-press your home screen → Widgets → Dot Calendar. Tap 日 / EN on a widget to switch language.",
            ),
            fontFamily = UiFont,
            fontSize = 12.sp,
            color = pal.sub,
        )
        Spacer(Modifier.height(24.dp))
    }
}

/** Big clock-style date, with the era and old month name in brush underneath. */
@Composable
private fun TodayHeader(today: LocalDate) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val accent = Color(LocalSettings.current.today)
    val holiday = JapaneseHolidays.nameOf(today)
    Row(verticalAlignment = Alignment.Bottom) {
        Text("${today.monthValue}.${today.dayOfMonth}", fontFamily = UiFont, fontWeight = FontWeight.Bold, fontSize = 52.sp, color = pal.text)
        Spacer(Modifier.width(10.dp))
        Text(
            tx.dayName(today),
            fontFamily = if (tx.ja) BrushFont else UiFont,
            fontWeight = if (tx.ja) FontWeight.Normal else FontWeight.SemiBold,
            fontSize = if (tx.ja) 22.sp else 18.sp,
            color = accent,
            modifier = Modifier.padding(bottom = 10.dp),
        )
    }
    Text(
        if (tx.ja) "${JapaneseCalendar.eraYearKanji(today)}　${JapaneseCalendar.traditionalMonth(today.monthValue)}"
        else "${tx.eraLine(today)} · ${JapaneseCalendar.traditionalRomaji(today.monthValue).uppercase()}",
        fontFamily = if (tx.ja) BrushFont else UiFont,
        fontSize = if (tx.ja) 16.sp else 13.sp,
        color = pal.sub,
    )
    if (holiday != null) {
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(SealRed),
            )
            Spacer(Modifier.width(8.dp))
            Text(tx.holiday(holiday), fontFamily = if (tx.ja) BrushFont else UiFont, fontSize = 15.sp, color = SealRed)
        }
    }
}

@Composable
private fun YearRecord(today: LocalDate) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val style = LocalAppStyle.current
    val day = today.dayOfYear
    val total = today.lengthOfYear()
    val progress = day / total.toFloat()
    val pct = (progress * 100).toInt()
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RenderCanvas(Modifier.size(112.dp)) { c, w, h ->
                Renderer.drawVinyl(c, w * 0.45f, h * 0.55f, w * 0.40f, progress, style, "暦")
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(tx.t("今年", "THIS YEAR"), fontFamily = if (tx.ja) BrushFont else UiFont, fontSize = 13.sp, color = pal.sub, letterSpacing = if (tx.ja) 0.sp else 1.5.sp)
                Text("$day / $total", fontFamily = UiFont, fontWeight = FontWeight.Bold, fontSize = 28.sp, color = pal.text)
                Text(
                    tx.t("${pct}% · 残り${total - day}日", "$pct% · ${total - day} days left"),
                    fontFamily = UiFont,
                    fontSize = 13.sp,
                    color = pal.sub,
                )
            }
        }
    }
}

@Composable
private fun MonthHeader(month: YearMonth, isCurrent: Boolean, onPrev: () -> Unit, onNext: () -> Unit, onToday: () -> Unit) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            BrushTitle(tx.monthTitle(month.monthValue), if (tx.ja) 30.sp else 24.sp)
            Spacer(Modifier.height(4.dp))
            Text(tx.monthLine(month), fontFamily = if (tx.ja) BrushFont else UiFont, fontSize = 13.sp, color = pal.sub)
        }
        if (!isCurrent) {
            FlatButton(tx.t("今日", "Today"), onToday, selected = true)
            Spacer(Modifier.width(8.dp))
        }
        FlatButton("‹", onPrev, fontSize = 20.sp)
        Spacer(Modifier.width(8.dp))
        FlatButton("›", onNext, fontSize = 20.sp)
    }
}

@Composable
private fun MonthGrid(month: YearMonth, today: LocalDate, onSwipePrev: () -> Unit, onSwipeNext: () -> Unit) {
    val style = LocalAppStyle.current
    val lang = LocalTx.current.lang
    val data = remember(month, today, lang) { RenderBridge.month(month, today, lang) }
    val prev by rememberUpdatedState(onSwipePrev)
    val next by rememberUpdatedState(onSwipeNext)
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val h = Renderer.monthGridHeight(maxWidth.value, data.weeks.size)
        RenderCanvas(
            Modifier
                .fillMaxWidth()
                .height(h.dp)
                .pointerInput(Unit) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = {
                            if (total > 120f) prev() else if (total < -120f) next()
                            total = 0f
                        },
                    ) { _, dx -> total += dx }
                },
        ) { c, w, _ -> Renderer.drawMonthGrid(c, w, style, data) }
    }
}

@Composable
private fun Legend() {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    Panel {
        SectionTitle("凡例", "Key")
        val items = listOf(
            Renderer.PASSED to tx.t("過ぎた日", "Days passed"),
            Renderer.TODAY to tx.t("今日", "Today"),
            Renderer.HOLIDAY to tx.t("これからの日曜・祝日", "Upcoming Sundays & holidays"),
            Renderer.FUTURE to tx.t("これからの日", "Upcoming days"),
        )
        items.forEach { (state, label) ->
            Row(Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                DaySample(state, 7, 30.dp)
                Spacer(Modifier.width(10.dp))
                Text(label, fontFamily = UiFont, fontSize = 14.sp, color = pal.text)
            }
        }
    }
}

@Composable
private fun HolidayList(month: YearMonth) {
    val tx = LocalTx.current
    val pal = LocalPalette.current
    val holidays = JapaneseHolidays.forYear(month.year)
        .filterKeys { YearMonth.from(it) == month }
        .toSortedMap()
    Panel {
        SectionTitle("祝日", "Holidays")
        if (holidays.isEmpty()) {
            Text(tx.t("今月は祝日がありません", "No public holidays this month"), fontFamily = UiFont, fontSize = 14.sp, color = pal.sub)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                holidays.forEach { (date, name) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(SealRed),
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(tx.shortDate(date), fontFamily = UiFont, fontSize = 14.sp, color = pal.sub, modifier = Modifier.width(120.dp))
                        Column {
                            Text(tx.holiday(name), fontFamily = if (tx.ja) BrushFont else UiFont, fontSize = 14.sp, color = pal.text)
                            if (!tx.ja) Text(name, fontFamily = BrushFont, fontSize = 11.sp, color = pal.sub)
                        }
                    }
                }
            }
        }
    }
}
